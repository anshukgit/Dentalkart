import React from "react";
import { Icon, } from 'native-base'
import { StyleSheet, StatusBar, Text, View, Image, Pressable, ScrollView, } from 'react-native';
// import { screenPadding, moderateScale, writeLog, verticalScale, responsiveHeight, responsiveFontSize, responsiveWidth } from '../helpers/functions';
import colors from '@config/colors';
// import fonts from '../helpers/font'
class headerComponent extends React.Component {

  render() {
    const { label, isheart, cartCount, onPress, onHeartPress, isempty, getHelp, style, AddnewAddress, gethelpPress, addressBtnPress } = this.props;
    return (
      <View style={[styles.headerView, style]}>
        <StatusBar
          barStyle="default"
          hidden={false}
          backgroundColor={'#fff'}
          barStyle={'dark-content'}
          translucent={false}
        />
        <Pressable style={styles.leftimgView} onPress={onPress}>
          <Image source={require('../../assets/leftArrow.png') } style={{ width: 40, left: -8 }} resizeMode={'contain'} />
          {/* <Icon name='arrow-back' type='Ionicons' style={{ fontSize: 25, color: colors.blueColor }} /> */}
        </Pressable>
        <View style={{ width: AddnewAddress ? '55%' : '60%', }}>
          <Text style={{ color: colors.productHeaderText, fontSize: 16, }}>{label}</Text>
        </View>
        {/* {
          isempty ?
            null :
            <View style={styles.headerLeftSideView}>
              <Pressable style={styles.heartView} onPress={onHeartPress} >
                <Icon name={isheart ? "heart" : "hearto"} type="AntDesign" style={{ fontSize: 17, color: isheart ? colors.red : colors.black }} />
              </Pressable>
              <Pressable style={styles.shareBtnView}  >
                <Icon name={"share-google"} type="EvilIcons" style={{ fontSize: 28, color: colors.black }} />
              </Pressable>
              <Pressable style={styles.cartView} >
               
                <View style={styles.cartCount}>
                  <Text style={{ fontSize: 9, color: colors.white }}>{cartCount}</Text>
                </View>
              </Pressable>
            </View>
        }

        {
          getHelp ?
            <View style={[styles.headerLeftSideView, { alignItems: 'center', justifyContent: 'flex-end' }]}>
              <Pressable style={[styles.heartView, { borderWidth: 1, borderColor: colors.orangeBtn, width: '55%', height: '60%', }]} onPress={gethelpPress}>
                <Text style={{ fontSize: 10, color: colors.orangeBtn }}>Get Help</Text>
              </Pressable>

            </View>
            :
            null
        }

        {
          AddnewAddress ?
            <Pressable style={[styles.headerLeftSideView, { alignItems: 'center', justifyContent: 'center', width: '100%', }]} onPress={addressBtnPress}>
              <Text style={{ fontSize: 14, width: '100%', alignContent: 'center', color: colors.blueColor }}>+  Add new address</Text>

            </Pressable>
            :
            null
        } */}

      </View>
    );
  }

}

const styles = StyleSheet.create({
  headerView: { height: 50, width: '100%', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, backgroundColor: '#fff' },
  leftimgView: { width: '12%', height: '70%', justifyContent: 'center' ,},
  headerLeftSideView: { width: '28%', height: '70%', justifyContent: 'space-between', alignItems: 'center', flexDirection: 'row' },
  heartView: { width: '20%', height: '100%', justifyContent: 'center', alignItems: 'center', },
  shareBtnView: { width: '25%', height: '100%', justifyContent: 'center', alignItems: 'center', },
  cartView: { width: '25%', height: '100%', justifyContent: 'center', alignItems: 'center', },
  cartCount: { width: 12, height: 12, borderRadius: 12, backgroundColor: colors.NeonCarrot, justifyContent: 'center', alignItems: 'center', position: 'absolute', top: 5, right: -5 },
})
export default headerComponent;