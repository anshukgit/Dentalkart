import {StyleSheet, Platform} from 'react-native';
import {DeviceWidth, DeviceHeight, SecondaryColor} from '@config/environment';

export default (styles = StyleSheet.create({
  quantityWrapper: {
    backgroundColor: '#fff',
    // width: Platform.OS === 'ios' ? DeviceWidth / 2 : null,
    paddingLeft: 1,
    paddingVertical: 2,
    borderRadius: 2,
    borderColor: '#b9b9b9',
  },
  quantityTitle: {
    fontSize: 11,
    color: '#212121',
    left:2
  },
  quantityPickerWrapper: {
    flexDirection: 'row',
    paddingHorizontal:5,
    backgroundColor: '#F3F3F3',
    width: 70,
    alignItems: 'center',
    justifyContent: 'center',
  height:28,
     borderRadius: 5,
    borderWidth:0.5,
    borderColor: '#aaa',
    elevation: 3,
    shadowColor: '#bfbfbf',
    shadowOffset: {
      height: 0,
      width: 0,
    },
    shadowOpacity: 0.5,
    shadowRadius: 2,
    paddingBottom:3
  },
  dropdownIcon: {
    color: '#000',
    marginLeft: 7,
    fontSize:20
  },
  quantityInputWrapper: {
    flexDirection: 'row',
  },
  quantityInput: {
    width: 30,
    height: 25,
    backgroundColor: '#fff',
    justifyContent: 'center',
    borderRadius: 2,
    borderColor: SecondaryColor,
    borderWidth: 0.3,
    elevation: 1.5,
    shadowColor: '#bfbfbf',
    shadowOffset: {
      height: 1,
      width: 1,
    },
    shadowOpacity: 1,
    shadowRadius: 5,
    paddingLeft: 5,
    paddingVertical: 0,
    marginRight: 10,
    fontSize: 12,
  },
  updateButton: {
    height: 25,
    elevation: 1.5,
    shadowColor: '#bfbfbf',
    shadowOffset: {
      height: 1,
      width: 1,
    },
    shadowOpacity: 1,
    shadowRadius: 5,
    paddingHorizontal: 3,
    paddingVertical: Platform.OS === 'ios' ? 5 : null,
    backgroundColor: '#fff',
    borderRadius: 2,
    borderColor: SecondaryColor,
    borderWidth: 0.3,
    justifyContent: 'center',
    alignItems: 'center',
    flexWrap: 'nowrap',
  },
  updateButtonText: {
    color: '#212121',
    fontSize: 12,
  },
  modalWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    height: DeviceHeight,
    width: DeviceWidth,
  },
  modalOverlay: {
    backgroundColor: '#000',
    height: DeviceHeight,
    width: DeviceWidth,
    opacity: 0.2,
    position: 'absolute',
  },
  modalContainer: {
    backgroundColor: '#fff',
    borderRadius: 5,
    height: DeviceHeight / 2.1,
    width: DeviceWidth / 3,
  },
  listWrapper: {
    borderBottomWidth: 1,
    borderColor: '#dfdfdf',
    paddingLeft: 10,
    justifyContent: 'center',
    height: DeviceHeight / 1.7 / 10,
  },
  lastQuantity: {
    borderBottomWidth: 0,
  },
}));
