import React, {Component} from 'react';
import {View, TouchableOpacity, Text, Platform} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import MIcon from 'react-native-vector-icons/MaterialIcons';
import MCIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './header.style';
import InfoHeader from '../infoheader';
import {StatusBarScreen} from '../statusbar';
import {fireAnalyticsEvent} from '@helpers/firebase_analytics';
import {DentalkartContext} from '@dentalkartContext';
import SyncStorage from '@helpers/async_storage';

export default class Header extends Component {
  static contextType = DentalkartContext;
  render() {
    const {userInfo, cartCount} = this.context;
    const {
      home,
      cart,
      title,
      search,
      menu,
      navigation,
      heading,
      scrollToTop,
    } = this.props;
    //const cartCount = SyncStorage.get('cartCount');
    return (
      <View>
        <StatusBarScreen />
        {home && <InfoHeader />}
        <View
          style={[
            styles.headerWrapper,
            {
              justifyContent: title ? 'space-between' : 'flex-start',
            },
          ]}>
          <View style={styles.leftIconsWrapper}>
            {menu ? (
              <DrawerIcon
                iconName="menu"
                navigation={navigation}
                userInfo={userInfo}
              />
            ) : (
              <BackIcon _this={this} />
            )}
          </View>
          {title ? (
            <DentalkartLogo _this={this} scrollToTop={scrollToTop} />
          ) : (
            <Text style={styles.heading}>{heading}</Text>
          )}
          <View style={styles.rightIconsWrapper}>
            {search ? <SearchIcon _this={this} /> : null}
            {cart ? <CartIcon _this={this} cartCount={cartCount ?? 0} /> : null}
          </View>
        </View>
        {home ? (
          <View style={styles.headerWrapperSearch}>
            <TouchableCustom
              underlayColor={'#ffffff10'}
              onPress={() =>
                _handlePress(this, 'ShopByCategory', 'ShopByCategory')
              }>
              <View style={styles.shopByCategory}>
                <Text style={styles.shopByCategoryText}>Shop by</Text>
                <Text style={styles.categoryText}>Category</Text>
              </View>
            </TouchableCustom>
            <TouchableCustom
              underlayColor={'#ffffff10'}
              onPress={() => _handlePress(this, 'Search', 'Search')}>
              <View style={styles.inputField}>
                <Icon
                  style={styles.searchIcon}
                  name="md-search"
                  size={25}
                  color={'#cdcdcd'}
                />
                <Text style={styles.inputFieldPlaceholder}>
                  Search your requirements
                </Text>
              </View>
            </TouchableCustom>
          </View>
        ) : null}
      </View>
    );
  }
}

function _handlePress(_this, routeName, operation = null, scrollToTop) {
  const {goBack, state, navigate} = _this.props.navigation;
  this.requestAnimationFrame(() => {
    if (operation == 'home') {
      if (state.routeName != 'Home') {
        navigate('Home');
      } else {
        scrollToTop();
      }
    } else if (operation == 'cart') {
      _this.props.navigation.push('Cart');
    } else if (operation == 'back') {
      const {backCoustomMethod} = _this.props;
      if (backCoustomMethod) {
        backCoustomMethod();
      } else {
        goBack();
      }
    } else {
      navigate(routeName);
    }
  });
}
const BackIcon = ({_this}) => (
  <TouchableOpacity
    style={styles.backIconWrapper}
    onPress={() => _handlePress(_this, 'Back', 'back')}
    hitSlop={{top: 20, right: 10, bottom: 20, left: 20}}>
    <Icon name="md-arrow-back" size={23} color="#ffffff" />
  </TouchableOpacity>
);
const DrawerIcon = ({iconName, navigation, userInfo}) => {
  triggerScreenEvent = routeName => {
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Left Navigation Pane',
      baseScreen: routeName,
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };
  return (
    <TouchableOpacity
      style={styles.drawerWrapper}
      onPress={() => {
        triggerScreenEvent(navigation.state.routeName);
        navigation.openDrawer();
      }}
      hitSlop={{top: 20, right: 20, bottom: 20, left: 10}}>
      <MIcon name={iconName} size={28} color="#fff" />
    </TouchableOpacity>
  );
};
const DentalkartLogo = ({_this, scrollToTop}) => (
  <TouchableOpacity
    style={styles.logoWrapper}
    onPress={() => _handlePress(_this, 'Home', 'home', scrollToTop)}>
    <Text style={styles.logo}>Dentalkart</Text>
  </TouchableOpacity>
);
const SearchIcon = ({_this}) => (
  <TouchableOpacity
    style={styles.searchIconWrapper}
    onPress={() => _handlePress(_this, 'Search')}
    hitSlop={{top: 20, right: 10, bottom: 20, left: 20}}>
    <MCIcon name="magnify" size={22} color={'#fff'} />
  </TouchableOpacity>
);
const CartIcon = ({_this, cartCount}) => (
  <TouchableOpacity
    style={styles.cartWrapper}
    onPress={() => _handlePress(_this, 'Cart', 'cart')}
    hitSlop={{top: 20, right: 20, bottom: 20, left: 10}}>
    <MIcon name={'shopping-cart'} size={20} style={styles.rightIcon} />
    <View style={styles.cartCountWrapper}>
      <Text style={styles.cartCount}>{cartCount}</Text>
    </View>
  </TouchableOpacity>
);
