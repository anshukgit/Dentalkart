export {default as GET_PRODUCT_REVIEWS_QUERY} from './get_product_reviews.gql';
export {CHECK_PRODUCT_BOUGHT_QUERY} from '../../graphql';
