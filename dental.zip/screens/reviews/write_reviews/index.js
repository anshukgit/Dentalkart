import React, {Component} from 'react';
import {
  View,
  Text,
  ActivityIndicator,
  Image,
  TouchableOpacity,
  KeyboardAvoidingView,
  TextInput,
  ToastAndroid,
} from 'react-native';
import {Query, Mutation} from 'react-apollo';
import {
  CHECK_PRODUCT_BOUGHT_QUERY,
  SUBMIT_REVIEW_QUERY,
  CUSTOMER_INFO_QUERY,
} from '../graphql';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {TextField} from 'react-native-material-textfield';
import {SecondaryColor} from '@config/environment';
import styles from './write_reviews.style';
import Header from '@components/header';
import {client} from '@apolloClient';
import {fireAnalyticsEvent} from '@helpers/firebase_analytics';
import {DentalkartContext} from '@dentalkartContext';
import {showErrorMessage, showSuccessMessage} from '../../../helpers/show_messages';

export default class Reviews extends Component {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    this.state = {
      star: 0,
      reviewTitle: '',
      reviewDescription: '',
    };
  }
  async submitReview(submitReview) {
    const {reviewDescription, reviewTitle, star} = this.state;
    const productId = this.props.navigation.getParam('productId', 'No-ID');
    const validateErrors = this.checkErrors();
    if (validateErrors) {
      const data = await client.readQuery({query: CUSTOMER_INFO_QUERY});
      const {
        customer: {firstname: nickname},
      } = data;
      let variables = {
        product_id: parseInt(productId),
        nickname,
        title: reviewTitle,
        details: reviewDescription,
        rating: parseInt(star),
      };
      submitReview({variables: variables});
      showSuccessMessage(
        'Thank you so much. Review has been accepeted for moderation.',
      );
      this.props.navigation.goBack();
    }
  }
  checkErrors() {
    const {reviewDescription, reviewTitle, star} = this.state;
    if (star <= 0) {
      this.setState({ratingError: true});
      return false;
    }
    if (!reviewDescription) {
      this.setState({descriptionError: 'This is a required field.'});
      return false;
    }
    if (!reviewTitle) {
      this.setState({titleError: 'This is a required field.'});
      return false;
    }
    return true;
  }
  triggerScreenEvent = _ => {
    const {userInfo} = this.context;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Write Review',
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };
  componentDidMount() {
    this.triggerScreenEvent();
  }
  render() {
    const {navigation} = this.props;
    const productId = navigation.getParam('productId', 'No-ID');
    return (
      <View>
        <Header
          goBack
          heading="Review Product"
          navigation={this.props.navigation}
        />
        <Query
          query={CHECK_PRODUCT_BOUGHT_QUERY}
          variables={{id: productId}}
          fetchPolicy="network-only">
          {({loading, error, data}) => {
            if (loading) {
              return <ActivityIndicator size="large" color="#343434" />;
            }
            if (error) {
              return showErrorMessage(`${error.message}. Please try again.`);
            }
            if (data.checkCustomerBoughtProduct) {
              return (
                <View>
                  <View style={styles.ratingHeadingContainer}>
                    <Text style={styles.ratingHeadingText}>
                      Rate the product
                    </Text>
                    <Text style={styles.ratingQuestion}>
                      How did you find this product based on your usage?
                    </Text>
                  </View>
                  <StarRating _this={this} />
                  <ReviewFields _this={this} />
                </View>
              );
            } else {
              return <NoAccessAddReview _this={this} />;
            }
          }}
        </Query>
      </View>
    );
  }
}

const NoAccessAddReview = ({_this}) => {
  return (
    <View style={styles.notAllowedRatingContainer}>
      <Image
        resizeMethod={'resize'}
        source={{
          uri:
            'https://s3.ap-south-1.amazonaws.com/dentalkart-media/App/Not-Allowed-Review-image-.png',
        }}
        style={styles.notAllowedImage}
      />
      <Text style={styles.notAllowedHeading}>
        Haven't purchased this product?
      </Text>
      <Text style={styles.notAllowedText}>
        Sorry! You are not allowed to review this product since you haven't
        bought it on Dentalkart.
      </Text>
      <TouchableCustom
        underlayColor={'#ffffff10'}
        onPress={() => _this.props.navigation.navigate('Home')}>
        <View style={styles.continueShoppingButton}>
          <Text style={styles.continueShoppingButtonText}>
            Continue Shopping
          </Text>
        </View>
      </TouchableCustom>
    </View>
  );
};

const StarRating = ({_this}) => {
  return (
    <View style={styles.starRatingContainer}>
      <TouchableOpacity
        style={styles.starRating}
        onPress={() => _this.setState({star: 1})}>
        <Icon
          name="star"
          size={30}
          color={_this.state.star < 1 ? '#ddd' : '#0ecc2a'}
        />
        <Text>Horrible</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.starRating}
        onPress={() => _this.setState({star: 2})}>
        <Icon
          name="star"
          size={30}
          color={_this.state.star < 2 ? '#ddd' : '#0ecc2a'}
        />
        <Text>Bad</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.starRating}
        onPress={() => _this.setState({star: 3})}>
        <Icon
          name="star"
          size={30}
          color={_this.state.star < 3 ? '#ddd' : '#0ecc2a'}
        />
        <Text>Average</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.starRating}
        onPress={() => _this.setState({star: 4})}>
        <Icon
          name="star"
          size={30}
          color={_this.state.star < 4 ? '#ddd' : '#0ecc2a'}
        />
        <Text>Good</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.starRating}
        onPress={() => _this.setState({star: 5})}>
        <Icon
          name="star"
          size={30}
          color={_this.state.star < 5 ? '#ddd' : '#0ecc2a'}
        />
        <Text>Excellent</Text>
      </TouchableOpacity>
    </View>
  );
};

const ReviewFields = ({_this}) => {
  return (
    <View>
      <Mutation
        mutation={SUBMIT_REVIEW_QUERY}
        update={_this.postSubmitReview}
        onError={error => {
          showErrorMessage(`${error.message}. Please try again.`);
        }}>
        {(submitReview, {data, loading, error}) => {
          if (loading) {
            return <ActivityIndicator size="large" color="#343434" />;
          }
          return (
            <KeyboardAvoidingView
              behaviour="padding"
              style={styles.reviewFieldsWrapper}>
              <TextField
                label="Title"
                tintColor={SecondaryColor}
                labelHeight={15}
                value={_this.state.reviewTitle}
                onChangeText={title => _this.setState({reviewTitle: title})}
                keyboardType="default"
                autoCorrect={false}
                returnKeyType="next"
                fontSize={12}
                maxlength={50}
              />
              <TextInput
                value={_this.state.reviewDescription}
                onChangeText={description =>
                  _this.setState({reviewDescription: description})
                }
                keyboardType="default"
                autoCorrect={false}
                fontSize={12}
                multiline={true}
                numberOfLines={10}
                editable={true}
                placeholder="Write your description here..."
                underlineColorAndroid={SecondaryColor}
                style={{
                  textAlignVertical: 'top',
                  marginBottom: Platform.OS === 'ios' ? 20 : null,
                }}
              />
              <TouchableCustom
                underlayColor={'#ffffff10'}
                onPress={() => _this.submitReview(submitReview)}>
                <View style={styles.submitReviewButton}>
                  <Text style={styles.submitReviewButtonText}>Submit</Text>
                </View>
              </TouchableCustom>
            </KeyboardAvoidingView>
          );
        }}
      </Mutation>
    </View>
  );
};
