import gql from "graphql-tag";

const CUSTOMER_INFO = gql`
    query{
        customer{
            firstname
            lastname
            email
            gender{
                options{
                    label
                    value
                }
                active
            }
            taxvat
        }
    }
`;

export default CUSTOMER_INFO
