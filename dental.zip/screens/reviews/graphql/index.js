export {default as CHECK_PRODUCT_BOUGHT_QUERY} from './check_product_bought.gql'
export {default as SUBMIT_REVIEW_QUERY} from './submit_review.gql';
export { default as CUSTOMER_INFO_QUERY } from './info.gql';
