import React from 'react';
import Carousel from 'react-native-snap-carousel';
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Dimensions, StatusBar, Image } from 'react-native';
import { SafeAreaView } from 'react-navigation';
import { DeviceHeight, DeviceWidth, SecondaryColor } from '@config/environment';
import Icon from 'react-native-vector-icons/Ionicons';
import { WebView } from 'react-native-webview';
import Modal from 'react-native-modal';
import SwipeView from 'react-native-swipeview';

export default class News extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showNews: false,
      activeIndex: 0,
      carouselItems: [
        {
          image: "https://www.sciencemag.org/sites/default/files/styles/article_main_large/public/_vaccine_1280p.jpg",
          title: "US issues guidelines on COVID-19 vaccination after allergic reactions",
          description: "The US centers for disease control and prevention (CDC) has issued guidelines on COVID-19 vaccinations after allergic reactions. Anyone who had a severe reactions to a COVID-19 vaccine should not get the second dose, the agency said. Individuals with histories of severe allergic reactions to vaccines should consult their Doctors about COVID-19 shots.",
          bottomTitle: "Those with allergies to food can get the shot",
          bottomLinkText: "Tap to read what more CDC said"
        },
        {
          image: "https://www.sciencemag.org/sites/default/files/styles/article_main_large/public/_vaccine_1280p.jpg",
          title: "US issues guidelines on COVID-19 vaccination after allergic reactions",
          description: "The US centers for disease control and prevention (CDC) has issued guidelines on COVID-19 vaccinations after allergic reactions. Anyone who had a severe reactions to a COVID-19 vaccine should not get the second dose, the agency said. Individuals with histories of severe allergic reactions to vaccines should consult their Doctors about COVID-19 shots.",
          bottomTitle: "Those with allergies to food can get the shot",
          bottomLinkText: "Tap to read what more CDC said"
        },
        {
          image: "https://www.sciencemag.org/sites/default/files/styles/article_main_large/public/_vaccine_1280p.jpg",
          title: "US issues guidelines on COVID-19 vaccination after allergic reactions",
          description: "The US centers for disease control and prevention (CDC) has issued guidelines on COVID-19 vaccinations after allergic reactions. Anyone who had a severe reactions to a COVID-19 vaccine should not get the second dose, the agency said. Individuals with histories of severe allergic reactions to vaccines should consult their Doctors about COVID-19 shots.",
          bottomTitle: "Those with allergies to food can get the shot",
          bottomLinkText: "Tap to read what more CDC said"
        },
        {
          image: "https://www.sciencemag.org/sites/default/files/styles/article_main_large/public/_vaccine_1280p.jpg",
          title: "US issues guidelines on COVID-19 vaccination after allergic reactions",
          description: "The US centers for disease control and prevention (CDC) has issued guidelines on COVID-19 vaccinations after allergic reactions. Anyone who had a severe reactions to a COVID-19 vaccine should not get the second dose, the agency said. Individuals with histories of severe allergic reactions to vaccines should consult their Doctors about COVID-19 shots.",
          bottomTitle: "Those with allergies to food can get the shot",
          bottomLinkText: "Tap to read what more CDC said"
        },
        {
          image: "https://www.sciencemag.org/sites/default/files/styles/article_main_large/public/_vaccine_1280p.jpg",
          title: "US issues guidelines on COVID-19 vaccination after allergic reactions",
          description: "The US centers for disease control and prevention (CDC) has issued guidelines on COVID-19 vaccinations after allergic reactions. Anyone who had a severe reactions to a COVID-19 vaccine should not get the second dose, the agency said. Individuals with histories of severe allergic reactions to vaccines should consult their Doctors about COVID-19 shots.",
          bottomTitle: "Those with allergies to food can get the shot",
          bottomLinkText: "Tap to read what more CDC said"
        },
      ]
    }
  }

  onSwipeRight = () => {
    this.setState({ showNews: true });
  }

  _renderItem({ item, index }) {
    const config = {
      velocityThreshold: 0.3,
      directionalOffsetThreshold: 80
    };
    return (
      <SwipeView
        onSwipedLeft={() => this.onSwipeRight()}
        disableSwipeToRight={true}
        swipeDuration={1000}
        swipeToOpenPercent={10}
        rightOpenValue={-250}
        renderVisibleContent={() => !this.state.showNews ? <View style={{ width: '100%', height: '100%' }}>
          <View style={{ flex: 0.3 }}>
            <Image style={{ flex: 1 }} source={{ uri: item.image }} />
          </View>
          <View style={{ flex: 0.1, justifyContent: 'center', paddingStart: 10, paddingEnd: 10 }}>
            <Text numberOfLines={2} ellipsizeMode="tail" style={{ fontSize: 20 }}>{item.title}</Text>
          </View>
          <View style={{ flex: 0.3, justifyContent: 'center', paddingStart: 10, paddingEnd: 10 }}>
            <Text numberOfLines={9} ellipsizeMode="tail" style={{ fontSize: 18, color: 'gray' }}>
              {item.description}
                </Text>
          </View>
          <View style={{ flex: 0.1, justifyContent: 'center', paddingStart: 10, paddingEnd: 10 }}>
            <Text numberOfLines={1} ellipsizeMode="tail" style={{ fontSize: 14, color: '#696969' }}>
              Swipe left for more at The DentalKart.Com
                </Text>
          </View>
          <View style={{ flex: 0.2, paddingTop: 10, paddingStart: 10, paddingEnd: 10, backgroundColor: SecondaryColor }}>
            <Text numberOfLines={1} ellipsizeMode="tail" style={{ fontSize: 16, color: '#ffffff' }}>{item.bottomTitle}</Text>
            <Text numberOfLines={1} ellipsizeMode="tail" style={{ fontSize: 12, color: '#ffffff', paddingTop: 5 }}>{item.bottomLinkText}</Text>
          </View>
        </View> : null}
      />

    )
  }

  render() {
    return (
      <SafeAreaView style={{ flex: 1 }}>
        <StatusBar barStyle="default" />
        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', }}>
          <Carousel
            layout={"default"}
            ref={ref => this.carousel = ref}
            data={this.state.carouselItems}
            sliderWidth={DeviceWidth}
            sliderHeight={DeviceHeight}
            itemWidth={DeviceWidth}
            itemHeight={DeviceHeight}
            renderItem={(item, index) => this._renderItem(item, index)}
            inactiveSlideOpacity={1}
            inactiveSlideScale={1}
            vertical={true}
            swipeThreshold={70}
            onSnapToItem={index => this.setState({ activeIndex: index })} />
        </View>
        <Modal
          animationIn="slideInRight"
          animationOut="slideOutRight"
          deviceWidth={1}
          deviceHeight={1}
          isVisible={this.state.showNews}
        >
          <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.container}>
              <TouchableOpacity onPress={() => this.setState({ showNews: false })} style={styles.header}>
                <Icon name="ios-close-circle-outline" size={25} />
              </TouchableOpacity>
            </View>
            <View style={{ flex: 0.9 }}>
              <WebView
                source={{ uri: 'https://google.com/' }}
                startInLoadingState={true}
              />
            </View>
          </SafeAreaView>
        </Modal>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  container: { flex: 0.1, flexDirection: 'row', justifyContent: 'flex-end', backgroundColor: '#ffffff' },
  header: { flex: 0.2, justifyContent: 'center', alignItems: 'center' },
});