import Account from './account';

export { CUSTOMER_INFO_QUERY, APP_REVIEW_ACTION_MUTATION} from './modules/authentication';

export default Account;
