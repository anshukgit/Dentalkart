import gql from "graphql-tag";
import {ProductListingFragment} from '@screens/cart/graphql/fragments/product_listing_fragment.gql.js';

const APPLY_REWARD_POINTS = gql`
	mutation applyPoints($rewardpoints: Int!){
    	applyRewardPoints(rewardpoints: $rewardpoints)
    	{

			    ...ProductListingFragment

				prices {
	                grand_total{
	                    value
	                    currency
						currency_symbol
	                }
					rewardsdiscount{
						amount{
							value
							currency
							currency_symbol
						 }
						label
					}
	                subtotal_including_tax{
	                     value
	                     currency
						 currency_symbol
	                }

					discount{
					   amount{
						   value
						   currency
						   currency_symbol
					   }
					   label
					}
		        }
			}

	}
	${ProductListingFragment}
`;
export default APPLY_REWARD_POINTS;
