import React, { Component } from 'react';
import {
  View,
  Image,
  TouchableOpacity,
  Text,
  FlatList,
  Slider,
  Switch,
  TextInput,
  ToastAndroid, Pressable
} from 'react-native';
import { Query, Mutation } from 'react-apollo';
import { GET_CART_REWARDS_QUERY, APPLY_REWARD_POINTS } from '../../graphql';
import { PrimaryColor, SecondaryColor } from '@config/environment';
import styles from './apply_rewards.style';
import Loader from '@components/loader';
import { GET_NEW_CART } from '@screens/cart/graphql';
import SyncStorage from '@helpers/async_storage';
import { showErrorMessage, showSuccessMessage } from '../../../../../../helpers/show_messages';
import { Icon } from 'native-base'
export default class CartRewards extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isChecked: false
    };
  }
  render() {
    const { postUpdateCart } = this.props;
    return (
      <Query query={GET_CART_REWARDS_QUERY} fetchPolicy="cache-and-network">
        {({ data, loading, error }) => {
          if (error) {
            return showErrorMessage(`${error.message}. Please try again.`);
          }
          if (data && data.getRewardsCartInfo) {
            const info = data.getRewardsCartInfo;
            console.warn('info ====== > ', info)
            return <ApplyRewards info={info} postUpdateCart={postUpdateCart} />;
          } else {
            return <Loader loading={loading} transparent={true} />;
          }
        }}
      </Query>
    );
  }
}

class ApplyRewards extends Component {
  constructor(props) {
    super(props);
    this.state = {
      coins: parseInt(this.props.info.max_point_to_checkout),
      isReward: true,
      customer_cart_id: 0,
    };
  }
  async componentWillMount() {
    let customer_cart_id = await SyncStorage.get('customer_cart_id');
    this.setState({ customer_cart_id });
  }
  onApplyRewardsClick() {
    this.setState({ isChecked: !this.state.isChecked }, () => {

      if (this.state.isChecked) {
        coins: parseInt(this.props.info.max_point_to_checkout);
        applyRewards();
      }
      else {
        coins: 0;//parseInt(this.props.info.max_point_to_checkout);
        applyRewards();
      }
    });

  }
  render() {
    const { info, postUpdateCart } = this.props;
    const { coins, isReward } = this.state;

    const customer_cart_id = this.state.customer_cart_id;
    return (
      <View>

        {info.balance && parseInt(info.balance) > 0 && (

          <View style={styles.rewardsContainer}>
            <View style={styles.earnedTxtView}>
              <Text style={[styles.rewardsGainedText, {  }]}>
                {/* Earned Rewards {info.earn_points} {info.reward_term} with products in the order. */}
              Earned Rewards {info.earn_points} {info.reward_term} with products in the order.
      </Text>

              <Text style={styles.rewardsGainedInfo}>
                {info.reward_gain_info}
              </Text>
            </View>
            {/* <View style={{ width: '100%', height: 5, backgroundColor: colors.HexColor,marginHorizontal:5,marginHorizontal:-15 }}></View> */}
            <View style={styles.applyRewardsButtonView}>
              <Mutation
                mutation={APPLY_REWARD_POINTS}
                variables={{ rewardpoints: coins }}
                refetchQueries={() => {
                  return [
                    {
                      query: GET_NEW_CART,
                      variables: { cart_id: customer_cart_id },
                    },
                  ];
                }}
                onCompleted={() => {
                  showSuccessMessage('Rewards points applied successfully.');
                }}>
                {(applyRewards, { data, loading, error }) => {
                  if (loading) {
                    return <Loader loading={true} transparent={true} />;
                  }
                  return (
                    <TouchableCustom
                      onPress={() => {
                        this.setState({ isChecked: !this.state.isChecked }, () => {

                          if (this.state.isChecked) {
                            this.setState({ coins: parseInt(this.props.info.max_point_to_checkout) }, () => {
                              applyRewards();
                            });
                          }
                          else {
                            this.setState({ coins: 0 }, () => {
                              applyRewards();
                            });
                          }
                        });

                      }

                      }
                      underlayColor="#ffffff10">
                      <View style={styles.checkBoxMainView}>

                        <View style={[styles.checkBoxView, { borderColor: this.state.isChecked ? colors.blueColor : colors.otpBorder, }]} >
                          {this.state.isChecked ? <Icon name='check' type='AntDesign' style={{ fontSize: 12, color: colors.blueColor }} /> : null}
                        </View>
                        <Text style={styles.applyRewardTxt}>Apply reward {info.max_point_message}</Text>
                      </View>
                    </TouchableCustom>
                  );
                }}
              </Mutation>
            </View>
            {/* <View style={styles.checkBoxMainView}>
      
        <Pressable style={[styles.checkBoxView, { borderColor: this.state.isChecked ? colors.blueColor : colors.otpBorder, }]} 
        onPress={() => this.setState({ isChecked: !this.state.isChecked })}
        onPress={() => applyRewards()}
        >
          <Icon name='check' type='AntDesign' style={{ fontSize: 12, color: colors.blueColor }} /> 
        </Pressable>
        <Text style={{ fontSize: 12, color: '#292929', }}>Apply reward</Text>
      </View> */}

          </View>
        )}
      </View>
    );
  }
}
