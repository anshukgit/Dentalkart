import gql from "graphql-tag";

const CANCEL_ORDER = gql`
	mutation CancelOrder($increment_id: String!){
    	CancelOrder(increment_id: $increment_id)
	}
`;
export default CANCEL_ORDER;