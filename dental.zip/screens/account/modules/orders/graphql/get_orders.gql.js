import gql from "graphql-tag";

const GET_ORDERS = gql`
    {
        dkcustomerOrders{
            orders{
                can_cancel
                can_return
                grand_total
                id
                increment_id
                created_at
                status
                currency
                items{
                    name
                    price
                    sku
                    product_id
                    qty
                }
            }
        }
    }
`;

export default GET_ORDERS;
