export { default as GET_ORDER_DETAILS_QUERYGET_NEW_ORDER_DETAILS_VERSION_THREE_QUERY } from './get_orders_details_new.gql';
export { default as GET_ORDERS_QUERY} from './get_orders.gql';
export { default as TRACK_SHIPMENT_QUERY} from './track_shipment.gql';
export { default as CANCEL_ORDER} from './cancel_order.gql';
export {default as TRACK_BY_TRACK_NUMBER_QUERY} from './track_shipment_details.gql'