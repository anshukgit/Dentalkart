import React, { Component, useEffect } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Image,
    FlatList,
    TouchableHighlight,
    ToastAndroid,
    ScrollView,
    Alert, Dimensions
} from 'react-native';
import { Icon } from 'native-base';
import Header from '@components/header';
import styles from "./transit_details.style";
import { client } from '@apolloClient';
import { GET_ORDER_DETAILS_QUERYGET_NEW_ORDER_DETAILS_VERSION_THREE_QUERY, CANCEL_ORDER } from '../../graphql';
import { showErrorMessage } from '../../../../../../helpers/show_messages';
import Timeline from 'react-native-timeline-flatlist'
export default class transitDetails extends Component {

    constructor(props) {
        super(props);
        const fetchData = null;
        this.state = {
            orderDetailsData: null,
            orderDetailsLoader: false,
            orderDetailsError: false,
            orderArr: [],
            isModalVisibal: false,
            items: [],
            transDetails: '',
            tracking: [],
            TrackingData: [],
        }

    }



    getOrderDetailsData = async () => {
        const { navigation } = this.props;
        const orderId = navigation.getParam('orderId');
        const transDetails = navigation.getParam('transDetails');

        const { trackByTrackNumberV2 } = transDetails;
     
        const transData = trackByTrackNumberV2;
   console.warn('trans data : ' , transData);
            if (transData.response) {
               var trackeArr = transData.response.scan;
                if (trackeArr) {
                    trackeArr.map((val) => {
                        val.title = val.status_detail;
                        val.description = val.location;
                      
                    })
                   
                    this.setState({ tracking: trackeArr })
                }
            }
      
        this.setState({ transDetails: transDetails });
        try {
            this.setState({ orderDetailsLoader: true })
            const { data } = await client.query({
                query: GET_ORDER_DETAILS_QUERYGET_NEW_ORDER_DETAILS_VERSION_THREE_QUERY,
                fetchPolicy: 'network-only',
                variables: { order_id: orderId }

            });
            if (data && data.OrderDetailsV3) {
                // this.getRefetchRes();
                if (this.state.orderDetailsError) {
                    this.setState({ orderDetailsError: false })
                }
                this.setState({ orderDetailsData: data, orderDetailsLoader: false });

            }
        }
        catch (e) {
            console.log("rderError", e);
            this.setState({ orderDetailsLoader: false })
            this.setState({ orderDetailsError: true })
            showErrorMessage(e.message);
        }

    }

    componentDidMount() {

        this.getOrderDetailsData();
    }


    addressMapping() {
        const { OrderDetailsV3 } = this.state.orderDetailsData;
        const order = OrderDetailsV3.shipping_address
        return (
            Object.entries(order).map(([key, value]) => {
                return value ? <Text style={styles.address}>{value} , </Text> : null
            })
        )
    }


    render() {
        const { trackByTrackNumberV2 } = this.state.transDetails;
        // const { error } = trackByTrackNumberV2;
        const transData = trackByTrackNumberV2;
       
        return (
            <View style={{ backgroundColor: '#EBFBFF', }}>
                <Header
                    back
                    heading={'Transit Details'}
                    navigation={this.props.navigation}
                />
                <View style={styles.shippingAddressView}>
                    <Text style={styles.shippingAddressText}>
                        Shipping Address
            </Text>


                    {this.state.orderDetailsData ?
                        <Text style={{ marginTop: 3,paddingBottom:3 }}>
                            {this.addressMapping()}
                        </Text>
                        :
                        null}
                </View>

                {transData ?
                    transData.error ?
                        <View style={styles.shippingAddressView}>
                            <Text style={styles.shippingAddressText}>
                                We have dispatched your order through <Text style={{ color: '#42A9E2', fontWeight: 'bold' }}>{transData.error.transporter}</Text>. Our system has not updated details yet, but you can check the same at <Text style={{ color: '#42A9E2', fontWeight: 'bold' }}>{transData.error.transporter} Website</Text>. Find below the details to track your order:
                         </Text>
                            <Text style={{ marginTop: 10 }}>Website URL <Text style={{ color: '#42A9E2', fontWeight: 'bold' }}>{transData.error.url}</Text></Text>
                            <Text style={{ marginTop: 5 }}>Track No. <Text style={{ color: '#42A9E2', fontWeight: 'bold' }}>{transData.error.track_number}</Text></Text>

                        </View>
                        :
                        null
                    :
                    null}

                {this.state.tracking.length > 0?
                    <View style={{  height: this.state.tracking.length * 110, paddingHorizontal: 20, backgroundColor: '#fff', marginBottom: 5,paddingTop:8}}>
                        <View style={{ width: '100%',  height: this.state.tracking.length * 110 }}>
                            <Timeline
                                data={this.state.tracking}
                                circleSize={18}
                                innerCircle={'icon'}
                                iconStyle={{ width: '50%' }}
                                circleColor={colors.orangeBtn}
                                lineColor={colors.orangeBtn}
                                listViewStyle={{}}
                                descriptionStyle={{ color: 'gray', top: -18,fontSize:10 }}
                                titleStyle={{ top: -10,fontSize:12.5,color:colors.black }}
                                options={{
                                    style: { paddingTop: 5, right: 0, },
                                    showsVerticalScrollIndicator: false
                                }}
                                showTime={true}
                             timeStyle={{width:55,fontSize:10,top:5}}
                            />

                        </View>


                    </View>

                    :
                    null
                }


            </View >
        )
    }

}
