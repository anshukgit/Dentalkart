import React, { Component, useEffect } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Image,
    FlatList,
    TouchableHighlight,
    ToastAndroid,
    ScrollView,
    Linking, Dimensions, Platform
} from 'react-native';
import { GET_ORDER_DETAILS_QUERYGET_NEW_ORDER_DETAILS_VERSION_THREE_QUERY, CANCEL_ORDER } from '../../graphql';
import Timeline from 'react-native-timeline-flatlist'
import { Icon } from 'native-base';
import Header from '@components/header';
import styles from "./track_details.style";
import { AirbnbRating } from 'react-native-ratings';
import { newclient, client } from '@apolloClient';
import { NavigationActions } from 'react-navigation';
import { TRACK_BY_TRACK_NUMBER_QUERY } from '../../graphql';
import { showErrorMessage } from '../../../../../../helpers/show_messages';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
export default class Tracking extends Component {

    constructor(props) {
        super(props);
        const fetchData = null;
        this.state = {
            date: 'Dec 29, 2020',
            rating: 0,
            trackingNo: 781797056843,
            tracking: [],
            TrackingData: null,
            transDetails: '',
            cartItem: [{ pName: 'Finger Pulse oximete with OLED display', qty: '02', totalprice: '2.00', rewards: '02', unitPrice: '2.00' },
            { pName: 'ChlorHex Mouthwash', type: 'Manufacture: Waldent', qty: '02', totalprice: '2.00', rewards: '02', unitPrice: '2.00' }],
        }

    }

    getOrderDetailsData = async () => {
        const { navigation } = this.props;
        const orderId = navigation.getParam('orderId');
        try {
            const { data } = await client.query({
                query: GET_ORDER_DETAILS_QUERYGET_NEW_ORDER_DETAILS_VERSION_THREE_QUERY,
                fetchPolicy: 'network-only',
                variables: { order_id: orderId }

            });
            if (data && data.OrderDetailsV3) {
                const { OrderDetailsV3 } = data;
                this.setState({ TrackingData: OrderDetailsV3 });//, orderDetailsLoader: false });

            }
        }
        catch (e) {
            console.log("rderError", e);
            //   this.setState({ orderDetailsLoader: false })
            //   this.setState({ orderDetailsError: true })
            showErrorMessage(e.message);
        }

    }
    async componentDidMount() {
        const { navigation } = this.props;
        const data = navigation.getParam('data');
        const prvPage = navigation.getParam('prvPage');
        const orderid = navigation.getParam('orderId');
        this.setState({ TrackingData: data })
        if (prvPage == 'orderList') {
            console.warn('yes');
            this.getOrderDetailsData();
        }
        else {


            var trackeArr = data.status_history;
            var ind = -1;
            for (var i = 0; i < trackeArr.length; i++) {
                if (trackeArr[i].current == true) {
                    ind = i;
                    break;
                }
            }
            
            trackeArr.map((val, index) => {
                val.title = val.status;
                val.description = val.date ? ('- ' + val.status + ' on ' + val.date) : '';
                val.isProcess = index <= ind && ind != -1 ? true : false;
                var lineFlg = index < ind && ind != -1 ? true : false;
                val.lineColor =  lineFlg?colors.orangeBtn:'#C6D2DE';
                val.circleColor =  val.isProcess?colors.orangeBtn:'#2B3E56';
                val.innerCircle = 'dot';
                if(val.isProcess && index == ind)
                    val.icon = <Icon name={'circle-o'} type={'FontAwesome'} style={{fontSize:15,color:'#fff',}} />
                else if(val.isProcess && index < ind)    
                  val.icon =<Icon name={'check'} type={'FontAwesome5'} style={{fontSize:11,color:'#fff',}} />
                else
                val.icon =null
            });



            this.setState({ tracking: trackeArr })
            var tracknum = data.tracking_number;
            var transpotnum = data.transporter;
            console.warn('result Data................... : ',this.state.tracking);
            if (tracknum) {
                try {
                    const { data, loading, error } = await newclient.query({
                        query: TRACK_BY_TRACK_NUMBER_QUERY,
                        fetchPolicy: 'network-only',
                        variables: { order_id: orderid, track_number: tracknum, courier: transpotnum }

                    });
                    this.setState({ transDetails: data })
                    // if (data && data.fetchOrder && data.fetchOrder.order_id) {
                    //     this.setState({ fetchOrderRes: data.fetchOrder })
                    //     console.log('refetchQuery', data.fetchOrder)
                    // }
                }
                catch (e) {
                    console.warn('error  : ', e);
                    showErrorMessage(e.message);
                }
            }
        }
    }

    ratingCompleted(rating) {
        this.setState({ rating: rating })
        Linking.openURL(Platform.OS == 'android' ? 'https://play.google.com/store/apps/details?id=com.vasadental.dentalkart' : 'https://apps.apple.com/app/dentalkart/id1382207992?ls=1')
    }
    onItemPrice(data) {
        let price = data.price * data.qty_ordered

        price = price.toFixed(2)
        return (
            <Text style={styles.qtyTextCount}> {price}</Text>
        )
    }
    renderCircle(rowData, sectionID, rowID) {
        console.warn('row data infor : ', rowData)
        return (
            <View style={{ width: 15, height: 15, borderRadius: 15, backgroundColor: rowData.isProcess ? colors.orangeBtn : 'grey', left: -(windowWidth*68.5/100) }}>
            </View>
        )
    }
    renderCircle1(rowData, sectionID, rowID) {
        console.warn('row data infor : ', rowData)
        return (
            <View style={{ width: 15, height: 100, borderRadius: 15, backgroundColor: rowData.isProcess ? colors.orangeBtn : 'grey', }}>
            </View>
        )
    }
    cartItemMapping() {
        const { navigation } = this.props;
        const TrackingData = navigation.getParam('data');

        const trakingItems = TrackingData ? TrackingData.items : []
        if (trakingItems.length > 0) {
            return trakingItems.map((data, index) => {
                return (
                    <View style={[styles.cartItemMappingMainView,]}>
                        <View style={styles.cartItemImg}>
                            <Image source={require('../../../../../../assets/android-icon.png')} style={{ width: '100%', height: '100%' }} resizeMode={'contain'} />
                        </View>
                        <View style={styles.mappingDetailView}>
                            <Text style={styles.prodctName}>{data.name}</Text>
                            <View style={{ width: "85%", height: 20, flexDirection: 'row', justifyContent: 'space-between' }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={[styles.qtyText, { width: '52.5%' }]}>Quantity:</Text>
                                    <Text style={[styles.qtyTextCount,]}>{data.qty_ordered}</Text>
                                </View>
                                <Text><Text style={styles.qtyText}>Unit Price : </Text><Icon name="rupee" type="FontAwesome" style={{ fontSize: 11, color: colors.black }} />
                                    {/* <Text style={styles.qtyTextCount}></Text> */}
                                    {data.price}
                                </Text>
                            </View>
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Text style={[styles.qtyText, { width: '26.5%' }]}>Total price:</Text>
                                <Icon name="rupee" type="FontAwesome" style={{ fontSize: 10, color: colors.black }} /><Text style={styles.qtyTextCount}> {this.onItemPrice(data)}</Text>
                            </View>
                            <View style={{ flexDirection: 'row', alignItems: 'center', height: 22, }}>
                                <Text style={[styles.qtyText, { width: '26.5%', }]}>Rewards:</Text>
                                <Text style={styles.qtyTextCount}>{data.rewards}</Text>
                            </View>
                        </View>
                    </View>
                )
            })
        }
    }
    render() {
        const { navigation } = this.props;
        const orderId = navigation.getParam('orderId');
        return (
            <View style={{ backgroundColor: '#EBFBFF', flex: 1 }}>
                <Header
                    back
                    heading={'Tracking'}
                    navigation={this.props.navigation}
                />
                <ScrollView style={{ width: '100%', height: Dimensions.get('window').height - 80, borderColor: 'red' }}>
                    <View style={{ width: '100%' }}>
                        {this.state.TrackingData ?
                            <View style={{ height: 40, backgroundColor: '#fff', justifyContent: 'center', paddingHorizontal: 20, }}>
                                {this.state.TrackingData.tracking_number == null ?
                                    <Text style={{ fontSize: 12, }}>Status: {this.state.TrackingData.status}</Text> :
                                    <Text style={{ fontSize: 12, }}>Tracking No: {this.state.TrackingData.tracking_number}</Text>
                                }
                            </View>
                            :
                            null
                        }
                        {this.state.tracking.length>0 ?
                            <View style={{ height: this.state.tracking.length * 65, paddingHorizontal: 20, backgroundColor: '#fff', marginBottom: 5 }}>
                                <View style={{ width: '100%', height: this.state.tracking.length * 65, }}>
                                    <Timeline
                                        data={this.state.tracking}
                                        circleSize={18}
                                        innerCircle={'icon'}
                                        iconStyle={{ width: '50%' }}
                                        circleColor={colors.orangeBtn}
                                        lineColor={colors.orangeBtn}
                                        listViewStyle={{}}
                                        descriptionStyle={{ color: 'gray', top: -18, fontSize: 10 }}
                                        titleStyle={{ top: -10, fontSize: 12.5, color: colors.black }}
                                        options={{
                                            style: { paddingTop: 5, right: 55, },
                                            showsVerticalScrollIndicator: false
                                        }}
                                    />
                                    {this.state.TrackingData ?
                                        this.state.TrackingData.tracking_number && this.state.TrackingData.delivereddate ?
                                            <Text style={{ fontSize: 11, left: -10, textAlign: 'center', top: -10 }}> <Text >Expected date of Delivery - </Text><Text style={{ color: colors.blueColor }}>{this.state.TrackingData.delivereddate}</Text></Text>
                                            :
                                            null

                                        :
                                        null
                                    }
                                </View>
                                {this.state.TrackingData && this.state.transDetails ?
                                    this.state.TrackingData.tracking_number ?
                                        <TouchableOpacity style={{ top: 8, alignItems: 'flex-end', position: 'absolute', right: 15 }} onPress={() => { console.warn('ontrasit btn click'); this.props.navigation.navigate('transitDetails', { orderId: orderId, transDetails: this.state.transDetails }) }}>
                                            <Text style={{ fontSize: 12, color: colors.blueColor, }}>Transit details</Text>
                                        </TouchableOpacity>
                                        :
                                        null
                                    :
                                    null}
                            </View>
                            :
                            null}
                        <View style={styles.itemsinOrderView}>
                            <Text style={styles.itemsinOrderTxt}>Items in this order</Text>
                        </View>

                        {this.state.TrackingData ?
                            this.cartItemMapping()
                            :
                            null
                        }

                        <View style={{ width: '100%', height: 70, flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white, paddingHorizontal: 20 }}>
                            <View style={{ width: '60%', height: '100%', justifyContent: 'space-around', paddingVertical: 15 }}>
                                <Text style={{ color: colors.black, fontSize: 14, }}>Don’t forget to rate</Text>
                                <Text style={{ color: colors.productHeaderText, fontSize: 12, }}>Give your opinion about our app</Text>
                            </View>
                            <View style={{ width: '40%', justifyContent: 'flex-start', right: 20 }}>
                                <AirbnbRating
                                    count={5}
                                    defaultRating={this.state.rating}
                                    size={18}
                                    showRating={false}
                                    onFinishRating={(rating) => this.ratingCompleted(rating,)}
                                    style={{}}
                                />
                            </View>
                        </View>

                    </View>
                </ScrollView>
            </View >
        )
    }

}
