import {StyleSheet} from 'react-native';
import {DeviceWidth, PrimaryColor, SecondaryColor} from '@config/environment';
import colors from '@config/colors';
// import { screenPadding, moderateScale, writeLog, verticalScale, responsiveHeight, responsiveFontSize, responsiveWidth } from '@config/functions';
export default styles = StyleSheet.create({
    orderIdWrapper: {
		padding: 10
	},
	card: {
		backgroundColor: '#fff',
        borderRadius: 3,
        marginVertical: 5,
        marginHorizontal: 8,
        elevation: 1,
		shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
	},
	productImageWrapper: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		width: DeviceWidth/3
	},
	productImage: {
		width: 60,
		height: 60
	},
	productDetailWrapper: {
		width: DeviceWidth - (DeviceWidth/3)
	},
	imageDetailsWrapper: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		padding: 5
	},
	productIndex: {
		color: '#21212150',
		fontSize:12
	},
	productDetailValue: {
		color: '#212121'
	},
	customizedProductDetailWrapper: {
		flexDirection: 'row'
	},
	customizedProductDetails: {
		color: '#21212180',
		fontSize: 12
	},
	cardHeader: {
		borderBottomColor: '#ddd',
		padding: 5,
		borderBottomWidth: 0.5
	},
	header: {
		color: '#212121'
	},
	cardBodyWrapper: {
		padding: 5
	},
	twoFields: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		marginBottom: 7
	},
	field: {
		color: '#21212180'
	},
	cancelButtonWrapper: {
		backgroundColor: PrimaryColor,
		margin: 7,
		borderRadius: 3,
		padding: 10,
		justifyContent: 'center',
		alignItems: 'center'
	},
	cancelButton: {
		color: '#fff',
		fontSize: 14
	},
	productShipmentContainer: {
		marginVertical: 15,
		elevation: 1.5,
		shadowColor: '#bfbfbf',
		shadowOffset: {
	      height: 1,
		  width: 1
	    },
		shadowOpacity: 1,
		shadowRadius: 5,
		backgroundColor: '#fff'
	},
	productsContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		paddingVertical: 5,
		paddingHorizontal: 10
	},
	shipmentCardHeading: {
		color: SecondaryColor,
		fontSize: 14
	},
	trackButton: {
		alignItems: 'center',
		margin: 10,
		borderRadius: 3,
		borderColor: SecondaryColor,
		borderWidth: 1
	},
	trackButtonText: {
		paddingVertical: 5,
		color: SecondaryColor
	},
	rewardWrapper: {
		flexDirection: 'row',
		alignItems: 'center'
	},
	rewardIcon: {
		width: 18,
		height: 18
	},
	rewardPoints: {
		color: '#282828'
	},
	rewardsInfoCard: {
		flex: 1,
		flexDirection: 'row',
		padding: 5,
		alignItems: 'center',
		justifyContent: 'center',
		elevation: 1,
		marginBottom: 5,
		backgroundColor: '#fff',
		marginHorizontal: 8,
		shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
	},
	rewardPointsContainer: {
		alignItems: 'center',
        flex: 1
	},
	pointsWrapper: {
		flexDirection: 'row',
		alignItems: 'center',
        height: 15,
        marginVertical: 5
	},
	borderRight: {
		borderRightColor: '#efefef',
		borderRightWidth: 1
	},

	orderSummarySUbView: { height: 60, marginVertical: 8, width: '100%', backgroundColor: '#fff', paddingHorizontal:15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
	orderSummaryText: { fontSize: 14, color:'#000' },
	moadlWhiteBgView: { width: '100%', minHeight: 52,paddingBottom:10, backgroundColor: colors.white, paddingHorizontal:15, marginBottom: 8 },
	packTextMainView: { width: '100%', height: 40, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
	packageImgView: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
	itemCountView: { width: 100, height: 25, borderRadius: 15, backgroundColor: colors.HexColor, justifyContent: 'center', alignItems: 'center', right: 5 },
	itemCountText: { fontSize: 11,fontWeight:'400', color: colors.black },
	trackingTxtView: { width: '100%', height: 30, justifyContent: 'center', paddingHorizontal: 5 },
	trackingTxt: { fontSize: 13, color: colors.productHeaderText },
	deliveryTxtView: { width: '100%', height: 30, bottom: 1, justifyContent: 'center', paddingHorizontal: 5 },
	deliveryTxt: { fontSize: 12.5, color: colors.black },
	btnView: { width: '100%', height: 42, justifyContent: 'flex-end', paddingHorizontal: 5},
	trakBtn: { width: 180, height: 35, borderRadius: 3, backgroundColor: colors.SummerSky, justifyContent: 'center', alignItems: 'center' ,}
});
