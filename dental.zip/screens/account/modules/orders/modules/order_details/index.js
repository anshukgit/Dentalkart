import React, { Component, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  FlatList,
  TouchableHighlight,
  ToastAndroid,
  ScrollView,
  Alert,
} from 'react-native';
import { GET_ORDER_DETAILS_QUERYGET_NEW_ORDER_DETAILS_VERSION_THREE_QUERY, CANCEL_ORDER } from '../../graphql';
import { TRACK_BY_TRACK_NUMBER_QUERY } from '../../graphql';
import Header from '@components/header';
import TouchableCustom from '@helpers/touchable_custom';
import styles from './order_details.style';
import { client } from '@apolloClient';
import { NavigationActions } from 'react-navigation';
import Loader from '@components/loader';
import { fireAnalyticsEvent } from '@helpers/firebase_analytics';
import { DentalkartContext } from '@dentalkartContext';
import { showErrorMessage } from '../../../../../../helpers/show_messages';
import { FETCH_ORDER_DETAILS_QUERY } from '@screens/payment/graphql';
import { RetryPaymentButton } from '@screens/payment/retryWithRazorpayPopUp';
import { Icon } from 'native-base';
import Modal from "react-native-modal";
export const RefetchOrderFiveTimes = (props) => {
  let refetchCounter = 0;
  let interval = setInterval(() => {
    refetchCounter = refetchCounter + 1;
    if (refetchCounter === 5) {
      clearInterval(interval)
    }
    props.getRefetchRes();
  }, 30000)

  useEffect(() => {
    return () => {
      clearInterval(interval)
    }
  })

  return (
    <View style={{ padding: 7 }}>
      <Text style={{ fontWeight: 'bold' }}> Please wait loading... </Text>
      <Text style={{ padding: 5, fontSize: 12 }}>we are verifying your payment status. </Text>
    </View>
  )
}

export const RetryOrderComponent = (props) => {
  const paymentData = { ...props.retryPaymentData }
  return (
    <View>
      <RetryPaymentButton paymentData={paymentData} navigation={props.navigation} />
    </View>
  )
}



export default class OrderDetails extends Component {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    const fetchData = null;
    this.state = {
      fetchOrderRes: fetchData,
      orderDetailsData: null,
      orderDetailsLoader: false,
      orderDetailsError: false,
      orderArr: [],
      isModalVisibal: false,
      items: []
    };

  }

  triggerScreenEvent = _ => {
    const { userInfo } = this.context;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Order Detail',
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };

  getRefetchRes = async () => {
    const { navigation } = this.props;
    const orderId = navigation.getParam('orderId', 'No-ID');
    try {
      const { data, loading, error } = await client.query({
        query: FETCH_ORDER_DETAILS_QUERY,
        fetchPolicy: 'network-only',
        variables: { order_id: orderId, rzp_payment_id: '', rzp_order_id: '', rzp_signature: '' }

      });
      if (data && data.fetchOrder && data.fetchOrder.order_id) {
        this.setState({ fetchOrderRes: data.fetchOrder })
        console.log('refetchQuery', data.fetchOrder)
      }
    }
    catch (e) {
      showErrorMessage(e.message);
    }

  }

  getOrderDetailsData = async () => {
    const { navigation } = this.props;
    const orderId = navigation.getParam('orderId');

    try {
      this.setState({ orderDetailsLoader: true })
      const { data } = await client.query({
        query: GET_ORDER_DETAILS_QUERYGET_NEW_ORDER_DETAILS_VERSION_THREE_QUERY,
        fetchPolicy: 'network-only',
        variables: { order_id: orderId }

      });
      if (data && data.OrderDetailsV3) {
        this.getRefetchRes();
        if (this.state.orderDetailsError) {
          this.setState({ orderDetailsError: false })
        }
        this.setState({ orderDetailsData: data, orderDetailsLoader: false });

      }
    }
    catch (e) {
      console.log("rderError", e);
      this.setState({ orderDetailsLoader: false })
      this.setState({ orderDetailsError: true })
      showErrorMessage(e.message);
    }

  }

  componentDidMount() {
    this.triggerScreenEvent();
    this.getOrderDetailsData();
  }
  cancelOrder = async orderId => {
    const { reset } = this.props.navigation;
    Alert.alert(
      'Cancel Order',
      'Sure you want to cancel the order',
      [
        {
          text: 'No',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'YES',
          onPress: async () => {
            try {
              const { data } = await client.mutate({
                mutation: CANCEL_ORDER,
                variables: { increment_id: orderId },
              });
              showErrorMessage('Order Cancelled Successfully!');
              reset(
                [
                  NavigationActions.navigate({ routeName: 'Home' }),
                  NavigationActions.navigate({ routeName: 'OrdersList' }),
                ],
                1,
              );
            } catch (error) {
              showErrorMessage(error.message);
            }
          },
        },
      ],
      { cancelable: false },
    );
  };
  trackOrder(order, item) {
    const { navigate } = this.props.navigation,
      _this = this.props._this;
    console.log(item);
    let params = {};
    if (item.id) {
      params = {
        order_id: item.id,
      };
    } else {
      params = {
        order_id: order.order_id,
      };
    }
    navigate('TrackingDetails', { params: params });
  }
  products(order, item, index) {
    return (
      <TouchableHighlight underlayColor={'#fff'}>
        <View style={styles.card}>
          <View style={styles.imageDetailsWrapper}>
            <View style={styles.productDetailWrapper}>
              <Text style={styles.productIndex}>PRODUCT-{index + 1}</Text>
              <Text style={styles.productDetailValue}>{item.name}</Text>
              {item.options ? (
                <FlatList
                  data={item.options}
                  listKey={(item, index) => index.toString()}
                  keyExtractor={(item, index) => 'option-' + index.toString()}
                  renderItem={({ item, index }) => (
                    <View style={styles.customizedProductDetailWrapper}>
                      <Text style={styles.customizedProductDetails}>
                        {item.label}:{' '}
                      </Text>
                      <Text style={styles.customizedProductDetails}>
                        {item.value}
                      </Text>
                    </View>
                  )}
                />
              ) : null}
              <Text style={styles.productDetailValue}>
                Quantity: {item.qty}
              </Text>
              <Text style={styles.productDetailValue}>
                Price: {order.currency} {item.price}
              </Text>
              {item.rewardpoints ? (
                <View style={styles.rewardWrapper}>
                  <Text>Rewards:</Text>
                  <Image
                    resizeMethod={'resize'}
                    source={{ uri: order.rewards.reward_icon }}
                    style={styles.rewardIcon}
                  />
                  <Text style={styles.rewardPoints}>{item.rewardpoints}</Text>
                </View>
              ) : null}
            </View>
            <View style={styles.productImageWrapper}>
              <Image
                resizeMethod={'resize'}
                source={{ uri: item.thumbnail }}
                style={styles.productImage}
              />
            </View>
          </View>
        </View>
      </TouchableHighlight>
    );
  }

  orderMapping() {
    const { OrderDetailsV3 } = this.state.orderDetailsData;
    const order = OrderDetailsV3.packages;
    const orderId = OrderDetailsV3.order_id
   return order.map((data, index) => {

      return (
        <View style={styles.moadlWhiteBgView} >
          <View style={styles.packTextMainView}>
            <View style={styles.packageImgView}>
              <Image source={require('../../../../../../assets/packageImg.png')} style={{ width: 40, height: 20, right: 3 }} resizeMode={'contain'} />
              <Text style={{ fontSize: 14, color: '#000' }}>
                Package {index + 1}
              </Text>
            </View>

            <TouchableOpacity style={styles.itemCountView}>
              <Text style={styles.itemCountText}>{data.items.length} items in it</Text>
            </TouchableOpacity>
          </View>

          {data.tracking_number == null ?
            null
            :
            <View style={styles.trackingTxtView}>
              <Text style={styles.trackingTxt}>Tracking No: {data.tracking_number}  </Text>
            </View>
          }
          <View style={styles.trackingTxtView}>
            <Text style={styles.trackingTxt}>status: {data.status}  </Text>
          </View>
          {data.delivereddate == null ? null :
            <View style={styles.deliveryTxtView}>
              <Text style={styles.deliveryTxt}>Expected delivery date {data.delivereddate}</Text>
            </View>
          }
          <View style={styles.btnView}>
            <TouchableOpacity style={styles.trakBtn} onPress={() => this.onTrackBtnPress(data, orderId)}>
              <Text style={{ color: '#fff', fontSize: 14 }}>Track</Text>
            </TouchableOpacity>
          </View>

        </View>
      )
    })
  }

  dispItemList(items) {
    this.setState({ items: items }, () => { this.setState({ isModalVisibal: true }) })

  }

  dispItemListMappling() {
    return this.state.items.map((data, index) => {
      return (
        <View style={{ flexDirection: 'row', paddingBottom: 5, borderBottomWidth: 0.5 }}>
          <View style={{ width: '30%', height: 80, justifyContent: 'center', alignItems: 'center' }}>
            <Image source={require('../../../../../../assets/android-icon.png')} resizeMode='contain' style={{ width: '80%', height: '80%' }} />
          </View>
          <View style={{ width: '70%', height: 70, justifyContent: 'center' }}>
            <Text style={{ fontSize: 13 }}>{data.name}</Text>
            <View style={{ flexDirection: 'row', top: 10 }}>
              <Text style={{ fontSize: 11 }}>Qty: {data.qty_ordered}</Text>
              <Text style={{ fontSize: 11, left: 30 }}>Price: {data.price}</Text>
            </View>

          </View>

        </View>
      )
    })
  }

  onTrackBtnPress(data) {
    const { OrderDetailsV3 } = this.state.orderDetailsData;
    const order = OrderDetailsV3;
    this.props.navigation.navigate('trackDetails', { data: data, orderId: order.order_id })
  }
  render() {
    const { userInfo } = this.context;
    const orderId = this.props.navigation.getParam('orderId', 'No-ID');
    const can_cancel = this.props.navigation.getParam('can_cancel');
    const { orderDetailsData, orderDetailsLoader, orderDetailsError } = this.state;
    const customerEmail = userInfo ? userInfo.customer.email : '';

    if (orderDetailsData) {
      const { OrderDetailsV3 } = orderDetailsData;
      const order = OrderDetailsV3;
      console.log("order in render", OrderDetailsV3);
      return (
        <View style={{ backgroundColor: '#EBFBFF' }}>
          <Header
            back
            heading={'#' + order.order_id}
            navigation={this.props.navigation}
          />
          <View style={styles.mainView}>

            <TouchableOpacity style={styles.orderSummarySUbView} onPress={() => this.props.navigation.navigate('orderSummary', { orderId: orderId })} >
              <Text style={styles.orderSummaryText}>Order Summary</Text>
              <Icon name='right' type='AntDesign' style={{ fontSize: 18, right: 10 }} />
            </TouchableOpacity>
            <ScrollView showsVerticalScrollIndicator={false}>
              {this.orderMapping()}
            </ScrollView>
          </View>
          <Modal isVisible={this.state.isModalVisibal}
            animationInTiming={1000}
            animationOutTiming={1000}
            transparent={true}
            animationIn="fadeIn"
            animationOut="fadeOut"
            // onSwipeComplete={() => this.setState({ isModalVisibal: false })}
            style={{ margin: 0, justifyContent: "center", alignItems: 'center' }}
          >
            <View style={{ minHeight: 130, backgroundColor: '#fff', borderRadius: 10, width: '90%', paddingHorizontal: 5, paddingVertical: 8 }}>

              <View style={{ height: 40, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }} >
                <TouchableOpacity style={[styles.trakBtn, { left: 5 }]} onPress={() => this.onTrackBtnPress()}>
                  <Text style={{ color: '#fff', fontSize: 14 }}>Track</Text>
                </TouchableOpacity>
                <TouchableOpacity style={{ width: 35, height: 35, justifyContent: 'center', alignItems: 'flex-end' }} onPress={() => this.setState({ isModalVisibal: false })}>
                  <Icon name='close' type='AntDesign' style={{ fontSize: 23 }} />
                </TouchableOpacity>
              </View>

              <ScrollView>
                <View style={{ width: '100%', }}>
                  {this.dispItemListMappling()}
                </View>

              </ScrollView>
            </View>

          </Modal>
        </View>
      )
    }
    else if (orderDetailsLoader) {
      return <Loader loading={true} transparent={true} />;
    }
    else if (orderDetailsError) {
      return <Text>Something went wrong please try agin later.</Text>;
    }
    else {
      return <Text>NO data in rendered.</Text>
    }
  }
}
