import React, {Component} from 'react';
import {
  View,
  Text,
  ActivityIndicator,
  FlatList,
  ToastAndroid,
  Image,
} from 'react-native';
import {Query} from 'react-apollo';
import {GET_ORDERS_QUERY} from '../../graphql';
import OrderCard from '../order_card';
import Header from '@components/header';
import Styles from './order_list.style';
import Loader from '@components/loader';
import {DentalkartContext} from '@dentalkartContext';
import {fireAnalyticsEvent} from '@helpers/firebase_analytics';
import {showErrorMessage} from '../../../../../../helpers/show_messages';

export const EmptyOrders = () => {
  return (
    <View style={Styles.wrapper}>
      <Text style={Styles.textHeading}>{"It's Empty Here !"}</Text>
      <Image
        source={{
          uri:
            'https://s3.ap-south-1.amazonaws.com/dentalkart-media/App/noOrders.png',
        }}
        style={Styles.emptyImage}
      />
      <Text style={Styles.textAfterImage}>
        You have not placed any order till now. Start ordering!
      </Text>
    </View>
  );
};

export default class OrdersList extends Component {
  static contextType = DentalkartContext;
  triggerScreenEvent = _ => {
    const {userInfo} = this.context;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Order List',
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };
  componentDidMount() {
   
    this.triggerScreenEvent();
  }
  render() {
    return (
      <View style={{backgroundColor: '#fff', flex: 1}}>
        <Header back heading="My Orders" navigation={this.props.navigation} />
        <Query
          query={GET_ORDERS_QUERY}
          fetchPolicy="network-only"
          onError={error => {
            showErrorMessage(`${error.message}. Please try again.`);
          }}>
          {({data, loading, error}) => {
          
            if (loading) {
              return <Loader loading={true} transparent={true} />;
            }
            if (error) {
              return <Text>Somethig went wrong. Try Again.</Text>;
            }
            if (data.dkcustomerOrders) {
              const customerOrders = data.dkcustomerOrders.orders;
              return (
                <View>
                  <FlatList
                    data={customerOrders}
                    renderItem={({item, index}) => (
                      <OrderCard
                        navigation={this.props.navigation}
                        item={item}
                        _this={this}
                      />
                    )}
                    keyExtractor={(item, index) => JSON.stringify(item.id)}
                    initialNumToRender={3}
                    ListEmptyComponent={() => <EmptyOrders />}
                  />
                </View>
              );
            }
          }}
        </Query>
      </View>
    );
  }
}
