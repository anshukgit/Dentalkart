import {StyleSheet, Platform} from 'react-native';
import {SecondaryColor, DeviceWidth} from '@config/environment';

export default styles = StyleSheet.create({
    cardContainer: {
		backgroundColor: '#fff',
        padding: 1,
        borderRadius: 3,
        marginTop: 5,
        marginBottom: 5,
        marginRight: 8,
        marginLeft: 8,
        elevation: 2,
		shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
	},
	cardWrapper: {
		flexDirection: 'row',
		paddingHorizontal: 5,
		padding: 3,
		justifyContent: 'space-between'
	},
	title: {
		fontSize: 13,
		color: '#212121'
	},
	value: {
		fontSize: 13,
		color: '#212121'
	},
	header: {
		paddingVertical: 5,
		paddingHorizontal: 5,
		borderBottomWidth: 0.5,
		borderBottomColor: '#ddd',
		flexDirection: 'row',
		justifyContent: 'space-between'
	},
	orderId: {
		color: '#21212180'
	},
	status: {
		color: SecondaryColor
	},
	orderImageBox: {
		flexDirection: 'row',
		paddingLeft: 5,
		marginBottom: 5
	},
	imageWrapper: {
		marginRight: 5,
		padding: 1,
		borderWidth: 0.5,
		borderColor: SecondaryColor,
		borderRadius: 5
	},
	thumbnail: {
		height: 30,
		width: 30,
		borderRadius: 5
	},
	actionWrapper: {
		flexDirection: 'row',
		borderTopWidth: 0.5,
		borderTopColor: '#ddd'
	},
	trackButton: {
		flex: Platform.OS === 'ios' ? null : 1,
		width : Platform.OS === 'ios' ? (DeviceWidth-16) / 2 : null,
		paddingVertical: 10,
		alignItems: 'center'
	},
	detailsButton: {
		flex: Platform.OS === 'ios' ? null : 1,
		width : Platform.OS === 'ios' ? (DeviceWidth-16) / 2 : null,
		paddingVertical: 10,
		alignItems: 'center',
		borderLeftWidth: 0.5,
		borderLeftColor: '#ddd'
	},
	actionButtonText: {
		fontSize: 13,
		color: '#212121'
	},
	cancelButton: {
		borderWidth: 1,
		borderColor: SecondaryColor,
		padding: 5,
		margin: 5,
		borderRadius: 2,
		alignItems: 'center',
	}
});
