import React, { Component } from 'react';
import { View, Text, Image } from 'react-native';
import TouchableCustom from '@helpers/touchable_custom';
import styles from './order_card.style';

export default class OrderCard extends Component {
	render() {
		const _this = this.props._this,
			item = this.props.item,
			navigation = this.props.navigation;
		return (
			<View style={styles.cardContainer}>
				
				<View>
					
					<View style={styles.header}>
						<Text style={styles.orderId}>Order id: #{item.increment_id}</Text>
						<Text style={styles.status}>{item.status}</Text>
					</View>
					<View>
						<View style={styles.cardWrapper}>
							<Text style={styles.title}>Shipped to</Text>
							<Text style={styles.value}>{item.shipto}</Text>
						</View>
						<View style={styles.cardWrapper}>
							<Text style={styles.title}>Ordered on</Text>
							<Text style={styles.value}>{item.created_at}</Text>
						</View>
						<View style={styles.cardWrapper}>
							<Text style={styles.title}>Total amount</Text>
							<Text style={styles.value}>{item.currency} {item.grand_total}</Text>
						</View>
					</View>
					<View style={styles.orderImageBox}>
						{item.images && item.images.map((item, index) => (
							(index < 5) ? (
								<View key={index} style={styles.imageWrapper}>
									<Image source={{ uri: item }} style={styles.thumbnail} />
								</View>
							) : null
						))}
					</View>
					<View style={styles.actionWrapper}>
						<TouchableCustom underlayColor={'#ffffff10'} onPress={() => navigation.navigate('OrderDetails', { orderId: item.increment_id, can_cancel: item.can_cancel })}>
						{/* navigation.navigate('trackDetails', { data: item.increment_id } */}
							<View style={styles.trackButton}>
								<Text style={styles.actionButtonText}>Track</Text>
							</View>
						</TouchableCustom>
						<TouchableCustom underlayColor={'#ffffff10'} onPress={() => navigation.navigate('OrderDetails', { orderId: item.increment_id, can_cancel: item.can_cancel })}>
							<View style={styles.detailsButton}>
								<Text style={styles.actionButtonText}>Details</Text>
							</View>
						</TouchableCustom>
						{(item.can_return) &&
							<TouchableCustom underlayColor={'#ffffff10'} onPress={() => navigation.navigate('CreateReturnScreen', { orderId: item.increment_id })}>
								<View style={styles.detailsButton}>
									<Text style={styles.actionButtonText}>Return</Text>
								</View>
							</TouchableCustom>
						}
					</View>
				</View>
			</View>
		);
	}
}
