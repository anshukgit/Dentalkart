import gql from "graphql-tag";
const UPDATE_INFO = gql`
    mutation updateInfo(
        $firstname: String,
        $lastname: String,
        $email: String,
        $taxvat: String,
        $is_subscribed: Boolean,
    ){
        updateCustomer(input: {
            firstname: $firstname,
            lastname: $lastname,
            email: $email,
            taxvat: $taxvat,
            is_subscribed: $is_subscribed
        }){
            customer{
                id,
                firstname,
                lastname,
                email,
                taxvat,
                dob,
                is_subscribed
            }

        }
    }
`;
export default UPDATE_INFO;
