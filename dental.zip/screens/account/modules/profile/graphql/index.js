export {default as UPDATE_INFO_QUERY} from './update.gql';
export {default as SEND_CONFIRMATION_OTP_QUERY} from './sendOtp.gql';
export {default as VERIFY_CONFIRMATION_OTP_QUERY} from './confirmOtp.gql';
