import React, { Component, Fragment } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ToastAndroid,
  FlatList,
  Pressable, Keyboard
} from 'react-native';
import { Mutation } from 'react-apollo';
import { SecondaryColor, PrimaryColor } from '@config/environment';
import { UPDATE_INFO_QUERY, SEND_CONFIRMATION_OTP_QUERY, VERIFY_CONFIRMATION_OTP_QUERY } from './graphql';
import { CUSTOMER_INFO_QUERY } from '@screens/account';
import { Icon } from 'native-base';
import { TextField } from 'react-native-material-textfield';
import RadioButton from '@components/radioButton';
import { DentalkartContext } from '@dentalkartContext';
import Spinner from 'react-native-loading-spinner-overlay'
import { validateName, validateEmail } from '@helpers/validator';
import { fireAnalyticsEvent } from '@helpers/firebase_analytics';
import { client } from '@apolloClient';
import { showErrorMessage, showSuccessMessage } from '../../../../helpers/show_messages';
import {
  usernameErrMsg,
  passwordErrMsg,
  otpSentMsg,
  emailExistenceErrMsg,
  unconfirmedEmailMsg,
  incorrectCredentialMsg,
  emailExistMsg,
  firstNameErrMsg,
  lastNameErrMsg,
  mobileNumberErrMsg
} from '@config/messages';
import TextInputComponent from "@components/TextInputComponent";
import CountDown from 'react-native-countdown-component';
import HeaderComponent from "@components/HeaderComponent";
import Modal from 'react-native-modal'
import OtpInputs from 'react-native-otp-inputs';
export default class Profile extends Component {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    this.state = {
      firstName: '',
      firstNameError: '',
      lastName: '',
      lastNameError: '',
      email: '',
      emailError: '',
      phoeNumber: '',
      altPhoeNumber: '',
      password: '',
      fulfilled: false,
      isEditModal: false,
      gst: '',
      isVerifiedData: false,
      isLoading: false,
      isEmailVerified: false,
      shouldShow: false,
      showOtp: false,
      confirmOtpVal: '',
      showOtpView: false,
      editEmail: '',
      editEmailError: '',
      confirmOTPError:'',
      isEditMail:false,
    };
  }
  componentDidMount() {
    const { userInfo } = this.context;
    const user = userInfo ? userInfo.customer : {};
    // const active = user.gender.options.filter(item => item.value === user.gender.active);
    console.warn('updated user info : ', user)
    this.setState({
      firstName: user.firstname,
      lastName: user.lastname,
      email: user.email,
      mobilenumber: user.mobilenumber,
      // gender: user.gender.options,
      // activeGender: active[0],
      phoneNumber: user.mobilenumber,
      gst: user.taxvat,
      fulfilled: true,
      showOTPTimer: false
    });
    this.triggerScreenEvent();
  }
  editDetails = name => text => {
    if (!text) {
      this.setState({ [`${name}Error`]: 'Field can not be empty.' });
    } else if (!validateName(text)) {
      this.setState({ [`${name}Error`]: 'Do not use any special characters.' });
    } else {
      this.setState({ [`${name}Error`]: '' });
    }
    this.setState({ [name]: text });
  };
  updateInfo(updateInfo) {
    const {
      firstName,
      lastName,
      firstNameError,
      lastNameError,
      phoneNumber,
      email,
      gst,
    } = this.state;
    if (firstNameError || lastNameError) {
      showErrorMessage(firstNameError || lastNameError);
      return false;
    }
    let { setUserInfo, userInfo, handleError } = this.context;
    const variables = {
      firstname: firstName,
      lastname: lastName,
      email:email,
      mobilenumber:phoneNumber,
      // gender: activeGender.value,
      taxvat: gst,
    };

    console.warn('variables : ' , variables)
    updateInfo({ variables: variables });
    userInfo.customer.email = email;
    userInfo.customer.mobilenumber = phoneNumber;
    userInfo.customer.firstname = firstName;
    userInfo.customer.lastname = lastName;
    userInfo.customer.taxvat = gst;
    setUserInfo(userInfo)
  }
  // setGender = item => {
  //     const {gender} = this.state;
  //     this.setState({activeGender: gender[item.value]});
  // }
  postUpdateInfo = (cache, { data }) => {
    let { setUserInfo, userInfo, handleError } = this.context;
    console.warn('update post info : ' , data.updateCustomer.customer)
    const {
      id,
      email,
      firstname,
      lastname,
      mobilenumber,
      taxvat,
    } = data.updateCustomer.customer;
    userInfo.customer = data.updateCustomer.customer;
    userInfo.customer.mobilenumber = this.state.phoneNumber;
    setUserInfo(userInfo);
    showSuccessMessage('Information updated successfully');
    try {
      cache.writeQuery({
        query: CUSTOMER_INFO_QUERY,
        data: {
          customer: {
            id: id,
            firstname: firstname,
            lastname: lastname,
            taxvat: taxvat,
            email: email,
            mobilenumber:this.state.phoneNumber,
            dob: null,
            __typename: 'Customer',
          },
        },
      });
    } catch (error) {
      const msg = handleError(error);
      showErrorMessage(`${msg}. Please try again.`);
    }
  };
  // renderGender(){
  //     return(
  //         <View style={styles.genderWrapper}>
  //             <Text style={styles.genderText}>Gender</Text>
  //             <FlatList
  //                 data={this.state.gender}
  //                 renderItem={({item, index}) => {
  //                     if(item.value)
  //                         return(
  //                             <View style={styles.genderWrapper}>
  //                                 <TouchableOpacity onPress={()=> this.setGender(item)}>
  //                                     <RadioButton selected={this.state.activeGender.label === item.label} />
  //                                 </TouchableOpacity>
  //                                 <Text style={styles.genderTitle}>{item.label}</Text>
  //                             </View>
  //                         )
  //                     else null;
  //                 }}
  //                 extraData={this.state}
  //                 keyExtractor={(item) => item.value}
  //                 horizontal
  //             />
  //         </View>
  //     )
  // }
  triggerScreenEvent = _ => {
    const { userInfo } = this.context;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Edit Profile',
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };

  otpScreeen = () => {
    this.setState({ showOtp: true });
  };
  completeOTPTimer = async () => {
    this.setState({ shouldShow: false });
  }
  otpVerify = async () => {
    const { editEmail, confirmOtpVal } = this.state;
    const { setUserInfo, userInfo, handleError } = this.context;
    console.warn('Userinfo val =========== > ' , userInfo);
    //setUserInfo(userInfo);
    //{"customer": {"__typename": "Customer", "addresses": [], "confirmation": {"__typename": "Confirmation", "email_confirm": true, "mobile_confirm": false}, "dob": null, "email": "kinjalgajera22@gmail.com", "firstname": "Kids", "id": null, "lastname": "Viyu", "mobilenumber": "", "taxvat": null}}


    console.warn('cofirmopt val length : ', confirmOtpVal.length)
    if (confirmOtpVal.length < 6) {
      this.setState({confirmOTPError : 'Please enter six digit opt'});
    }
    else {

      this.setState({ isLoading: true })
      try {
        const {data} = await client.mutate({
          mutation: VERIFY_CONFIRMATION_OTP_QUERY,
          variables: { entity_type: this.state.isEditMail?"email":"mobile", type_value: editEmail, random_code: confirmOtpVal },
        });
        console.warn('VERIFY_CONFIRMATION_OTP_QUERY data response================= : ', editEmail, data, data.verifyConfirmationOtp.message)
        this.setState({ isLoading: false })
        //if()
        console.warn('error message : ' , data.verifyConfirmationOtp.message )
        this.setState({confirmOTPError : data.verifyConfirmationOtp.message});
        if(data.verifyConfirmationOtp.status){
          this.setState({ isEditModal: false,confirmOTPError:'' });
          this.state.isEditMail?
            this.setState({email:editEmail})
            :
            this.setState({phoneNumber:editEmail})
          showSuccessMessage(this.state.isEditMail?'Email updated successfully':"Mobile No updated successfully",'top')
          this.state.isEditMail?
          userInfo.customer.email = editEmail
          :
          userInfo.customer.mobilenumber = editEmail

          
          setUserInfo(userInfo);
        }
        //m {"data": {"verifyConfirmationOtp": {"__typename": "ConfirmationOtpOutput", "message": "Entered OTP is not correct.", "status": false}}}
        // if (data.sendConfirmationOtp.status) {
        //   this.setState({ showOtpView: true, shouldShow: true });
        // }
      } catch (err) {
        console.warn('verify error : ', err)
        this.setState({confirmOTPError : err});
        const msg = handleError(err);
        showErrorMessage(msg, 'top');
        this.setState({ isLoading: false })
      }
    }
  };

  emailVerify = async () => {
    const { editEmail, editEmailError,isEditMail } = this.state;
    const { handleError } = this.context;
    if (this.state.editEmail == ''){
      this.setState({isVerifiedData:true});
      this.setState({editEmailError:isEditMail?"Enter Email.":"Enter Mobile No"})
    }
    else if(isEditMail && !validateEmail(this.state.editEmail)) {
      this.setState({ isVerifiedData: true })
      this.setState({editEmailError:"Enter Valid Email Address"})
    }
    else if(!isEditMail && (this.state.editEmail.length < 10 || this.state.editEmail.length > 10 )){
      this.setState({ isVerifiedData: true })
      this.setState({editEmailError:"Enter Valid Mobile No with 10 digit only"})
    }
    else{// if (isEditMail && validateEmail(editEmail)) {
      this.setState({ isVerifiedData: true, })
      this.setState({ isLoading: true })
      try {
        const { data } = await client.mutate({
          mutation: SEND_CONFIRMATION_OTP_QUERY,
          variables: { type_value: editEmail, entity_type: isEditMail?'email':'mobile' },
        });
        console.warn('SEND_CONFIRMATION_OTP data response : ', editEmail, data.sendConfirmationOtp)
        this.setState({ isLoading: false })
        if (data.sendConfirmationOtp.status) {
          this.setState({ showOtpView: true, shouldShow: true,editEmailError:'' });
        }
        else{
          this.setState({ isVerifiedData: true })
          this.setState({editEmailError:data.sendConfirmationOtp.message})
        }
      } catch (err) {
        console.warn('verify error : ', err)
        const msg = handleError(err);
        showErrorMessage(msg, 'top');
        this.setState({ isLoading: false })
      }
    }
  };

  closeModal() {
    this.setState({ isEditModal: false, showOtpView: false })
  }
  render() {
    const { userInfo } = this.context;
    const {
      firstName,
      lastName,
      email,
      gst,
      firstNameError,
      lastNameError,
      fulfilled,
      phoneNumber
    } = this.state;
    console.log('state');
    console.log(this.state.firstName);
    return (
      <ScrollView>
        <Spinner
          visible={this.state.isLoading}
          // textContent={''}
          // textStyle={{ color: colors.White }}
          indicatorStyle={{ activeOpacity: 1 }}
        />
        <View style={{ height: 10, wdth: '100%' }}></View>
        <HeaderComponent label={'Profile details'} onPress={() => this.props.navigation.goBack()} />
        {/* <View style={styles.userInfoContainer}>
          <View style={[styles.shadow, { width: 80, height: 80, borderRadius: 80, backgroundColor: '#fff', justifyContent: 'center', alignItems: 'center' }]}>
            <Image
              source={require('../../../../assets/user.png')}
              style={styles.userImage} resizeMode={'contain'}
            />
           
          </View>
        </View> */}
        <View style={{ height: 10, wdth: '100%' }}></View>
        <Mutation
          mutation={UPDATE_INFO_QUERY}
          update={this.postUpdateInfo}
          onError={error => {
            showErrorMessage(`${error.message}. Please try again.`);
          }}>
          {(updateInfo, { data, loading, error }) => {
            return (
              <Fragment >
                {fulfilled &&
                  <Fragment style={{}}>
                    <View style={[styles.formWrapper, { marginTop: 10 }]}>
                      <View style={styles.textinputMainView}>
                        <View style={styles.textinputSubView}>
                          <Text style={styles.labelText}>First Name</Text>
                          <TextInputComponent placeholder='Frist Name'
                            placeholderTextColor={SecondaryColor}
                            value={firstName}
                            onChangeText={this.editDetails('firstName')}
                            autoCapitalize="none"
                            style={{}}
                            autoFocus={true}
                            style={[styles.TextInput, { borderRadius: 3 }]}
                          />
                        </View>
                        <View style={styles.textinputSubView}>
                          <Text style={styles.labelText}>Last Name</Text>
                          <TextInputComponent placeholder='Last Name'
                            placeholderTextColor={SecondaryColor}
                            value={lastName}
                            onChangeText={this.editDetails('lastName')}
                            autoCapitalize="none"
                            style={styles.TextInput}

                            style={[styles.TextInput, { borderRadius: 3 }]}
                          />
                        </View>
                      </View>


                    </View>
                    {/*{this.renderGender()}*/}
                    <View style={styles.formWrapper}>
                      <Text style={styles.labelText}>Email</Text>
                      <View style={[styles.emailTextInputView]} >
                        {/* <Icon name='email' type='Fontisto' style={styles.emailIcon} /> */}
                        <TextInputComponent placeholder='Youremail@mail.com'
                          placeholderTextColor={SecondaryColor}
                          value={email}
                          keyboardType="email-address"
                          autoCapitalize="none"
                          editable={false}

                        />
                        <Pressable style={{ right: 15, height: '100%', justifyContent: 'center' }}
                         onPress={() => this.setState({ editEmail: email, isEditModal: true, showOtpView: false,isEditMail:true })}>
                          <Icon name='edit' type='AntDesign' style={styles.emailIcon} />
                        </Pressable>
                      </View>

                      <View>
                        <Text style={styles.labelText}>Phone Number</Text>
                        <View style={[styles.emailTextInputView]}>

                          <TextInputComponent placeholder='Phone Number'
                            placeholderTextColor={SecondaryColor}
                            onChangeText={text => this.setState({ phoneNumber: text })}
                            value={this.state.phoneNumber}
                            keyboardType={'numeric'}
                            maxLength={10}
                            editable={false}
                          />
                          <Pressable style={{ right: 15 }}   onPress={() => this.setState({ editEmail: this.state.phoneNumber, isEditModal: true, showOtpView: false,isEditMail:false })}>
                            <Icon name='edit' type='AntDesign' style={styles.emailIcon} />
                          </Pressable>
                        </View>
                        {/* <Text style={styles.labelText}>Alternative Phone Number</Text>
                        <View style={[styles.emailTextInputView, { borderColor: colors.borderColor, }]}>
                       
                          <TextInputComponent placeholder='Alternative Phone Number'
                            placeholderTextColor={SecondaryColor}
                            onChangeText={text => this.setState({ altPhoeNumber: text })}
                            value={this.state.altPhoeNumber}
                            keyboardType={'numeric'}
                            maxLength={10}
                          />
                        </View> */}
                        {/* <Text style={styles.labelText}>Password</Text>
                        <View style={[styles.emailTextInputView]}>

                          <TextInputComponent placeholder='Password'
                            placeholderTextColor={SecondaryColor}
                            onChangeText={text => this.setState({ password: text })}
                            value={this.state.password}
                            keyboardType={'numeric'}
                            secureTextEntry={true}
                          />
                        </View> */}

                        <Text style={styles.labelText}>GST Number</Text>
                        <View style={[styles.emailTextInputView]}>

                          <TextInputComponent placeholder='GST Number'
                            placeholderTextColor={SecondaryColor}
                            onChangeText={text => this.setState({ gst: text })}
                            value={gst}
                            keyboardType={'numeric'}
                            maxLength={15}

                          />
                        </View>
                        {/*<TouchableOpacity style={styles.updateButton}>
                                                      <Text>Update</Text>
                                                  </TouchableOpacity>*/}
                      </View>
                    </View>
                    <TouchableOpacity
                      style={styles.saveButton}
                      onPress={() => this.updateInfo(updateInfo)}>

                      <Text style={styles.saveText}>
                        {loading ? 'Saving...' : 'Save'}
                      </Text>
                    </TouchableOpacity>
                  </Fragment>
                }
              </Fragment>
            );
          }}
        </Mutation>
        {/* <View style={styles.buttonContainer}>
                    <TouchableHighlight underlayColor="#efefef" >
                        <View style={styles.buttonWrapper}>
                            <Text style={styles.buttonText}>Change Password</Text>
                        </View>
                    </TouchableHighlight>
                </View> */}

        <Modal isVisible={this.state.isEditModal}
          animationInTiming={1000}
          animationOutTiming={1000}
          animationIn="fadeIn"
          animationOut="fadeOut"
          onSwipeComplete={() => this.setState({ is: false })}
          style={{ margin: 0, justifyContent: "center", alignItems: 'center' }}
        >
          <Pressable style={styles.emptyView} >

          </Pressable>

          <View style={[styles.moadlMainView, { height: this.state.showOtpView ? 400 : 205, }]}>
            <View style={styles.modalHeaderView}>
              <View style={styles.locationTxtView}>
                <Text style={styles.locationTxt}>{this.state.isEditMail?'Email Verification':'Mobile Verification'}</Text>
              </View>
              <Pressable style={styles.closeIconView} onPress={() => this.closeModal()}>
                <Icon name={'closecircleo'} type={'AntDesign'} style={styles.closeIcon} />
              </Pressable>
            </View>

            <View style={styles.modalemailTextInputView}>
              <View style={[styles.emailTextInputView, { width: '100%', marginTop: 15, borderColor: this.state.isVerifiedData && (this.state.editEmail == "") ? 'red' : colors.LightCyan }]} >
            
                <TextInputComponent placeholder={this.state.isEditMail?'Youremail@mail.com':'9876543210'}
                  placeholderTextColor={SecondaryColor}
                  value={this.state.editEmail}
                  onChangeText={this.editDetails('editEmail')}
                  keyboardType={this.state.isEditMail?"email-address":"number-pad"}
                  autoCapitalize="none"

                />
              </View>
          
                <View style={styles.editemailError}>
                  <Text style={[styles.editEmailTxtError]}>{this.state.editEmailError}</Text>
                </View>
                 
              {this.state.showOtpView == false ?
                <TouchableOpacity
                  style={[styles.saveButton, {}]}
                  onPress={() => this.emailVerify()}>
                  <Text style={styles.saveText}>
                    Verify
                  </Text>
                </TouchableOpacity>
                :
                null
              }
            </View>
            {this.state.showOtpView ?
              <View style={styles.otpFormWrapper}>
                <View style={{ alignItems: 'center' }}>
                  <OtpInputs
                    handleChange={(otp) => this.setState({ confirmOtpVal: otp })}
                    numberOfInputs={6}
                    inputContainerStyles={styles.inputContainerStyles}
                    inputStyles={styles.inputStyles}
                    focusStyles={{}}
                    keyboardType={'phone-pad'}
                    containerStyles={{ margin: 0 }}
                    inputsContainerStyles={{ justifyContent: 'center' }}
                  />

                  <View style={{ alignItems: 'center' }}>
                    {this.state.shouldShow ? (

                      <View
                        style={styles.resendOtpTimer}>
                        <Text style={styles.resendOtpTextRem}>Time Remaining : </Text>
                        <CountDown
                          until={60 * 1 + 59}
                          size={15}
                          onFinish={this.completeOTPTimer}
                          digitStyle={{ width: 20 }}
                          digitTxtStyle={{
                            color: '#999999',
                            fontWeight: '500',
                            fontSize: 15,
                          }}
                          timeToShow={['M', 'S']}
                          timeLabels={{ m: null, s: null }}
                          showSeparator={true}
                          separatorStyle={{
                            fontSize: 15,
                            color: '#999999',
                            width: 5,
                          }}
                        />
                      </View>
                    ) : (
                      <View style={styles.resendOtpWrapper}>
                        <TouchableOpacity
                          style={{ alignItems: 'center' }}
                          onPress={() => this.emailVerify()}>
                          <Text style={styles.resendOtpText}>Resend Otp</Text>
                        </TouchableOpacity>
                      </View>
                    )}
                  </View>
                  {this.state.confirmOtpVal.length < 6 || this.state.confirmOTPError != ''?
                    <View style={styles.confirmOTPErrorView}>
                      <Text style={[styles.editEmailTxtError]}>{this.state.confirmOTPError}</Text>
                    </View> : null
                  }
                  <TouchableOpacity
                    style={styles.otpBtn}
                    onPress={() => this.otpVerify()}>

                    <View
                      style={[
                        styles.loginBtn

                        , {}]}>
                      <Text style={[styles.signInButtonText,]}>Confirm Otp</Text>
                    </View>
                  </TouchableOpacity>
                
                </View>


              </View>
              : null}
          </View>
        </Modal>
      </ScrollView >
    );
  }
}

const styles = StyleSheet.create({
  userInfoContainer: {
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 25,
    marginBottom: 10,
  },
  userImage: {
    width: 80,
    height: 80,
    borderRadius: 80
  },
  formWrapper: {
    width: '95%',
    alignSelf: 'center',
    paddingHorizontal: 8,
  },
  genderWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 10,
    paddingHorizontal: 10,
  },
  genderText: {
    color: '#212121',
    fontSize: 15,
  },
  genderTitle: {
    color: '#000',
    fontSize: 15,
    marginLeft: 5,
  },
  editButton: {
    position: 'absolute',
    bottom: 5,
    right: 5,
    backgroundColor: '#444',
    borderRadius: 10,
  },
  saveButton: {
    marginHorizontal: 20, right: 3,
    width: '90%', height: 48, borderRadius: 3, alignItems: 'center', marginVertical: 18, backgroundColor: colors.blueColor, justifyContent: 'center',
  },
  saveText: {
    color: '#fff',
  },
  buttonContainer: {
    elevation: 3,
    marginVertical: 20,
  },
  updateButton: {
    position: 'absolute',
    right: 5,
    top: 15,
  },
  buttonWrapper: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#00000050',
    padding: 10,
  },
  buttonText: {
    color: '#000',
    fontSize: 15,
    marginLeft: 10,
  },
  emailTextInputView: { width: '100%', height: 45, borderWidth: 1, alignItems: 'center', flexDirection: 'row', paddingHorizontal: 15, borderRadius: 3, marginBottom: 15, top: 5, borderColor: colors.LightCyan },
  emailIcon: { fontSize: 17, marginRight: 15, color: '#c4cddd' },
  shadow: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 5,
  },
  textinputMainView: { width: '100%', height: 70, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5 },
  textinputSubView: { width: '49%', height: '100%', justifyContent: 'space-around' },
  labelText: { fontSize: 15, color: colors.StormGrey, },
  TextInput: { borderWidth: 1, height: 45, paddingHorizontal: 18, borderColor: colors.LightCyan, },
  modalHeaderView: { width: '100%', height: 50, borderBottomWidth: 5, justifyContent: 'center', paddingHorizontal: 15, flexDirection: 'row', borderBottomColor: colors.HexColor },
  locationTxtView: { width: '80%', height: '100%', justifyContent: 'center' },
  locationTxt: { fontSize: 18, fontWeight: '700' },
  closeIconView: { width: '20%', height: '100%', justifyContent: 'center', alignItems: 'flex-end' },
  closeIcon: { fontSize: 18 },
  otpFormWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    marginTop: 30,
  },
  signInButtonText: {
    color: '#ffffff',
    fontSize: 12
  },
  loginBtn: { width: '100%', height: 48, borderRadius: 3, alignItems: 'center', flexDirection: 'row', backgroundColor: colors.blueColor, justifyContent: 'center', marginTop: -8 },
  resendOtpTimer: {
    marginTop: 40,
    flexDirection: 'row',
    alignItems: 'center'
  },
  resendOtpText: {
    color: "#999999"
  },
  resendOtpTextRem: {
    color: '#999999',
    fontSize: 15
  },
  resendOtpWrapper: {
    marginTop: 50,
  },
  emptyView: { width: '100%', height: '100%', justifyContent: 'center', position: 'absolute' },
  moadlMainView: { width: '95%', backgroundColor: '#fff', borderRadius: 6, },
  modalemailTextInputView: { width: '100%', paddingHorizontal: 15, alignItems: 'center' },
  inputContainerStyles: { margin: 3, borderBottomWidth: 0, justifyContent: 'center', alignItems: 'center' },
  inputStyles: { width: 50, height: 50, paddingBottom: 10, borderWidth: 1, borderColor: '#0ea1e0', borderRadius: 4, justifyContent: 'center', alignItems: 'center' },
  otpBtn: { width: '75%', justifyContent: 'center', alignItems: 'center', marginTop: 30 },
  editemailError:{ marginTop: -8, width: '100%' },
  editEmailTxtError:{ fontSize: 12, color: 'red' },
  confirmOTPErrorView:{ width: '100%',justifyContent: 'center', alignItems: 'center', marginTop: 10 }
});