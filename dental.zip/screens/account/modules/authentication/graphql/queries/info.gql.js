import gql from "graphql-tag";

const CUSTOMER_INFO = gql`
    query{
       customer{
            id
            firstname
            lastname
            email
            mobilenumber
            confirmation{
                email_confirm
                mobile_confirm
            }
            taxvat
            dob
            addresses{
                default_shipping
                telephone
            }
        }
    }
`;

export default CUSTOMER_INFO


// customer{
//     id
//     firstname
//     lastname
//     email
//     taxvat
//     dob
// }
