import gql from "graphql-tag";

const LOGOUT = gql`
    mutation{
        revokeCustomerToken{
            result
        }
    }
`;

export default LOGOUT
