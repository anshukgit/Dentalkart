import gql from "graphql-tag";

const CREATE_NEW_USER = gql`
    mutation checkOTP($email: String!, $firstname: String!, $lastname: String!, $password: String!){
        createCustomer(input: {
        	firstname: $firstname,
        	lastname: $lastname,
        	email: $email,
        	password: $password
        }){
            customer {
                firstname
                lastname
                email
            }
        }
    }
`;

export default CREATE_NEW_USER;
