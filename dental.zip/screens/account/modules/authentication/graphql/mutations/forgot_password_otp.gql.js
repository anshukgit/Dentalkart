import gql from "graphql-tag";

const GET_FORGOT_PASSWORD_OTP = gql`
    mutation forgotPassworOTP($mobileNumber: String, $websiteId: Int){
        forgotPassworOTP(mobileNumber: $mobileNumber, websiteId: $websiteId){
            status
            message

        }
    }
`;

export default GET_FORGOT_PASSWORD_OTP;
