import gql from "graphql-tag";

const CHECK_OTP = gql`
    mutation checkOTP($email: String!, $otp: String!){
        confirmSignupOtp(email: $email, otp: $otp)
    }
`;

export default CHECK_OTP;
