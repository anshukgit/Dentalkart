import React, { Component } from 'react';
import {
  Text,
  View,
  Image,
  ToastAndroid,
  ScrollView,
  Platform,
  TouchableOpacity,
  KeyboardAvoidingView,
} from 'react-native';
import { TextField } from 'react-native-material-textfield';
import { SecondaryColor } from '@config/environment';
import { Query } from 'react-apollo';
import {
  CHECK_NEW_EMAIL_QUERY,
  CREATE_NEW_USER_QUERY,
  CHECK_OTP_QUERY,
  RESEND_SIGNUP_OTP_QUERY,
  LOGIN_QUERY,
} from '../../graphql';
import TouchableCustom from '@helpers/touchable_custom';
import styles from './register.style';
import { client } from '@apolloClient';
// import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { Icon } from 'native-base'
import {
  validateEmail,
  validatePassword,
  validateName,
  validateOTP,
  validatePhone,
} from '@helpers/validator';
import { Otp } from '../../modules/otp';
import tokenClass from '@helpers/token';
import { getCartId } from '@helpers/cart_id';
import { DentalkartContext } from '@dentalkartContext';
import AsyncStorage from '@react-native-community/async-storage';
import {
  usernameErrMsg,
  passwordErrMsg,
  otpSentMsg,
  emailExistenceErrMsg,
  unconfirmedEmailMsg,
  incorrectCredentialMsg,
  emailExistMsg,
  firstNameErrMsg,
  lastNameErrMsg,
  mobileNumberErrMsg
} from '@config/messages';
import { fireAnalyticsEvent } from '@helpers/firebase_analytics';
import { showErrorMessage, showSuccessMessage } from '../../../../../../helpers/show_messages';
import { SafeAreaView } from 'react-native';
import CREATE_ACCOUNT_OTP from '../../graphql/mutations/createAccountOtp.gql';
import VERIFY_CREATE_ACCOUNT_OTP from '../../graphql/mutations/verifyCreateAccount.gql';
import CREATE_NEW_MOBILE_USER from '../../graphql/mutations/createMobileNewUser.gql';
import TextInputComponent from "@components/TextInputComponent";
import Spinner from 'react-native-loading-spinner-overlay'
export default class SignUp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loginField: '',
      phoneField: '',
      loginFieldError: '',
      phoneFieldError: '',
      isVerifiedData: false,
      isEmailVerified: false,
      firstname: '',
      firstnameError: '',
      lastname: '',
      lastnameError: '',
      password: '',
      passwordError: '',
      hidePassword: true,
      otp: '',
      showOtp: false,
      shouldShow: false,
      showOTPTimer: false,
      isPhoneVerified: false,
      isLoading: false,
    };
    this._inputs = {};
  }
  static contextType = DentalkartContext;
  static navigationOptions = {
    title: 'Sign Up',
  };
  async validate(type, data) {
    if (type == 'loginField') {
      await this.setState({ loginField: data });
      if (!this.state.isPhoneVerified) {
        !validateEmail(data)
          ? this.setState({ [`${type}Error`]: usernameErrMsg })
          : this.setState({ loginFieldError: '' });
      }
    } else if (type == 'phoneField') {
      await this.setState({ phoneField: data });
      !validatePhone(data)
        ? this.setState({ [`${type}Error`]: mobileNumberErrMsg })
        : this.setState({ phoneFieldError: '' });
    }
    else if (type == 'firstname') {
      await this.setState({ firstname: data });
      !validateName(data)
        ? this.setState({ [`${type}Error`]: firstNameErrMsg })
        : this.setState({ firstnameError: '' });
    } else if (type == 'lastname') {
      await this.setState({ lastname: data });
      !validateName(data)
        ? this.setState({ [`${type}Error`]: lastNameErrMsg })
        : this.setState({ lastnameError: '' });
    } else if (type == 'password') {
      await this.setState({ password: data });
      !validatePassword(data)
        ? this.setState({ passwordError: 'Password must be of 6 characters.' })
        : this.setState({ passwordError: '' });
    } else if (type == 'otp') {
      await this.setState({ otp: data });
      !validateOTP(data)
        ? this.setState({ isOtpVerified: false })
        : this.setState({ isOtpVerified: true });
    }
    if (this.state.loginField && !this.state.loginFieldError) {
      this.setState({ isVerifiedData: true });
    } else {
      this.setState({ isVerifiedData: false });
    }
  }
  emailVerify = async () => {
    const { loginField, loginFieldError } = this.state;
    const { handleError } = this.context;
    if (loginField && !loginFieldError) {
      try {
        this.setState({isLoading:true})
        const { data } = await client.query({
          query: CHECK_NEW_EMAIL_QUERY,
          variables: { email: loginField },
          fetchPolicy: 'network-only',
        });
        if (!data.checkCustomerEmail.is_exist) {
          this.setState({
            isEmailVerified: true,
          });
        } else {
          data.checkCustomerEmail.message?showErrorMessage(data.checkCustomerEmail.message,'top'):showErrorMessage(emailExistMsg,'top');
        }
        this.setState({isLoading:false})
      } catch (err) {
        const msg = handleError(err);
        showErrorMessage(msg,'top');
        this.setState({isLoading:false})
      }
    }
  };
  resendSignUpOtp = async () => {
    const { handleError } = this.context;
    const { loginField, otp } = this.state;
    try {
      this.setState({isLoading:true})
      const { data } = await client.mutate({
        mutation: RESEND_SIGNUP_OTP_QUERY,
        variables: { email: loginField },
      });
    
      if (data.resendSignupOtp.status) {
        showSuccessMessage('Please check your email for OTP.','top');
      } else {
        data.resendSignupOtp.message?showErrorMessage(data.resendSignupOtp.message,'top'):showSuccessMessage(otpSentMsg,'top');
      }
      this.setState({isLoading:false})
    } catch (err) {
      const msg = handleError(err);
      this.setState({isLoading:false})
      showErrorMessage(msg,'top');
      console.log(err);
    }
  };
  newUserData = async () => {
    const { loginField, firstname, lastname, password } = this.state;
    const { handleError } = this.context;
    try {
      this.setState({isLoading:true})
      const { data } = client.mutate({
        mutation: CREATE_NEW_USER_QUERY,
        variables: {
          email: loginField,
          firstname: firstname,
          lastname: lastname,
          password: password,
        },
      });
      this.resendSignUpOtp();
      this.setState({ showOtp: true });
      this.setState({isLoading:false})
    } catch (err) {
      this.setState({isLoading:false})
      const msg = handleError(err);
      showErrorMessage(msg,'top');
      console.warn(err);
    }
  };
  confirmOtp = async () => {
    const { loginField, otp } = this.state;
    const { handleError } = this.context;
    try {
      this.setState({isLoading:true})
      const { data } = await client.mutate({
        mutation: CHECK_OTP_QUERY,
        variables: { email: loginField, otp: otp },
      });
      showSuccessMessage('OTP Verified!','top');
      this.login();
      this.setState({isLoading:false})
    } catch (err) {
      const msg = handleError(err);
      this.setState({isLoading:false})
      showErrorMessage(msg,'top');
      console.log(err);
    }
  };
  login = async () => {
    const { loginField, password } = this.state;
    const { getUserInfo, handleError, getGuestAndCustomerCartId } = this.context;
    try {
      this.setState({isLoading:true})
      const { data } = await client.mutate({
        mutation: LOGIN_QUERY,
        variables: { username: loginField, password: password },
      });
      if (data.generateCustomerToken.token) {
        const token = data.generateCustomerToken.token;
        await tokenClass.setToken(token);
        await getUserInfo();
        await getGuestAndCustomerCartId()
        this.setState({isLoading:false})
        return this.props.navigation.navigate('Home');
      }
    } catch (err) {
      const msg = handleError(err);
      this.setState({isLoading:false})
      showErrorMessage(msg,'top');
      console.warn(err);
    }
  };
  // navigateToLastScreen = async (key) => {
  //     const {navigate, state, push} = this.props.navigation;
  //     if(key === 'later')
  //         await AsyncStorage.setItem('firstTime', 'installed ha ha ha!');
  //     try {
  //         console.log(this.props.navigation.state)
  //         let lastScreen = state.params.screen;
  //         let params = state.params?.params ?? {};
  //         return push(lastScreen ? lastScreen : 'Home', params);
  //     } catch (e) {
  //         alert(e);
  //         return navigate('Home');
  //     }
  // }
  _next(field) {
    this._inputs[field] && this._inputs[field].focus();
  }
  triggerScreenEvent = _ => {
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Register',
      userId: '',
    });
  };
  componentDidMount() {
    this.triggerScreenEvent();
  }
  otpScreeen = () => {
    this.setState({ showOtp: true });
  };
  createMobileRegisterOTP = async () => {
    try {
      this.setState({isLoading:true})
      const { data } = await client.mutate({
        mutation: CREATE_ACCOUNT_OTP,
        variables: { mobileNumber: this.state.phoneField, websiteId: 1 }
      });
      if (data) {
        if (data.createAccountOTP.status) {
          this.setState({
            showOtp: true,
            shouldShow: false,
            showOTPTimer: true,
          isLoading:false
          });
        } else {
          this.setState({isLoading:false})
          showErrorMessage(data.createAccountOTP.message,'top');
        }
      }
    } catch (error) {
      this.setState({isLoading:false})
      showErrorMessage(error,'top');
    }
  };
  confirmOtpPhone = async () => {
    const { phoneField, otp } = this.state;
    const { handleError } = this.context;
    try {
      this.setState({isLoading:true})
      const { data } = await client.mutate({
        mutation: VERIFY_CREATE_ACCOUNT_OTP,
        variables: { mobileNumber: phoneField, otp: otp, websiteId: 1 },
      });
      if (data) {
        if (data.createAccountOTPVerify.status) {
          this.setState({
            showOtp: false,
            shouldShow: true,
            showOTPTimer: false,
            isPhoneVerified: true,
            isLoading:false
          });
        } else {
          this.setState({isLoading:false})
          showErrorMessage(data.createAccountOTPVerify.message,'top');
        }
      }
    } catch (err) {
      const msg = handleError(err);
      this.setState({isLoading:false})
      showErrorMessage(msg,'top');
      console.log(err);
    }
  };
  resendSignUpOtpPhone = async () => {
    try {
      this.setState({isLoading:true})
      const { data } = await client.mutate({
        mutation: CREATE_ACCOUNT_OTP,
        variables: { mobileNumber: this.state.phoneField, websiteId: 1 }
      });
      if (data) {
        this.setState({isLoading:false})
        if (data.createAccountOTP.status) {
          this.setState({ showOTPTimer: true });
        } else {
          showErrorMessage(data.createAccountOTP.message,'top');
        }
      }
    } catch (error) {
      this.setState({isLoading:false})
      showErrorMessage(error,'top');
    }
  }
  completeOTPTimer = async () => {
    this.setState({ showOTPTimer: false });
  }
  newAccountCreatePhone = async () => {
    const { phoneField, otp, loginField, firstname, lastname, password } = this.state;
    const { getUserInfo, handleError, getGuestAndCustomerCartId } = this.context;
    let emailData = '';
    try {
      this.setState({isLoading:true});
      if (loginField != '') {
        emailData = loginField;
      } else {
        emailData = phoneField + '@dentalkart.user';
      }
      const { data } = await client.mutate({
        mutation: CREATE_NEW_MOBILE_USER,
        variables: { customerEmail: emailData, firstname: firstname, lastname: lastname, password: password, mobileNumber: phoneField, otp: otp, websiteId: 1 },
      });
      if (data) {

        if (data.createCustomerAccount.status) {
          const token = data.createCustomerAccount.token;
          await tokenClass.setToken(token);
          await getUserInfo();
          await getGuestAndCustomerCartId()
          this.setState({isLoading:false})
          this.props.navigation.navigate('Home');
        } else {
          this.setState({isLoading:false})
          showErrorMessage(data.createCustomerAccount.message,'top');
        }
      }
    } catch (err) {
      this.setState({isLoading:false})
      const msg = handleError(err);
      showErrorMessage(msg,'top');
      console.log(err);
    }
  }
  render() {
    const buttonText = this.state.shouldShow ? "Use Mobile Number" : "Use Email";
    return (
      <View style={{ flex: 1, }}>
           <Spinner
          visible={this.state.isLoading}
          // textContent={''}
          // textStyle={{ color: colors.White }}
          indicatorStyle={{ activeOpacity: 1 }}
        />
        {/* <KeyboardAvoidingScrollView > */}
        <View style={{ width: '100%', position: 'absolute', bottom: 0, }}>
          <Image source={require('../../../../../../assets/loginbg.png')} style={{ width: '100%' }} resizeMode={'contain'} />
        </View>
        <View style={styles.logoMinView}>
          <Image source={require('../../../../../../assets/logo.png')} style={{ width: '50%', }} resizeMode={'contain'} />
        </View>
        {!this.state.showOtp ? (
          <View style={{ flex: 0.75 }}>
            <View style={[styles.midView]}>
              {this.state.shouldShow && (!this.state.isEmailVerified || this.state.isPhoneVerified) || (this.state.isEmailVerified && !this.state.isPhoneVerified) ? (
                <View style={[styles.emailTextInputView, { borderColor: this.state.isSignUp && loginField == '' ? colors.red : colors.borderColor, marginTop: 15 }]}>
                  <Icon name='email' type='Fontisto' style={styles.emailIcon} />
                  <TextInputComponent placeholder='Youremail@mail.com'
                    placeholderTextColor={SecondaryColor}
                    value={this.state.loginField}
                    onChangeText={loginField =>{
                      loginField = loginField.replace(/\s/g, '');
                      this.validate('loginField', loginField)
                    }
                    }
                    keyboardType="email-address"
                    autoFocus={true}
                    autoCapitalize="none"

                  />
                </View>
              ) :
                null}
              {!this.state.shouldShow && (this.state.isEmailVerified || !this.state.isPhoneVerified) || (!this.state.isEmailVerified && this.state.isPhoneVerified) ? (

                <View style={[styles.emailTextInputView, { borderColor: this.state.isSignUp && this.state.email == '' ? colors.red : colors.borderColor, marginTop: 15 }]}>
                  <Icon name='phone' type='Feather' style={[styles.emailIcon, { fontSize: 20, }]} />
                  <TextInputComponent placeholder='Mobile Number'
                    placeholderTextColor={SecondaryColor}
                    onChangeText={phoneField =>
                      {
                        phoneField = phoneField.replace(/\s/g, '');
                        this.validate('phoneField', phoneField)}
                    }
                    autoFocus={true}
                    value={this.state.phoneField}
                    error={this.state.phoneFieldError}
                    autoCorrect={false}
                    keyboardType={'numeric'}
                    maxLength={10}
                  />
                </View>

              )
                :
                null}
              {!this.state.isEmailVerified && !this.state.isPhoneVerified ?
                <TouchableOpacity
                  style={{ alignItems: 'flex-start', marginTop: 15 ,height:30,justifyContent:'center'}}
                  onPress={() => this.setState({ shouldShow: !this.state.shouldShow })}>
                  <Text style={{ fontSize: 14 }}><Text style={{ color: colors.text }}>Or Signup with </Text><Text style={{ color: colors.normalText }}>{buttonText}</Text></Text>
                </TouchableOpacity> : null}

              {this.state.isEmailVerified || this.state.isPhoneVerified ? (
                <View>
                  <View style={[styles.emailTextInputView, { borderColor: colors.borderColor, marginTop: 15 }]}>
                    <Icon name='user' type='AntDesign' style={styles.emailIcon} />
                    <TextInputComponent placeholder='First Name'
                      placeholderTextColor={SecondaryColor}
                      onChangeText={firstname =>
                        this.validate('firstname', firstname)
                      }
                      value={this.state.firstname}
                      autoCorrect={false}
                    />
                  </View>

                  <View style={[styles.emailTextInputView, { borderColor: colors.borderColor, marginTop: 15 }]}>
                    <Icon name='user' type='AntDesign' style={styles.emailIcon} />
                    <TextInputComponent placeholder='Last Name'
                      placeholderTextColor={SecondaryColor}
                      value={this.state.lastname}
                      onChangeText={lastname => this.validate('lastname', lastname)}
                      autoCorrect={false}
                    />
                  </View>
                  <View>
                    <View style={[styles.emailTextInputView, { borderColor: colors.borderColor, marginTop: 12 }]}>
                      <Icon name='lock' type='SimpleLineIcons' style={styles.emailIcon} />
                      <TextInputComponent placeholder='Password'
                        placeholderTextColor={SecondaryColor}
                        value={this.state.password}
                        onChangeText={password =>{
                          password = password.replace(/\s/g, '');
                          this.validate('password', password)
                        }
                        }
                        secureTextEntry={this.state.hidePassword}
                      />

                      <TouchableOpacity
                        onPress={() =>
                          this.setState({ hidePassword: !this.state.hidePassword })
                        }
                        style={styles.eyeIconWrapper}>
                        <Icon
                          name={this.state.hidePassword ? 'eye-off' : 'eye'}
                          color={
                            this.state.password ? SecondaryColor : '#ddd'
                          }
                          style={{ fontSize: 22, color: colors.blueColor }}
                          size={20}
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              ) : null}
            </View>

            <View style={styles.footerView}>
              {this.state.isEmailVerified || this.state.isPhoneVerified ? (
                 <TouchableCustom
                 onPress={() => {
                   (this.state.isVerifiedData || this.state.isPhoneVerified) &&
                     this.state.firstname &&
                     this.state.lastname &&
                     this.state.password &&
                     !this.state.passwordError
                     ? this.state.isPhoneVerified ? this.newAccountCreatePhone() : this.newUserData()
                     : null;
                 }}>
                 <View
                   style={
                     (this.state.isVerifiedData || this.state.isPhoneVerified) &&
                       this.state.firstname &&
                       this.state.lastname &&
                       this.state.password &&
                       !this.state.passwordError
                       ? styles.loginBtn
                       : styles.loginBtnDisabled
                   }>
                   <Text style={[styles.signUpButtonText, styles.textBtnCenter]}>Create Account</Text>
                 </View>
               </TouchableCustom>
              

              ) : this.state.shouldShow ? (
                <TouchableCustom
                  onPress={() => this.emailVerify()}>
                  <View
                    style={[
                      this.state.isVerifiedData
                        ? styles.loginBtn
                        : styles.loginBtnDisabled
                    ]}>
                    <Text style={[styles.signUpButtonText, styles.textBtnCenter]}>Verify Email</Text>
                  </View>
                </TouchableCustom>
              ) :
                <TouchableCustom
                onPress={ this.state.phoneField.length==10 && !this.state.phoneFieldError?this.createMobileRegisterOTP:null} >
                  <View
                    style={[
                      this.state.phoneField.length==10 && !this.state.phoneFieldError
                        ? styles.loginBtn
                        : styles.loginBtnDisabled
                      ]}>
                    <Text style={styles.textBtnCenter}> Verify Mobile</Text>
                  </View>
                </TouchableCustom>
              }
            </View>
          </View>
        ) : (
          this.state.shouldShow ?
            <Otp _this={this} resendOtp={this.resendSignUpOtp} confirmOtp={this.confirmOtp} />
            : <Otp _this={this} completeOTPTimer={this.completeOTPTimer} shouldShow={this.state.showOTPTimer} resendOtp={this.resendSignUpOtpPhone} confirmOtp={this.confirmOtpPhone}  pageName={'registration'}/>
        )}
        {/* </KeyboardAvoidingScrollView> */}
      </View>
    );
  }
}
