import React, { Component, useEffect, useState } from 'react';
import { Text, View, TouchableOpacity ,Platform} from 'react-native';
import OtpInputs from 'react-native-otp-inputs';
import { Mutation } from 'react-apollo';
import { CHECK_OTP_QUERY } from '../../graphql';
import styles from './otp.style';
import { fireAnalyticsEvent } from '@helpers/firebase_analytics';
import CountDown from 'react-native-countdown-component';
import Spinner from 'react-native-loading-spinner-overlay'

export const Otp = ({ _this, resendOtp, scr, generateToken, confirmOtp, shouldShow, completeOTPTimer,pageName }) => {

  triggerScreenEvent = (_) => {
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: `Otp`,
      userId: '',
    
    });
  };
  useEffect(() => {
    triggerScreenEvent();
  }, []);
  return (
    <View style={styles.otpWrapper}>
        
      <View style={styles.titleWrapper}>
        <Text style={styles.titleText}>
          Please enter the verification code sent to
        </Text>
        {pageName == 'registration'?
        <Text style={styles.titleText}>{_this.state.phoneField}</Text>
        :
        <Text style={styles.titleText}>{_this.state.loginField}</Text>
         }
        
      </View>
      <View style={styles.otpFormWrapper}>
        <View style={{ flex: 1 }}>
          <OtpInputs
            handleChange={(otp) => _this.validate('otp', otp)}
            numberOfInputs={6}
            inputContainerStyles={{ margin: 3, borderBottomWidth: 0,justifyContent:'center',alignItems:'center' }}
            inputStyles={{ width: 50, height:50,paddingBottom:10,borderWidth: 1, borderColor: '#0ea1e0', borderRadius: 4,justifyContent:'center',alignItems:'center' }}
            focusStyles={{}}
            keyboardType={'phone-pad'}
            containerStyles={{ margin: 0 }}
            inputsContainerStyles={{ justifyContent: 'center' }}
          />
          <View style={styles.verifyWrapper}>
            {scr !== 'fp' ? (

              <TouchableOpacity
          style={{width: '75%',justifyContent:'center',alignItems:'center',marginTop:35}}
          activeOpacity= {_this.state.isOtpVerified?0:1  }    
          onPress={() =>
                  _this.state.isOtpVerified && !_this.state.isPhoneLogin ? confirmOtp(generateToken) : _this.state.isOtpVerified && _this.state.isPhoneLogin ? confirmOtp() : null
                }>
                <View
                  style={[
                    _this.state.isOtpVerified
                      ? styles.loginBtn
                      : styles.loginBtnDisabled
                  ,{}]}>
               <Text style={[styles.signInButtonText,]}>Verify</Text> 
                </View>
              </TouchableOpacity>

            ) : null}
            <View style={{ alignItems: 'center' }}>
              {shouldShow ? (

                <View
                  style={styles.resendOtpTimer}>
                  <Text style={styles.resendOtpTextRem}>Time Remaining : </Text>
                  <CountDown
                    until={60 * 1 + 59}
                    size={15}
                    onFinish={completeOTPTimer}
                    digitStyle={{ width: 20 }}
                    digitTxtStyle={{
                      color: '#999999',
                      fontWeight: '500',
                      fontSize: 15,
                    }}
                    timeToShow={['M', 'S']}
                    timeLabels={{ m: null, s: null }}
                    showSeparator={true}
                    separatorStyle={{
                      fontSize: 15,
                      color: '#999999',
                      width: 5,
                    }}
                  />
                </View>
              ) : (
                <View style={styles.resendOtpWrapper}>
                  <TouchableOpacity
                    style={{ alignItems: 'center' }}
                    onPress={() => resendOtp()}>
                    <Text style={styles.resendOtpText}>Resend Otp</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};
