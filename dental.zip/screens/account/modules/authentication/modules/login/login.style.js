import {StyleSheet} from 'react-native';
import {DeviceWidth, PrimaryColor, DeviceHeight} from '@config/environment';
import colors from '@config/colors';
export default styles = StyleSheet.create({
    loginPageContainer: {
		backgroundColor: '#ffffff',
		flex: 1
	},
	loginScreenWrapper: {
		flex: 1,
        justifyContent: 'center',
	},
    signInFormWrapper: {
		width: DeviceWidth,
		paddingLeft: 15,
		paddingRight: 15,
		marginTop: 26
	},
	eyeIcon: {
		position: 'absolute',
		right: 5,
		top: 12,

	},
    signInButtonDisabled: {
		backgroundColor: '#d4d4d4',
		borderRadius: 5,
		marginTop: 25,
		height: 40,
		justifyContent: 'center',
		alignItems: 'center',
		width: DeviceWidth-30,
	},
	signInButton: {
		backgroundColor: PrimaryColor,
		borderRadius: 5,
		marginTop: 25,
		height: 40,
		justifyContent: 'center',
		alignItems: 'center',
		width: DeviceWidth-30,
	},
	signInButtonText: {
		color: '#ffffff',
		fontSize: 12
	},
    OtherFormNavigatorWrapper: {
		width: DeviceWidth,
		justifyContent: 'center',
		alignItems: 'center',
		marginTop: 10
	},
	OtherFormNavigatorSeparator: {
		backgroundColor: '#b4b3b3',
		height: 0.5,
		width: 100,
		marginVertical: 20,
	},
	OtherFormNavigatorText: {
		color: '#b4b3b3',
		fontSize: 12,
		marginTop:10
	},
	OtherFormOtpText: {
		color: '#b4b3b3',
		fontSize: 14,
		marginTop:10
	},
	newUserTextWrapper: {
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'baseline',
		height: 25,
	},
	signUpText: {
		color: PrimaryColor,
		fontSize: 17
	},
	loginLaterWrapper: {
		justifyContent: 'center',
		alignItems: 'center',
		marginTop: 20,
	},
	loginLaterText: {
		color: '#b4b3b3',
		fontSize: 12
	},
	socialLoginContainer: {
		flexDirection: 'row',
		justifyContent: 'space-evenly',
		alignItems: 'center',
		width: '100%',
	},
	logoMinView: { width: '100%', flex: 0.38, justifyContent: 'center', alignItems: 'center' },
	midView: { width: '100%', flex: 0.32, paddingHorizontal: 20, },
	footerView: { width: '100%', flex: 0.3, alignItems: 'center' },
	emailTextInputView: { width: '100%', height: 45, borderWidth: 1, alignItems: 'center', flexDirection: 'row', paddingHorizontal: 15, borderRadius: 3, },
	emailIcon: { fontSize: 16, marginRight: 15, color: '#c4cddd' },
	phoneNumberView: { width: '100%', height: 25, alignItems: 'center', flexDirection: 'row', marginTop: 10, },
	loginBtn: { width: '100%', height: 48, borderRadius: 3, alignItems: 'center', flexDirection: 'row', marginTop: 18, backgroundColor: colors.blueColor, justifyContent: 'center', },
	loginBtnDisabled: { width: '100%', height: 48, borderRadius: 3, alignItems: 'center', flexDirection: 'row', marginTop: 18, backgroundColor: colors.blueColor, justifyContent: 'center',opacity:0.5 },
})
