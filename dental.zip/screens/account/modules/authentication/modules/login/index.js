import React, { Component } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ToastAndroid, Image, Pressable, ActivityIndicator, Platform
} from 'react-native';
import TouchableCustom from '@helpers/touchable_custom';
import { SecondaryColor } from '@config/environment';
import Logo from '@components/authlogo';
import { TextField } from 'react-native-material-textfield';
// import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './login.style';
import {
  LOGIN_QUERY,
  RESEND_SIGNUP_OTP_QUERY,
  CHECK_OTP_QUERY,
} from '../../graphql';
import { Mutation } from 'react-apollo';
import { Otp } from '../../modules/otp';
import { client } from '@apolloClient';
import {
  validateEmail,
  validatePassword,
  validateMobile,
  validateOTP,
  validatePhone
} from '@helpers/validator';
import {
  usernameErrMsg,
  passwordErrMsg,
  otpSentMsg,
  emailExistenceErrMsg,
  unconfirmedEmailMsg,
  incorrectCredentialMsg,
  mobileNumberErrMsg,
} from '@config/messages';
import tokenClass from '@helpers/token';
import { DentalkartContext } from '@dentalkartContext';
import SyncStorage from '@helpers/async_storage';
import { getCartId } from '@helpers/cart_id';
import GoogleLogin from '@components/googleLogin';
import AppleLogin from '@components/applelogin';
import { SOCIAL_LOGIN } from '../../graphql';
import { fireAnalyticsEvent } from '@helpers/firebase_analytics';
import { showErrorMessage } from '../../../../../../helpers/show_messages';
import appleAuth from '@invertase/react-native-apple-authentication'
import GET_LOGIN_OTP from '../../graphql/mutations/loginOtp.gql';
import VERIFY_LOGIN_OTP from '../../graphql/mutations/verfiyLoginOtp.gql';
import GET_FORGOT_PASSWORD_OTP from '../../graphql/mutations/forgot_password_otp.gql';
import VERIFY_FORGOT_PASSWORD_OTP from '../../graphql/mutations/forgot_password_otp_verify.gql';
import GENERATE_MOBILE_NUMBER_TOKEN from '../../graphql/mutations/mobileToken.gql';
import TextInputComponent from "@components/TextInputComponent";
import { Icon } from "native-base";
import Spinner from 'react-native-loading-spinner-overlay'
export default class Login extends Component {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    this.state = {
      isVerifiedData: false,
      loginField: '',
      loginFieldError: '',
      password: '',
      showPassword: false,
      passwordError: '',
      otp: '',
      showOtp: false,
      isKeyboard: false,
      isOtpVerified: false,
      isPhoneLogin: false,
      shouldShow: false,
      isLoading: false,
    };
  }
  login = async () => {
    const { loginField, password } = this.state;
    const { getUserInfo, handleError, getGuestAndCustomerCartId } = this.context;
    try {
      this.setState({ isLoading: true })
      const { data } = await client.mutate({
        mutation: GENERATE_MOBILE_NUMBER_TOKEN,
        variables: { mobileEmail: loginField, password: password, websiteId: 1 },
      });

      if (data.login.status) {
        const token = data.login.token;
        await tokenClass.setToken(token);
        await getUserInfo();
        await getGuestAndCustomerCartId();
        this.setState({ isLoading: false })
        return this.navigateToLastScreen();

      } else {
        this.setState({ isLoading: false })
        console.warn('login message : ', data.login.message)
        showErrorMessage(data.login.message, 'top');
      }
    } catch (err) {
      this.setState({ isLoading: false })
      const msg = handleError(err);
      showErrorMessage(msg, 'top');
      console.warn(err);
    }
  };
  navigateToLastScreen = async key => {
    const { navigate, state, push } = this.props.navigation;
    if (key === 'later') {
      await SyncStorage.set('firstTime', 'installed ha ha ha!');
    }
    try {
      let lastScreen = state.params.screen;
      lastScreen = lastScreen == 'UrlResolver' ? 'Home' : lastScreen;
      let params = state.params?.params ?? {};
      return navigate(lastScreen ? lastScreen : 'Home', params);
    } catch (e) {
      alert(e);
      return navigate('Home');
    }
  };
  confirmOtp = async generateToken => {
    const { loginField, otp } = this.state;
    const { handleError } = this.context;
    try {
      this.setState({ isLoading: true })
      const { data } = await client.mutate({
        mutation: CHECK_OTP_QUERY,
        variables: { email: loginField, otp: otp },
      });
      generateToken();
      this.setState({ isLoading: false })
    } catch (err) {
      const msg = handleError(err);
      this.setState({ isLoading: false })
      showErrorMessage(msg, 'top');
      console.log(err);
    }
  };
  resendSignUpOtp = async () => {
    const { handleError } = this.context;
    const { loginField, otp } = this.state;
    try {
      this.setState({ isLoading: true })
      const { data } = await client.mutate({
        mutation: RESEND_SIGNUP_OTP_QUERY,
        variables: { email: loginField },
      });
      showErrorMessage('Please check your email for OTP.', 'top');
      this.setState({ isLoading: false })
    } catch (err) {
      const msg = handleError(err);
      this.setState({ isLoading: false })
      showErrorMessage(msg, 'top');
      console.log(err);
    }
  };
  handleLoginErrors = error => {
    const { handleError } = this.context;
    const msg = handleError(error);
    try {

      const errorJSON = JSON.parse(msg);
      if (errorJSON.errorCode) {
        this.resendSignUpOtp();
        this.setState({ showOtp: true });
      }
    } catch (e) {
      showErrorMessage(msg, 'top');
    }
  };
  async validate(type, data) {
    if (type == 'loginField') {
      if (data !== '') {
        let dataType = parseInt(data);
        if (dataType != data) {
          !validateEmail(data)
            ? this.setState({ [`${type}Error`]: usernameErrMsg })
            : this.setState({ loginFieldError: '', isPhoneLogin: false });
        } else {
          !validatePhone(data)
            ? this.setState({ [`${type}Error`]: mobileNumberErrMsg })
            : this.setState({ loginFieldError: '', isPhoneLogin: true });
        }

      }
      await this.setState({ loginField: data });
    } else if (type == 'password') {
      await this.setState({ password: data });
      !validatePassword(data)
        ? this.setState({ [`${type}Error`]: passwordErrMsg })
        : this.setState({ passwordError: '' });
    } else if (type == 'otp') {
      await this.setState({ otp: data });
      !validateOTP(data)
        ? this.setState({ isOtpVerified: false })
        : this.setState({ isOtpVerified: true });
    }
    if (
      this.state.loginField &&
      this.state.password &&
      !this.state.loginFieldError &&
      !this.state.passwordError
    ) {
      this.setState({ isVerifiedData: true });
    } else {
      this.setState({ isVerifiedData: false });
    }
  }
  _next() {
    this._passwordInput && this._passwordInput.focus();
  }
  googleLogin = async data => {
    const variables = {
      type: 'googlelogin',
      token: data.idToken,
      quoteId: await getCartId(),
    };
    try {
      this.setState({ isLoading: true })
      const { data } = await client
        .mutate({
          mutation: SOCIAL_LOGIN,
          variables: variables,
        })
        .catch(error => {
          this.setState({ isLoading: false })
          //globalObject.handleError(error);
        });
      if (data && data.dkgenerateSocialLoginCustomerToken.token) {
        await tokenClass.setToken(
          data.dkgenerateSocialLoginCustomerToken.token,
        );
        await this.context.getUserInfo();
        await this.context.getGuestAndCustomerCartId();
        this.setState({ isLoading: false })
        this.navigateToLastScreen();
      }
    } catch (error) {
      this.setState({ isLoading: false })
      // globalObject.handleError(error);
    }
  };
  appleLogin = async data => {
    const variables = {
      type: 'applelogin',
      token: data.idToken,
      quoteId: await getCartId(),
    };
    try {

      this.setState({ isLoading: true })
      const { data } = await client
        .mutate({
          mutation: SOCIAL_LOGIN,
          variables: variables,
        })
        .catch(error => {
          this.setState({ isLoading: false })
          showErrorMessage(error.message, 'top');
        });
      if (data && data.dkgenerateSocialLoginCustomerToken.token) {
        await tokenClass.setToken(
          data.dkgenerateSocialLoginCustomerToken.token,
        );
        await this.context.getUserInfo();
        await this.context.getGuestAndCustomerCartId();
        this.setState({ isLoading: false })
        this.navigateToLastScreen();
      }
    } catch (error) {
      this.setState({ isLoading: false })
      // globalObject.handleError(error);
    }
  };
  triggerScreenEvent = _ => {
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Login',
      userId: '',
    });
  };
  componentDidMount() {
    this.triggerScreenEvent();
  }
  phoneLogin = async () => {
    if (this.state.isPhoneLogin) {
      try {
        this.setState({ isLoading: true })
        const { data } = await client.mutate({
          mutation: GET_LOGIN_OTP,
          variables: { mobileNumber: this.state.loginField, websiteId: 1 }
        });
        if (data) {
          if (data.loginOTP.status) {
            this.setState({ showOtp: true, shouldShow: true });
          } else {
            showErrorMessage(data.loginOTP.message, 'top');
          }
          this.setState({ isLoading: false })
        }
      } catch (error) {
        showErrorMessage(error.message, 'top');
        this.setState({ isLoading: false })
      }
    } else {
      showErrorMessage('Please enter mobile number', 'top');
      this.setState({ isLoading: false })
    }
  };

  phoneLoginResendOTP = async () => {
    try {
      this.setState({ isLoading: true })
      const { data } = await client.mutate({
        mutation: GET_LOGIN_OTP,
        variables: { mobileNumber: this.state.loginField, websiteId: 1 }
      });
      if (data) {
        if (data.loginOTP.status) {
          this.setState({ shouldShow: true });
        } else {
          showErrorMessage(data.loginOTP.message, 'top');
        }
        this.setState({ isLoading: false })
      }
    } catch (error) {
      this.setState({ isLoading: false })
      showErrorMessage(error.message, 'top');
    }
  }

  completeOTPTimer = async () => {
    this.setState({ shouldShow: false });
  }

  phoneLoginConfirmOTP = async () => {
    const { loginField, otp } = this.state;
    const { handleError } = this.context;
    try {
      this.setState({ isLoading: true })
      const { data } = await client.mutate({
        mutation: VERIFY_LOGIN_OTP,
        variables: { mobileNumber: loginField, otp: otp, websiteId: 1 },
      });
      if (data) {
        if (data.loginOTPVerify.status) {
          const { getUserInfo, getGuestAndCustomerCartId } = this.context;
          const token = data.loginOTPVerify.token;
          await tokenClass.setToken(token);
          await getUserInfo();
          await getGuestAndCustomerCartId();

          this.setState({ isLoading: false })
          this.navigateToLastScreen();
        } else {

          this.setState({ isLoading: false })
          showErrorMessage(data.loginOTPVerify.message, 'top');
        }
      }
    } catch (err) {

      this.setState({ isLoading: false })
      const msg = handleError(err);
      showErrorMessage(msg, 'top');
    }
  }

  render() {
    const {
      loginField,
      password,
      showPassword,
      loginFieldError,
      passwordError,
      isVerifiedData,
      showOtp,
      otp,
    } = this.state;
    const { navigation } = this.props;
    const activeGuestCart = navigation.getParam('activeGuestCart', false);
    return (
      <View style={styles.loginPageContainer}>
        <Spinner
          visible={this.state.isLoading}
          // textContent={''}
          // textStyle={{ color: colors.White }}
          indicatorStyle={{ activeOpacity: 1 }}
        />
        <View style={{ flex: 1 }}>
          {!showOtp ? (
            <ScrollView
              contentContainerStyle={[
                styles.loginScreenWrapper,
                this.state.isKeyboard
                  ? { justifyContent: 'flex-start' }
                  : null,
              ]}
              keyboardDismissMode="interactive"
              keyboardShouldPersistTaps="handled">
              <View style={{ width: '100%', position: 'absolute', bottom: 0 }}>
                <Image source={require('../../../../../../assets/loginbg.png')} style={{ width: '100%' }} resizeMode={'contain'} />
              </View>
              <View style={styles.logoMinView}>
                <Image source={require('../../../../../../assets/logo.png')} style={{ width: '50%', }} resizeMode={'contain'} />
                <Text style={{ fontSize: 20, color: colors.blueColor }}>Welcome to Dentalkart</Text>
              </View>

              <View style={styles.midView}>
                {console.warn('error : ', loginFieldError)}
                <View style={[styles.emailTextInputView, { borderColor: loginFieldError ? colors.red : colors.borderColor }]}>
                  <Icon name='email' type='Fontisto' style={styles.emailIcon} />
                  <TextInputComponent placeholder='Enter Email / Mobile Number'
                    placeholderTextColor={SecondaryColor}
                    onChangeText={loginField => {
                      console.warn('login field: ', loginField)
                      loginField = loginField.replace(/\s/g, '');
                      this.validate('loginField', loginField)
                    }
                    }
                    value={loginField}
                    autoCapitalize="none"
                    style={{}}
                    onSubmitEditing={() => {
                      this.emailInput.focus()
                    }}
                    // error={loginFieldError}
                    returnKeyType='next'
                    blurOnSubmit={false}
                    autoFocus={true}
                    keyboardType="email-address"
                  />
                </View>
                {isVerifiedData && this.state.email == "" ?
                  <View style={{ marginBottom: responsiveHeight(-1), width: '90%' }}>
                    <Text style={[styles.textError, { fontFamily: fonts.LatoBold }]}>Enter Email.</Text>
                  </View> : null
                }
                <View style={[styles.emailTextInputView, { borderColor: passwordError ? colors.red : colors.borderColor, marginTop: 12 }]}>
                  <Icon name='lock' type='SimpleLineIcons' style={styles.emailIcon} />
                  <TextInputComponent placeholder='Password'
                    placeholderTextColor={SecondaryColor}
                    onChangeText={password => {
                      password = password.replace(/\s/g, '')
                      this.validate('password', password)
                    }
                    }
                    value={password}
                    autoCapitalize="none"
                    returnKeyType="done"
                    id={(input) => { this.emailInput = input; }}
                    secureTextEntry={!showPassword}
                  />

                  <TouchableOpacity
                    onPress={() =>
                      this.setState({
                        showPassword: !this.state.showPassword,
                      })
                    }
                    style={styles.eyeIcon}>
                    <Icon
                      name={this.state.showPassword ? 'eye-off' : 'eye'}
                      color={
                        this.state.password ? SecondaryColor : '#ddd'
                      }
                      style={{ fontSize: 22, color: colors.blueColor }}
                      type='MaterialCommunityIcons'
                    />
                  </TouchableOpacity>
                </View>

                <Pressable style={[styles.phoneNumberView, { marginBottom: this.state.isLogin ? -8 : null }]} onPress={this.phoneLogin}>
                  <Text style={{}}><Text style={{ color: colors.text }}>Or login with </Text><Text style={{ color: colors.normalText }}> Mobile Number, OTP</Text></Text>
                </Pressable>

                <TouchableCustom
                  underlayColor={'#ffffff10'}
                  onPress={() =>
                    isVerifiedData ? this.login() : null
                  }>
                  <View
                    style={isVerifiedData
                      ? styles.loginBtn : styles.loginBtnDisabled}>
                    <Text style={styles.signInButtonText}>Sign In</Text>
                  </View>
                </TouchableCustom>

              </View>

              <View style={styles.footerView}>
                <Text style={{ color: '#9098B1', fontSize: 14, marginVertical: 15, }}>OR</Text>
                {Platform.OS == 'android' ?
                  <View style={{ top: -13, width: '100%', alignItems: 'center', justifyContent: 'center' }}
                  >
                    <GoogleLogin getUserData={this.googleLogin} />
                    {appleAuth.isSupported ?
                      <AppleLogin getUserData={this.appleLogin} />
                      : null}

                  </View>
                  : null}

                <Pressable style={{ marginTop: -5, }} onPress={() =>
                  this.props.navigation.navigate('ForgotPassword')
                }>
                  <Text style={{ color: colors.normalText, fontSize: 12 }}>Forgot Password?</Text>
                </Pressable>
                <Pressable onPress={() =>
                  this.props.navigation.navigate('SignUp')
                }
                  style={{ marginTop: 8 }}
                >
                  <Text style={{ fontSize: 12 }}><Text style={{ color: colors.text }}>Don't have an account?</Text><Text style={{ color: colors.normalText }}> Register</Text></Text>
                </Pressable>
                {!activeGuestCart && (

                  <TouchableOpacity
                    style={styles.OtherFormNavigatorWrapper}
                    onPress={() => this.navigateToLastScreen('later')}>
                    <Text style={styles.OtherFormNavigatorText}>
                      I'll Login Later
                          </Text>
                  </TouchableOpacity>

                )}
              </View>

            </ScrollView>
          ) : (
            this.state.isPhoneLogin ?
              <Otp
                _this={this}
                resendOtp={this.phoneLoginResendOTP}
                shouldShow={this.state.shouldShow}
                completeOTPTimer={this.completeOTPTimer}
                confirmOtp={this.phoneLoginConfirmOTP}
              /> :
              <Otp
                _this={this}
                resendOtp={this.resendSignUpOtp}
                generateToken={generateToken}
                confirmOtp={this.confirmOtp}
              />
          )}
        </View>
      </View>
    );
  }
}
