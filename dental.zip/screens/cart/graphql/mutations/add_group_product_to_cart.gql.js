import gql from "graphql-tag";
import toSource from "@helpers/toSource";

const  ADD_GROUP_PRODUCTS_TO_CART = (options) => (
    gql`
        mutation addSimpleProductsToCart($cart_id : String!){
            addSimpleProductsToCart(
                input: {
                  cart_id: $cart_id
                  cart_items : ${options.length>0 ? options.toSource() : `[]`}
                }
              ) {
            cart {
              items {
                id
                product {
                  name
                  sku
                }
                quantity
              }
            }
        }
   }`
);
export default ADD_GROUP_PRODUCTS_TO_CART;
