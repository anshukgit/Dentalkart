import gql from "graphql-tag";
import {ProductListingFragment} from '../fragments/product_listing_fragment.gql.js';

const UPDATE_CART_ITEM = gql`
	mutation updateCartItems($cart_id: String!, $cart_item_id: Int!, $quantity:Float!){
        updateCartItems(
            input: {
                cart_id : $cart_id,
                cart_items: [
                    {
                        cart_item_id: $cart_item_id
                        quantity: $quantity
                    }
                ]
            }
        )
        {
            cart{
                total_quantity
                ...ProductListingFragment
                applied_coupons {
                    code
                }
                prices {
					grand_total{
						value
						currency
					}
					subtotal_including_tax{
						 value
						 currency
					}
					subtotal_excluding_tax{
						value
						currency
					}
					subtotal_with_discount_excluding_tax{
						value
						currency
					}
					discount{
					   amount{
						   value
						   currency
						   currency_symbol
					   }
					   label
			        }
					rewardsdiscount{
			            amount{
			                value
			                currency
							currency_symbol
		                 }
	                    label
	                }
				   applied_taxes{
						amount{
							value
							currency
						}
						label
					}
					 total_savings{
						value
						currency
					}
                }
            }
        }
    }
    ${ProductListingFragment}
`;

export default UPDATE_CART_ITEM;
