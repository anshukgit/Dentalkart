import gql from "graphql-tag";
import CART_FRAGMENT from './cart_fagment.gql';
import {ProductListingFragment} from '../fragments/product_listing_fragment.gql.js';
const APPLY_COUPON = gql`
	mutation applyCoupon($cart_id: String!, $coupon_code: String!){
        applyCouponToCart(
            input: {
                cart_id : $cart_id,
                coupon_code : $coupon_code
            }
        )  {
                cart {
					total_quantity
					...ProductListingFragment
		            applied_coupons {
		                code
		            }
		            prices {
						grand_total{
							value
							currency
						}
						subtotal_including_tax{
							 value
							 currency
						}
						subtotal_excluding_tax{
							value
							currency
						}
						subtotal_with_discount_excluding_tax{
							value
							currency
						}
					   applied_taxes{
							amount{
								value
								currency
							}
							label
						}
						 total_savings{
							value
							currency
						}
		            }
                }
            }
	}
	${ProductListingFragment}
`;
export default APPLY_COUPON;
