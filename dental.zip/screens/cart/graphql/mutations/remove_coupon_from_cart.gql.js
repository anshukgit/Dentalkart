import gql from "graphql-tag";
import CART_FRAGMENT from './cart_fagment.gql';

const REMOVE_COUPON = gql`
	mutation removeCouponFromCart($cart_id: String!){
       removeCouponFromCart(
            input:{ cart_id : $cart_id }
        ) {
            cart{
                items{
                    product {
                      name
                }
                    quantity
                }
                applied_coupons {
                    code
                }
                prices {
					grand_total{
						value
						currency
					}
					subtotal_including_tax{
						 value
						 currency
					}
					subtotal_excluding_tax{
						value
						currency
					}
					subtotal_with_discount_excluding_tax{
						value
						currency
					}
				   applied_taxes{
						amount{
							value
							currency
						}
						label
					}
					 total_savings{
						value
						currency
					}
                }
            }
        }
	}
`;
export default REMOVE_COUPON;
