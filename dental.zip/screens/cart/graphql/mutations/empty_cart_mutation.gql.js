import gql from "graphql-tag";

const GET_GUEST_CART_ID = gql`
    mutation {
        createEmptyCart
    }
`;
export default GET_GUEST_CART_ID;
