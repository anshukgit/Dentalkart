import gql from "graphql-tag";

const ADD_SIMPLE_PRODUCT_TO_CART = gql`
    mutation addSimpleProductsToCart($cart_id : String!, $qty: Float!, $sku : String!){
        addSimpleProductsToCart(
            input: {
              cart_id: $cart_id
              cart_items: [
                {
                  data: {
                    quantity: $qty
                    sku: $sku
                  }
                }
              ]
            }
          ) {
            cart {
              items {
                id
                product {
                  name
                  sku
                }
                quantity
              }
            }
       }
}`;

export default ADD_SIMPLE_PRODUCT_TO_CART;
