import gql from "graphql-tag";
import {ProductListingFragment} from '../fragments/product_listing_fragment.gql.js';

const REMOVE_CART_ITEM = gql`
	mutation removeItem($cart_id: String!, $cart_item_id: Int!){
        removeItemFromCart(
            input: {
                cart_id: $cart_id,
                cart_item_id: $cart_item_id
            }
        )
        {
            cart{
                total_quantity
                ...ProductListingFragment
                applied_coupons {
                      code
                }
                prices {
					grand_total{
						value
						currency
					}
					subtotal_including_tax{
						 value
						 currency
					}
					subtotal_excluding_tax{
						value
						currency
					}
					subtotal_with_discount_excluding_tax{
						value
						currency
					}
				   applied_taxes{
						amount{
							value
							currency
						}
						label
					}
					 total_savings{
						value
						currency
					}
                }
            }
        }
    }
    ${ProductListingFragment}
`;

export default REMOVE_CART_ITEM;
