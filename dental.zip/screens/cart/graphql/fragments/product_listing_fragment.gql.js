import gql from 'graphql-tag';

export const ProductListingFragment = gql`
    fragment ProductListingFragment on Cart {
        id
        items {
        id
        updated_at
        quantity
        discount
        prices{
             price{
                 value
                 currency
                 currency_symbol
             }
             row_total{
                 value
                 currency
                 currency_symbol
             }
             row_total_including_tax{
                 value
                 currency
                 currency_symbol
             }
             discounts{
                 amount{
                     value
                     currency
                     currency_symbol
                }
                label
            }
        }
        product{
            id
            name
            sku
            thumbnail{
                url
                label
            }
            price{
                regularPrice{
                    amount{
                        value
                        currency
                        currency_symbol
                    }
                }


            }
            type_id
			stock_status
			average_rating
			manufacturer
			url_path
			image{
			    label
			    url
			}
			weight
			is_cod
			url_key
			tier_prices{
				qty
				value
				percentage_value
			}
            dentalkart_custom_fee
		}
		brand_image
		qty_increments
		reward_point_product
		error_messages{
			code
			message
		}
		... on ConfigurableCartItem {
            configurable_options {
                id
                option_label
                value_id
                value_label
            }

        }
        ... on BundleCartItem {
             bundle_options {
                id
                label
                type
                values {
                    id
                    label
                    price
                    quantity
                }
            }
        }
    }
}
`;
