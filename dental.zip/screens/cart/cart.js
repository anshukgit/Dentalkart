import React, { Fragment, Component } from 'react';
import {
    View,
    ScrollView,
    Modal,
    ToastAndroid,
    FlatList,
    Text,
    TouchableOpacity, Pressable,
    Image,
} from 'react-native';
import { Query, Mutation } from 'react-apollo';
import EmptyCart from './modules/empty_cart';
import {
    APPLY_COUPON_MUTATION,
    REMOVE_COUPON_MUTATION,
    GET_NEW_CART,
    GUEST_NEW_CART,
} from './graphql';
import CartProducts from './modules/cart_products';
import BillingDetails from './modules/billing_details';
import SecurePayments from './modules/secure_payments';
import CartAction from './modules/cart_action';
import CouponForm from './modules/coupon_form';
import { CheckCashOnDelivery } from './modules/check_cod_section';
import { DeliveryAddressSection } from './modules/delivery_address';
import Header from '@components/header';
import Loader from '@components/loader';
import { client } from '@apolloClient';
import { getCartId } from '@helpers/cart_id';
import tokenClass from '@helpers/token';
import imageConstant from '@helpers/images';
import { GET_ADDRESSES_QUERY } from '@screens/address/graphql';
import { DentalkartContext } from '@dentalkartContext';
import CartRewards from '@screens/account/modules/rewards/modules/apply_rewards';
import { fireAnalyticsEvent } from '@helpers/firebase_analytics';
import brandingPageValidity from '@helpers/component_validity';
import { DeviceWidth as Width } from '@config/environment';
import { BrandingStartDate, BrandingEndDate } from '@config/environment';
import SyncStorage from '@helpers/async_storage';
import isInvalidCart from '@helpers/inActiveCartError.js';
import { showErrorMessage, showSuccessMessage } from '../../helpers/show_messages';
import colors from '@config/colors';
import styles from './cart.style'
import { Icon } from 'native-base'
import HeaderComponent from "@components/HeaderComponent";
const cart_banner = [
    {
        img:
            'https://dentalkart-media.s3.ap-south-1.amazonaws.com/6-12Jan2020/tcbannerforintraoralweeksale/Cart.jpg',
        url: 'waldent-premium-plus-led-airotor-wl-edtu.html',
    },
];

export default class Cart extends Component {
    static contextType = DentalkartContext;
    constructor(props) {
        super(props);
        this.state = {
            isCouponModal: false,
            prevCoupon: '',
            couponCode: '',
            couponStatus: false,
            guest_cart_id: 0,
            customer_cart_id: 0,
            addressModal: false,
            shippingAddress: '',
            pincode: '',
            isheart: false,
            cartCount: 1,
            isStockOutmodal: false,
            stockOutItem: '',
            similarProduct: [{ img: imageConstant.androidIcon, proname: 'Waldent Max Piezo 3+ Ultrosonic Scaler', proSmallDescription: 'Waldent Max Piezo 3+ Ultrosonic Scaler', disprice: 320, price: 1300 }, { img: imageConstant.androidIcon, proname: 'Waldent Max Piezo 3+ Ultrosonic Scaler', proSmallDescription: 'Waldent Max Piezo 3+ Ultrosonic Scaler', disprice: 320, price: 1300 }, { img: imageConstant.androidIcon, proname: 'Waldent Max Piezo 3+ Ultrosonic Scaler', proSmallDescription: 'Waldent Max Piezo 3+ Ultrosonic Scaler', disprice: 320, price: 1300 }, { img: imageConstant.androidIcon, proname: 'Waldent Max Piezo 3+ Ultrosonic Scaler', proSmallDescription: 'Waldent Max Piezo 3+ Ultrosonic Scaler', disprice: 320, price: 1300 }],
        };
    }
    backBtnPress() {
        this.props.navigation.navigate('Home')
    }

    onHeartPress() {
        this.setState({ isheart: !this.state.isheart })
    }
    postUpdateCart = async (cache, { data }) => {
        const { handleError, getCartItemCount, setShippingAddress } = this.context;
        const guest_cart_id = await SyncStorage.get('guest_cart_id');
        const customer_cart_id = await SyncStorage.get('customer_cart_id');
        const cart_id = (await tokenClass.loginStatus()) ? customer_cart_id : guest_cart_id;
        const query = (await tokenClass.loginStatus()) ? GET_NEW_CART : GUEST_NEW_CART;

        try {
            this.setState({ loader: true });

            if (data.applyCouponToCart || data.removeCouponFromCart) {
                this.setState({
                    isCouponModal: false,
                    couponCode: data.removeCouponFromCart ? '' : this.state.couponCode,
                });
            }

            if (data.removeItemFromCart && data.removeItemFromCart.cart) {
                getCartItemCount(data.removeItemFromCart.cart.items.length);
            }
            showSuccessMessage('Cart Updated Successfully.');
            await setShippingAddress();

        }
        catch (err) {
            const error = handleError(err);
            showErrorMessage(error);
        }

        this.setState({ loader: false });
    };

    getCartSkus = data => {
        const cartSkus = [];
        data.map((item, index) => cartSkus.push(item.sku));
        return JSON.parse(JSON.stringify(cartSkus));
    };

    scrollToBottom = () => { };

    checkAddress = async () => {
        let defaultAddress;
        let baseCountry = {
            country_id: this.context.country.country_id,
            country: this.context.country.country,
        };

        console.log(baseCountry);

        const { data } = await client.query({
            query: GET_ADDRESSES_QUERY,
            fetchPolicy: 'network-only',
        });
        data.customer.addresses.some(item => {
            if (
                item.default_shipping &&
                item.country_code === baseCountry.country_id
            ) {
                defaultAddress = item;
            }
            return item.default_shipping;
        });
        if (!defaultAddress) {
            if (data.customer.addresses.length > 0) {
                this.props.navigation.navigate('Address', { checkout: true });
            } else {
                this.props.navigation.navigate('EditAddress', { checkout: true });
            }
        } else {
            this.props.navigation.navigate('Payment', { item: defaultAddress });
        }
    };

    closeCouponModal = () => {
        this.setState({
            isCouponModal: false,
        });
    };

    navigateToProduct = item => {
        this.props.navigation.push('ProductDetails', {
            productUrl: item.product.url_path,
        });
    };

    triggerScreenEvent = _ => {
        const { userInfo } = this.context;
        const { navigation } = this.props;
        let { params } = navigation.state;
        const entry = params ? params.entry : false;
        fireAnalyticsEvent({
            eventname: 'screenname',
            screenName: 'Cart',
            entry,
            userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
        });
    };
   
    componentDidMount() {
        this.triggerScreenEvent();
    }
    async componentWillMount() {
        let guest_cart_id = await SyncStorage.get('guest_cart_id');
        let customer_cart_id = await SyncStorage.get('customer_cart_id');
        let shippingAddress = await SyncStorage.get('delivery_address');
        let pincode = await SyncStorage.get('pincode');
        let loginStatus = await tokenClass.loginStatus();
        this.setState({ guest_cart_id, customer_cart_id, loginStatus, shippingAddress, pincode });
    }

    similarProductMapping() {
        return this.state.similarProduct.map((data, index) => {
            return (
                <View style={[styles.shadow, styles.productMappingView]}>
                    <View style={[styles.productMappingImg, { backgroundColor: this.state.isStockOutmodal ? colors.white : colors.HexColor }]}>
                        <Image source={data.img} style={{ width: '90%', height: '90%' }} resizeMode={'contain'} />
                    </View>
                    <View style={styles.dissVIew}>
                        <Text numberOfLines={1} ellipsizeMode='tail' style={{ fontSize: 15, }}>{data.proname}</Text>
                        <Text numberOfLines={1} ellipsizeMode='tail' style={styles.productDiss}>{data.proSmallDescription}</Text>
                        <View style={styles.productMappingPriceMainView}>
                            <View style={styles.dispriceView}>
                                <Icon name="rupee" type="FontAwesome" style={styles.rupeeIcon} />
                                <Text style={styles.dispriceTxt}>{data.disprice}</Text>
                            </View>
                            <View style={[styles.dispriceView, { justifyContent: 'flex-start' }]} >
                                <Icon name="rupee" type="FontAwesome" style={{ fontSize: 10, color: colors.blueColor }} />
                                <Text style={{ fontSize: 15, color: colors.blueColor, }}>{data.price}</Text>
                            </View>
                        </View>
                    </View>
                </View>
            )
        })
    }
    render() {
        const { handleError, getGuestAndCustomerCartId } = this.context;
        const { navigation } = this.props;
        const isLoggedIn = this.state.loginStatus;
        const guest_cart_id = this.state.guest_cart_id;
        const customer_cart_id = this.state.customer_cart_id;
        const cart_id = isLoggedIn ? customer_cart_id : guest_cart_id;
        const query = isLoggedIn ? GET_NEW_CART : GUEST_NEW_CART;
        const validity = brandingPageValidity(BrandingStartDate, BrandingEndDate);
        return (
            <View style={{ backgroundColor: colors.HexColor, flex: 1 }}>
                {/* <Header back heading="Cart" navigation={this.props.navigation} /> */}
                {/* <HeaderComponent label={'Cart'} cartCount={this.state.cartCount} onPress={() => this.backBtnPress()} onHeartPress={() => this.onHeartPress()} isheart={this.state.isheart} /> */}
                <HeaderComponent label={'Cart'} onPress={() => this.backBtnPress()} style={{ height: 40 }} />
                <Query
                    query={query}
                    variables={{ cart_id: cart_id }}
                    fetchPolicy="network-only"
                    onError={async error => {
                        const shouldRetry = !error.networkError && isInvalidCart(error);
                        if (shouldRetry) {
                            await SyncStorage.remove('customer_cart_id');
                            await SyncStorage.remove('guest_cart_id');
                            await getGuestAndCustomerCartId();
                            return <Text>error!</Text>;
                        }
                        else {
                            showErrorMessage(`${error.message}. Please try again.`);
                        }
                    }}>
                    {({ data, loading, error }) => {
                        if (loading || error) {
                            return <Loader loading={loading} transparent={true} />;
                        } else if (data?.cart) {
                            if (data.cart.id) {
                                const { cart } = data;

                                console.warn('cart ...................', cart.product);
                                var arr = cart.items;
                                for (var i = 0; i < arr.length; i++) {
                                    var product = arr[i].product;
                                    if (product.stock_status != 'OUT_OF_STOCK') {
                                        console.warn('yes')
                                        // this.setState({ stockOutItem:arr[i] })
                                        break;
                                    }
                                }

                                const cartPrices = cart.prices;
                                const cart_totals = cart.prices.grand_total;
                                const currency = cartPrices.grand_total.currency_symbol;
                                const appliedCoupon =
                                    data.cart.applied_coupons != null &&
                                    data.cart.applied_coupons.length > 0 &&
                                    data.cart.applied_coupons[0].code;
                                const cartSkus = this.getCartSkus(data.cart.items);
                                const shippingAddress = cart.shipping_addresses;
                                const shippingamount =
                                    shippingAddress.length > 0 &&
                                    shippingAddress[0].available_shipping_methods.length > 0 &&
                                    shippingAddress[0].available_shipping_methods[0].amount;
                                if (!cart.items || cart.items.length === 0) {
                                    return <EmptyCart _this={this} />;
                                }
                                return (
                                    <Fragment>
                                        <ScrollView>
                                            <DeliveryAddressSection _this={this} />
                                            {/* {this.context.country.country_id === 'IN' && <CheckCashOnDelivery cartTotals={cart_totals} pincode={this.state.pincode} />} */}
                                            <Text style={{ paddingVertical: 7, paddingHorizontal: 20, backgroundColor: colors.HexColor, alignContent: 'center', top: -3 }}>{cart.items.length} items selected</Text>
                                            <FlatList
                                                data={cart.items}
                                                renderItem={({ item, index }) => (
                                                    <CartProducts
                                                        item={item}
                                                        Query={query}
                                                        currency={currency}
                                                        postUpdateCart={this.postUpdateCart}
                                                        _this={this}
                                                        navigateToProduct={this.navigateToProduct}
                                                        navigation={navigation}
                                                    />
                                                )}
                                                extraData={cart.items}
                                                keyExtractor={item => item.id.toString()}
                                            />

                                            {/* <View style={{ width: '100%', height: 18, backgroundColor: colors.white }}></View> */}




                                            {/* { validity &&
                							<View style={{flexDirection:'row', flexWrap:'wrap'}}>
                							   {
                									dkcart_banner.map((data,index)=>
                										<TouchableOpacity  onPress={() => navigation.push('UrlResolver', { url_key: data.url})}>
                											<Image source={{uri:data.img}} style={{
                                                                width: Width,
                                                                height: Width*120/428,
                                                                resizeMode: 'cover',
                                                                marginBottom:8
                                                            }}></Image>
                										</TouchableOpacity>
                									)
                							   }
                							</View>
                            } */}
                                            {isLoggedIn ? (
                                                <CartRewards
                                                    postUpdateCart={this.postUpdateCart}
                                                    _this={this}
                                                />
                                            ) :
                                                null
                                            }
                                            <Mutation
                                                mutation={appliedCoupon ? REMOVE_COUPON_MUTATION : APPLY_COUPON_MUTATION}
                                                variables={{
                                                    coupon_code: appliedCoupon ? appliedCoupon : this.state.couponCode,
                                                    cart_id: cart_id,
                                                }}
                                                onError={error => {
                                                    showErrorMessage(handleError(error));
                                                }}
                                                refetchQueries={() => {
                                                    return [
                                                        {
                                                            query: query,
                                                            variables: { cart_id: cart_id },
                                                        },
                                                    ];
                                                }}
                                                onCompleted={() => {
                                                    showSuccessMessage('cart updated successfully.');
                                                }}
                                                update={this.postUpdateCart}>
                                                {(coupon, { loading, error }) => {
                                                    return (
                                                        <View>
                                                            <Modal
                                                                visible={this.state.isCouponModal}
                                                                transparent={true}
                                                                animationType="fade"
                                                                onRequestClose={() =>
                                                                    this.setState({ isCouponModal: false })
                                                                }>
                                                                <CouponForm
                                                                    _this={this}
                                                                    cart={cart}
                                                                    appliedCoupon={appliedCoupon}
                                                                    coupon={coupon}
                                                                    DataLoading={loading}

                                                                />
                                                            </Modal>
                                                            <BillingDetails
                                                                cartPrices={cartPrices}
                                                                cart={cart}
                                                                couponMutation={coupon}
                                                                DataLoading={loading}
                                                                shippingamount={shippingamount}
                                                                appliedCoupon={appliedCoupon}
                                                                _this={this}
                                                                postUpdateCart={this.postUpdateCart}
                                                            />
                                                        </View>)

                                                }}
                                            </Mutation>
                                            <View style={[styles.similarProductMainView, { marginBottom: 20 }]}>
                                                <View style={{ width: '100%' }}>
                                                    <Text style={[styles.youalsoLikeText, {}]}>You also may like</Text>
                                                </View>
                                                <View style={[styles.similarProductSubView, {}]}>
                                                    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
                                                        {this.similarProductMapping()}
                                                    </ScrollView>
                                                </View>
                                            </View>
                                            <SecurePayments />
                                        </ScrollView>
                                        <CartAction
                                            data={cartPrices}
                                            navigation={navigation}
                                            title="Continue"
                                            disabled={cart.global_errors}
                                            userInfo
                                            _this={this}
                                            title={cart.error_message}
                                        />
                                    </Fragment>
                                );
                            } else {
                                return <EmptyCart _this={this} />;
                            }
                        } else {
                            <Text>Some error occurered</Text>;
                        }
                    }}
                </Query>
                {this.state.isStockOutmodal ?
                    <Modal isVisible={this.state.isStockOutmodal}
                        animationInTiming={1000}
                        animationOutTiming={1000}
                        transparent={true}
                        animationIn="fadeIn"
                        animationOut="fadeOut"
                        // onSwipeComplete={() => this.setState({ isModalVisibal: false })}
                        style={{ margin: 0, justifyContent: "center", alignItems: 'center' }}
                    >
                        <View style={styles.modalMainView}>
                            <View style={styles.stockOutModalEmptyView}>

                            </View>
                            <View style={styles.modalSubView}>
                                <ScrollView>
                                    <View style={styles.StockOutmodalSubView}>
                                        <Text style={styles.StockOutText}>This product  is  stock out</Text>

                                        <Text style={styles.eitherTxt}>Either remove the unavailable item or replace with recommended similar item</Text>
                                    </View>

                                    <View style={styles.StockOutProView}>
                                        <View style={styles.StockOutProimgView}>
                                            {/* <Image source={imageConstant.gloves} style={{ width: '100%', height: '100%' }} resizeMode={'cover'} /> */}
                                        </View>
                                        <View style={styles.StockOutDisView}>
                                            <Text style={styles.StockOutDisText}>ChlorHex Mouthwash</Text>
                                            <Text style={styles.dispersible}>Ketormore tromethamine dispersible tablets</Text>
                                            <View style={styles.priceMainView}>
                                                <View style={styles.priceView}>
                                                    <Icon name="rupee" type="FontAwesome" style={styles.priceIcon} />
                                                    <Text style={[styles.pricetext, { color: colors.blueColor, fontSize: 20 }]}>{1300}</Text>
                                                </View>

                                                <Pressable style={styles.unavilableView}>
                                                    <Text style={styles.unavilableText}>Unavailable</Text>
                                                </Pressable>
                                            </View>
                                        </View>
                                    </View>
                                    <View style={styles.StockOutFooterBtnView}>
                                        <Pressable style={styles.norecomendationsView}>
                                            <Text style={styles.norecomendationTxt}>No recommendations available</Text>
                                        </Pressable>
                                        <Pressable style={styles.notifyView}>
                                            <Text style={styles.notifyText}>Notify Me</Text>
                                        </Pressable>
                                    </View>

                                    <View style={[styles.similarProductMainView, { height: 190, }]}>
                                        <Text style={styles.youalsoLikeText}>You also may like</Text>
                                        <View style={[styles.similarProductSubView, { backgroundColor: colors.HexColor, }]}>
                                            <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
                                                {this.similarProductMapping()}
                                            </ScrollView>
                                        </View>
                                    </View>

                                    <Pressable style={styles.footerBtnView} onPress={() => this.removeBtnPress()} >
                                        <Text style={styles.removeBtnTxt}>Remove 1 product and proceed</Text>
                                    </Pressable>
                                </ScrollView>

                            </View>
                        </View>
                    </Modal>
                    : null}
            </View>
        );
    }
}
