import React, { Component } from 'react';
import { Text, View, FlatList, Pressable } from 'react-native';
import TouchableCustom from '@helpers/touchable_custom';
import MIcon from 'react-native-vector-icons/MaterialIcons';
import styles from './billing_details.style';
import NIcon from 'react-native-vector-icons/EvilIcons';

const _handleCouponNavigatePress = (navigate, routeName, appliedCoupon, _this) => {
    this.requestAnimationFrame(() => {
        _this.setState({
            isCouponModal: true,
            prevCoupon: appliedCoupon
        });
    });
}

export default class BillingDetails extends Component {
    render() {
        const { cartPrices, _this, postUpdateCart, appliedCoupon, cart, shippingamount, DataLoading, couponMutation } = this.props;
        const { navigate } = _this.props.navigation;
        const acceptedKeys = {
            "subtotal_including_tax": {
                'key': 'Sub Total',
                'value': cartPrices.subtotal_including_tax.value.toFixed(2),
                'currency': cartPrices.subtotal_including_tax.currency_symbol ? cartPrices.subtotal_including_tax.currency_symbol : cartPrices.subtotal_including_tax.currency,
                'visiblity': true,
                'modal': false,
            },
            "shipping": {
                'key': 'Delivery Charges',
                'value': shippingamount && shippingamount.value.toFixed(2),
                'currency': shippingamount && (shippingamount.currency_symbol ? shippingamount.currency_symbol : shippingamount.currency),
                'modal': true,
                'modal_title': ``,
                'visiblity': shippingamount ? true : false,
            },
            "overweight_delivery_charges": {
                'key': 'Overweight delivery charges',
                'value': cartPrices.overweight_delivery_charges.value.toFixed(2),
                'currency': cartPrices.overweight_delivery_charges.currency_symbol ? cartPrices.overweight_delivery_charges.currency_symbol : cartPrices.overweight_delivery_charges.currency,
                'visiblity': parseFloat(cartPrices.overweight_delivery_charges.value) > 0 ? true : false,
                'modal': false,
            },
            "discount": {
                'key': 'Coupon Applied',
                'value': cartPrices.discount != null ? cartPrices.discount.amount.value.toFixed(2) : 0,
                'currency': cartPrices.discount != null && (cartPrices.discount.amount.currency_symbol ? cartPrices.discount.amount.currency_symbol : cartPrices.discount.amount.currency),
                'visiblity': (cartPrices.discount != null && cartPrices.discount.amount.value) ? true : false,
                'modal': false,
            },
            "total_savings": {
                'key': 'Total Savings',
                'value': cartPrices.total_savings.value.toFixed(2),
                'currency': cartPrices.total_savings.currency_symbol ? cartPrices.total_savings.currency_symbol : cartPrices.total_savings.currency,
                'modal': false,
                'visiblity': true,
                'style': {
                    fontSize: 12,
                    color: 'green'
                }
            },
            "rewardsdiscount": {
                'key': `Reward Discount`,
                'value': (cartPrices.rewardsdiscount != null && cartPrices.rewardsdiscount.amount != null) ? cartPrices.rewardsdiscount.amount.value.toFixed(2) : 0,
                'currency': (cartPrices.rewardsdiscount != null && cartPrices.rewardsdiscount.amount != null) && (cartPrices.rewardsdiscount.amount.currency_symbol ? cartPrices.rewardsdiscount.amount.currency_symbol : cartPrices.rewardsdiscount.amount.currency),
                'visiblity': (cartPrices.rewardsdiscount != null && cartPrices.rewardsdiscount.amount != null && cartPrices.rewardsdiscount.amount.value) ? true : false,
                'modal': false,
            },
        }
        return (
            <View>
                {
                    (appliedCoupon) ? (
                        <TouchableCustom
                            underlayColor={'#ffffff10'}
                            onPress={() => (!DataLoading ? couponMutation() : null)}>
                            <View style={[styles.couponeCodeView, {}]}>
                                <View style={[styles.couponeSubView, { height: 45 }]}>
                                    <View style={{}}>
                                        <Text style={styles.couponButtonText}>Applied coupon ({appliedCoupon}) </Text>
                                        <Text style={styles.couponText}>You save {acceptedKeys.discount.currency}{Math.abs(acceptedKeys.discount.value)}</Text>
                                    </View>
                                    <View style={{}}>
                                        <Text style={styles.couponButtonText}>
                                            {!DataLoading ? `Remove` : 'Removing...'}
                                        </Text>
                                    </View>
                                </View>
                            </View>
                        </TouchableCustom>

                    ) :
                        (
                            <View style={[styles.couponeCodeView, {}]}>
                                <View style={styles.couponeSubView}>
                                    <Text style={{ fontSize: 13, color: '#292929' }}>Apply coupon code</Text>
                                    <Pressable style={{ height: '100%',  justifyContent: 'center', alignItems: 'center' }} onPress={() => _handleCouponNavigatePress(navigate, 'Coupon', appliedCoupon, _this)}>
                                        <Text style={{ fontSize: 12, color: colors.orangeBtn, }}>Apply couponcode</Text>
                                    </Pressable>
                                </View>
                            </View>
                        )
                }



                <View style={styles.PriceDetailWrapper}>
                    <View style={styles.priceDetailView}>
                        <Text style={styles.priceDetailText}>Price detail</Text>
                    </View>
                    <View style={styles.detailWrapper}>
                        <FlatList
                            data={Object.keys(acceptedKeys)}
                            renderItem={({ item, index }) => {
                                console.log(acceptedKeys[item]);
                                return (
                                    acceptedKeys[item].visiblity ?
                                        <View style={styles.detail}>
                                            <Text style={styles.detailTitle}>{acceptedKeys[item].key}</Text>
                                            <Text style={styles.detailValue}>{acceptedKeys[item].currency}{acceptedKeys[item].value}</Text>
                                        </View> : null
                                )
                            }}
                            keyExtractor={(item, index) => index.toString()}
                            extractData={cart}
                        />
                          <View style={[styles.priceDetailView, {  flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',borderTopWidth: 2, borderTopColor: colors.HexColor, borderBottomWidth:0 }]}>
                            <View style={styles.totalAmountTitleWrapper}>
                                <Text style={styles.totalAmountTitle}>Grand Total</Text>
                                <Text style={styles.totalAmountSubTitle}>(inclusive of all taxes)</Text>
                            </View>
                            <Text style={styles.totalAmountValue}>{cartPrices.grand_total.currency_symbol ? cartPrices.grand_total.currency_symbol : cartPrices.grand_total.currency}{cartPrices.grand_total.value.toFixed(2)}</Text>
                        </View>
                    </View>
                </View>
            </View>
        )
    }
}
