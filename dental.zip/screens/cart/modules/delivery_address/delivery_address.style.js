import { StyleSheet, Dimensions } from 'react-native';

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
import colors from '@config/colors';
export default styles = StyleSheet.create({
    // containerWrapper:{
    //     marginRight: 8,
    //     marginLeft: 8,
    // },
    addressCard: {
        backgroundColor: '#fff',
        padding: 10,
        marginBottom: 3,
        textAlign: 'justify',
        width: '100%', minHeight: 10, flexDirection: 'row', justifyContent: 'space-evenly', paddingVertical: 3, borderBottomWidth: 1, marginTop: 7, borderBottomColor: '#EBF0FF'
    },
    linkText:{
        padding: 8,
        // textDecorationLine: "underline",
        textDecorationStyle: "solid",
        color: "#000",
    },
    activeCard:{
        backgroundColor: '#fff8ea'
    },
    addressMainView: { height: '100%', backgroundColor: colors.white, padding: 10, flexDirection: 'row', alignItems: 'center' },
    addressIconView: { width: '10%',justifyContent:'center', alignItems: 'center', },
    addressIconsubView: { width: 20, height: 20, borderRadius: 20, backgroundColor: colors.PattensBlue, justifyContent: 'center', alignItems: 'center' },
    locationIcon:{ fontSize: 12, color: '#365F71' },
    addressView:{ minHeight: 70, width: '90%' },
    addressCount:{ fontSize: 18, color: '#000',fontWeight:'bold' },
    address:{ fontSize: 14, color: colors.normalText, },
    defaultAddressTxt:{ fontWeight: 'bold', lineHeight: 15, marginTop: 15,fontSize:13 },
    modalMainView:{ flex: 1, width: '100%', backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
    addressModalView:{ width: '95%', height: 400, backgroundColor: '#fff', borderRadius: 8,paddingBottom:5 },
    modalHeaderView:{ width: '100%', flex: 0.1, borderBottomWidth:5, justifyContent: 'center', paddingHorizontal: 15, flexDirection: 'row', borderBottomColor: colors.HexColor },
    locationTxtView:{ width: '80%', height: '100%', justifyContent: 'center' },
    locationTxt:{ fontSize: 18, fontWeight: '700' },
    closeIconView:{ width: '20%', height: '100%', justifyContent: 'center', alignItems: 'flex-end' },
    closeIcon:{ fontSize: 18 },
    midView:{ width: '100%', flex: 0.9, justifyContent: 'center',  flexDirection: 'row', paddingBottom: 3 },
    enterpinCodeTxt:{ marginTop: 5, marginBottom: 5, marginLeft: 8, textAlign: 'center' },
    deliveryView:{ width: '90%', height: '100%', },
    addressTouchable:{ display: 'flex', flexDirection: 'row' },
    shadow: {
        shadowColor: "#000",
        shadowOffset: {
          width: 0,
          height:Platform.OS=='android'?3: 1.5,
        },
        shadowOpacity: 0.35,
        shadowRadius: 2,
        elevation:Platform.OS=='android'? 3:1,
      },
      addressBox:{ width: 180, height: 160, margin: 10, borderRadius: 6, backgroundColor: '#fff', paddingHorizontal: 10 },
      PhoneIcon:{ fontSize: 18, color: colors.blueColor },
      AddShippingAddresssMainView:{ width: '100%', height: 60,  backgroundColor: colors.HexColor,justifyContent:'center',alignItems:'center' },
      AddShippingAddresssView:{width:'100%',height:50,backgroundColor:'#fff',justifyContent:'center',paddingHorizontal:5,top:5},
      orEnterView:{ width: '100%',top:-6,alignItems: 'center',justifyContent:'center' },
      orEnterTxt:{ fontSize: 15, color: '#aaa', fontWeight: '700' },
      addressSubView:{ flexDirection: 'row', justifyContent: 'space-between', width: '100%' },
      addressIconMainView:{ width: '15%', height: 50, top: 5 },
})
