import React, { useEffect, useState, useContext } from 'react';
import {
    View, ScrollView, Dimensions, SafeAreaView,
    Text, TouchableOpacity, FlatList, Image, Modal, Platform, Pressable
} from 'react-native';
import { client } from '@apolloClient';
import { GET_ADDRESSES_QUERY } from '@screens/address/graphql';
import SyncStorage from '@helpers/async_storage';
import styles from './delivery_address.style';
import Header from '@components/header';
import { DentalkartContext } from '@dentalkartContext';
import { CheckCashOnDelivery } from '../check_cod_section';
import { Icon } from 'native-base'
import colors from '@config/colors';
import {
    SecondaryColor,
    HeaderHeight,
    PrimaryTextColor,
    DeviceWidth,
} from '@config/environment';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
export const DeliveryAddressSection = ({ _this }) => {

    const [addressData, setAddressData] = useState([]);
    const { country } = useContext(DentalkartContext);

    const handleOpenAddressModal = () => {
        _this.setState({ addressModal: true })
    }

    const handleCloseAddressModal = () => {
        _this.setState({ addressModal: false })
    }

    const handleShippingAddressClick = async (data) => {
        if (data.id != shippingAddress.id) {
            await SyncStorage.set('delivery_address', data)
            await SyncStorage.set('pincode', data.postcode)
            _this.setState({ shippingAddress: data, addressModal: false, pincode: data.postcode })
        }
        else {
            handleCloseAddressModal();
        }

    }

    const getCustomerAddresses = async (client) => {
        try {
            const { data } = await client.query({
                query: GET_ADDRESSES_QUERY,
            });

            if (data && data.customer.addresses != null && data.customer.addresses.length > 0) {
                const storedAddress = await SyncStorage.get('delivery_address')
                const countryWiseAddress = data.customer.addresses.filter(data => data.country_code === country.country_id)
                const defaultAddress = countryWiseAddress.find(data => data.default_shipping === true)
                setAddressData(countryWiseAddress)
                if (!storedAddress && defaultAddress) {
                    await SyncStorage.set('delivery_address', defaultAddress)
                    country.country_id === 'IN' && await SyncStorage.set('pincode', defaultAddress.postcode)
                    _this.setState({ shippingAddress: defaultAddress, pincode: defaultAddress.postcode })
                }
            }
        }
        catch (e) {
            console.log(e);
        }
    }

    const AddShippingAddresss = () => {

        const handleNewAdddressClick = () => {
            _this.props.navigation.navigate('Address')
            _this.setState({ addressModal: false })
        }

        return (
            <TouchableOpacity onPress={() => handleNewAdddressClick()} style={{}}>
                <Text style={[styles.linkText, { color: colors.blueColor, fontWeight: 'bold', }]}>{`Add/Edit an address `}</Text>
            </TouchableOpacity>
        )
    }


    const DisplayAddressData = ({ data, index }) => {
        return (
            <TouchableOpacity style={[styles.shadow, _this.state.shippingAddress.id === data.id ? [styles.addressBox, { borderWidth: 1, borderColor: colors.blueColor }] : styles.addressBox]}
                onPress={() => handleShippingAddressClick(data)}
            >
                <Text style={[styles.addressCount, { lineHeight: 40 }]}>{data.firstname} {data.lastname}</Text>
                <View style={styles.addressView}>
                    <View style={styles.addressSubView}>
                        <View style={styles.addressIconMainView}>
                            <View style={[styles.addressIconsubView, {}]}>
                                <Icon name='ios-location-sharp' type='Ionicons' style={styles.locationIcon} />
                            </View>
                        </View>
                        <View style={{ width: '85%', padding: 3 }}>
                            <Text style={styles.address}>{data.street[0] ? `${data.street[0]}, ` : ''} {data.street[1] ? `${data.street[1]}, ` : ''} {data.city}, {data.region.region}, {data.postcode}.
                            </Text>
                        </View>

                    </View>
                    <Text style={[styles.address, { marginTop: 5 }]}><Icon name={'phone'} type={'FontAwesome'} style={styles.PhoneIcon} />  {data.telephone}
                    </Text>
                    {data.default_shipping ? <Text style={styles.defaultAddressTxt}>{`Your default address`}</Text> : null}
                </View>
            </TouchableOpacity>
        )
    }

    useEffect(() => {
        _this.state.loginStatus && getCustomerAddresses(client)
    }, [])

    const { shippingAddress, pincode } = _this.state

    return (
        <View>
            {shippingAddress ?
                <View style={[styles.addressCard,]}>
                    <TouchableOpacity style={styles.addressCard} onPress={() => handleOpenAddressModal()} style={styles.addressTouchable}>
                        <View style={styles.addressIconView}>
                            <View style={styles.addressIconsubView}>
                                <Icon name='ios-location-sharp' type='Ionicons' style={styles.locationIcon} />
                            </View>
                        </View>
                        <View style={styles.deliveryView}>
                            <Text style={styles.linkText}>
                                Deliver to {shippingAddress.firstname && shippingAddress.firstname.length > 12 ? `${shippingAddress.firstname.substring(0, 12)}...` : shippingAddress.firstname} - {shippingAddress.region.region && shippingAddress.region.region.length > 13 ? `${shippingAddress.region.region.substring(0, 13)}...` : shippingAddress.region.region}, {shippingAddress.postcode}
                            </Text>
                        </View>
                    </TouchableOpacity>
                </View> :
                <TouchableOpacity onPress={() => handleOpenAddressModal()} style={styles.addressCard}>
                    <Text style={styles.linkText}>{`Select delivery location`}</Text>
                </TouchableOpacity>

            }


            < Modal
                visible={_this.state.addressModal}
                transparent={true}
                animationType="fade"
                onRequestClose={() =>
                    _this.setState({ addressModal: false })
                }>
                <Pressable style={styles.modalMainView} >
                    <View style={[styles.addressModalView,]}  >
                        <View style={styles.modalHeaderView}>
                            <View style={styles.locationTxtView}>
                                <Text style={styles.locationTxt}>Choose your location</Text>
                            </View>
                            <Pressable style={styles.closeIconView} onPress={() => _this.setState({ addressModal: false })}>
                                <Icon name={'closecircleo'} type={'AntDesign'} style={styles.closeIcon} />
                            </Pressable>
                        </View>
                        <View style={styles.midView}>
                            <ScrollView showsVerticalScrollIndicator={false}>
                                {(_this.state.loginStatus) ?
                                    (
                                        <SafeAreaView style={styles.containerWrapper}>
                                            {addressData.length > 0 &&
                                                <FlatList
                                                    data={addressData}
                                                    renderItem={({ item, index }) => <DisplayAddressData data={item} index={index} />}
                                                    keyExtractor={(item, index) => index.toString()}
                                                    extraData={addressData}
                                                    horizontal
                                                    showsHorizontalScrollIndicator={false}
                                                />
                                            }

                                        </SafeAreaView>
                                    ) :
                                    <View style={{marginBottom:8,paddingHorizontal:11}}>
                                        <Text style={[styles.linkText,{color: colors.blueColor,textDecorationLine: "underline",}]} onPress={() => _this.props.navigation.navigate('Login')}>Login to see Your address</Text>
                                        {/* <Text style={styles.enterpinCodeTxt}>or Enter a Pincode</Text>
                                        {country.country_id === 'IN' && <CheckCashOnDelivery />} */}
                                    </View>
                                }

                                {(_this.state.loginStatus) ? <View style={styles.AddShippingAddresssMainView}>
                                    <View style={styles.AddShippingAddresssView}>
                                        <AddShippingAddresss />
                                    </View>
                                </View>
                                    : null}

                                <View style={styles.orEnterView}>
                                    <Text style={styles.orEnterTxt}>or enter a pincode </Text>
                                </View>
                                {country.country_id === 'IN' && <CheckCashOnDelivery />}
                            </ScrollView>
                        </View>

                    </View>
                </Pressable>
            </Modal>
        </View >
    )
}