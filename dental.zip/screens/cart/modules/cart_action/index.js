import React, { Component } from 'react';
import { Text, View, Pressable } from 'react-native';
import TouchableCustom from '@helpers/touchable_custom';
import styles from './cart_action.style';
import tokenClass from '@helpers/token';

export default class CartAction extends Component {
  render() {
    const { data, disabled, title, _this, navigation } = this.props;
    return (
      <View style={styles.cartActionContainer}>
        {disabled ? <Text style={styles.globalErrorText}>{title}</Text> : null}
        <View style={styles.cartActionWrapper}>
          {/* <View style={styles.shortSummaryWrapper}>
            <Text
              style={styles.shortSummaryPrice}
              onPress={() => _this.scrollToBottom()}>
              {data.grand_total.currency_symbol}
              {data.grand_total.value.toFixed(2)}
            </Text>
          </View> */}
          {/* <View style={styles.continueButtonWrapper}>
            <TouchableCustom
              underlayColor={'#ffffff10'}
              onPress= { async () => {
                    if(await tokenClass.loginStatus()){
                        if(_this.state.shippingAddress){
                            navigation.navigate('Payment', {item: _this.state.shippingAddress})
                        }
                        else {
                            _this.setState({addressModal:true})
                        }
                    }
                    else {
                        navigation.navigate('Login', { screen: 'Cart', activeGuestCart: true,})
                    }

                }}
              disabled={false}
             >
              <View
                style={[
                  styles.continueButton,
                  disabled ? styles.disabled : null,
                ]}>
                <Text style={styles.continueButtonText}>Continue</Text>
              </View>
            </TouchableCustom>
          </View> */}
          <View style={styles.footerView} >
            <Pressable style={styles.CheckoutView} onPress={async () => {
              if (await tokenClass.loginStatus()) {
                if (_this.state.shippingAddress) {
                  navigation.navigate('Payment', { item: _this.state.shippingAddress })
                }
                else {
                  _this.setState({ addressModal: true })
                }
              }
              else {
                navigation.navigate('Login', { screen: 'Cart', activeGuestCart: true, })
              }

            }} >
              <View
                style={[
                  styles.continueButton,
                  disabled ? styles.disabled : null,
                ]}>
                <Text style={styles.CheckoutText}>Checkout</Text>
              </View>
            </Pressable>
          </View>
        </View>
      </View>
    );
  }
}
