import {StyleSheet} from 'react-native';
import {DeviceWidth, SecondaryColor, PrimaryColor} from '@config/environment';
import colors from '@config/colors';
export default styles = StyleSheet.create({
    cartActionContainer: {
        backgroundColor: '#fff',
        elevation: 10,
        shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
        justifyContent: 'center',
    },
    globalErrorText: {
        textAlign: 'center',
        fontSize: 12,
        paddingBottom: 5,
        color: '#ed4949'
    },
    cartActionWrapper: {
        flexDirection: 'row',
    },
    shortSummaryWrapper: {
        width: DeviceWidth/2,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
    },
    shortSummaryPrice: {
        fontSize: 15,
        color: '#212121'
    },
    shortSummaryViewdetail: {
        color: SecondaryColor,
        fontSize: 12,
        fontWeight: 'bold'
    },
    continueButtonWrapper: {
        width: DeviceWidth/2,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    continueButton: {
        backgroundColor: PrimaryColor,
        // width: DeviceWidth/2,
        // height: 40,
        alignItems: 'center',
        justifyContent: 'center',
        // borderRadius: 2,
        // borderColor: '#b9b9b9',
		// elevation: 1,
        shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
    },
    continueButtonText: {
        color: '#fff',
        fontSize: 18
    },
    disabled: {
        opacity: 0.5
    },
    footerView: { height: 70,paddingBottom:5, backgroundColor: colors.white, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
    CheckoutView: { width: '100%', height: 43, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.orangeBtn },
    CheckoutText: { fontSize: 18, color: colors.white,fontWeight:'bold' },
})
