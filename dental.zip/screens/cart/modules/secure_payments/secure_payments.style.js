import {StyleSheet} from 'react-native';

export default styles = StyleSheet.create({
    securePaymentsContainer: {
        flex: 1,
        justifyContent: 'center',
        margin: 25,
        alignItems: 'center',
        flexDirection: 'row'
    },
    secureTextWrapper: {
        marginLeft: 7,
        alignItems: 'center'
    },
    secureText: {
        marginBottom: 3,
        color: '#999999',
        fontSize: 12,
    }
})
