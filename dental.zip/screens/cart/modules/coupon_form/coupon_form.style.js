import { StyleSheet, Platform } from 'react-native';
import { DeviceWidth, PrimaryColor, SecondaryColor } from '@config/environment';

export default styles = StyleSheet.create({
    couponFormWrapper: {
        backgroundColor: '#f1f3f6',
        padding: 1,
        borderRadius: 3,
        marginTop: 5,
        marginBottom: 5,
        marginRight: 8,
        marginLeft: 8,
        elevation: 5,
        shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
    },
    couponInputWrapper:{
        paddingLeft: 10,
        paddingRight: 10,
        backgroundColor: '#fff',
        margin: 10,
        paddingHorizontal: 10,
        paddingVertical: 10,
        flexDirection: 'row',
        alignItems: 'center'
    },
    couponInput: {
        backgroundColor: '#fff',
        marginRight: Platform.OS === 'ios' ? 10 : null,
        fontSize: 17,
        width: DeviceWidth - 150,
    },
    applyCouponButton: {
        width: Platform.OS === 'ios' ? 80 : 90,
        height: 23,
        // position: Platform.OS === 'ios' ? null : 'absolute',
        // right: Platform.OS === 'ios' ? null : 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor:'#42A9E2',
        borderRadius: 3,
        height:36,
    },
    applyCouponButtonText: {
        color: '#fff',
        fontSize: 14,
    },
    couponResponseWrapper: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginBottom: 5
    },
    couponResponseText: {
        fontSize: 13,
        color: SecondaryColor
    },
    appliedCouponWrapper: {
        flexDirection: 'row',
        paddingBottom: 10,
        paddingHorizontal: 20,
        alignItems: 'center'
    },
    appliedCouponCodeWrapper: {
        backgroundColor: 'green',
        flexDirection: 'row',
        alignItems: 'center',
        padding: 5,
        borderRadius: 50
    },
    appliedCouponCode: {
        color: '#fff',
        marginRight: 3
    },
    // couponRemoveWrapper: {
    // },
    couponRemoveText: {
        fontSize: 16,
        color: '#ff0000'
    },
    container: {
        flex: 1,
        marginBottom: 30,
  },
  item: {
    padding: 10,
    marginVertical: 5,
    marginHorizontal: 8,
    elevation: 2,
    backgroundColor: '#fff',
    shadowOpacity: 0.03,
    shadowRadius: 2,
  },
  title: {
    fontSize: 15,
    color:'#0f1f44'

  },
  titleDesc:{
    fontSize: 10,
  },
  couponeCodeTextView: { height: 20, width: 20, borderWidth: 1, borderRadius: 14, borderColor: colors.PattensBlue, justifyContent: 'center', alignItems: 'center' },
  modalMainView: { width: '100%', flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' },
  applyCouponcodeMainView: { height: 260, width: '93%',  backgroundColor: colors.white, borderRadius: 10, paddingHorizontal: 15,justifyContent:'center',alignItems:'center' },
  textInputView:{ width: '100%', height: '30%',  flexDirection: 'row', alignItems: 'center' },
  txtView:{ width: '65%', height: '100%', justifyContent: 'center', },
  textInput:{ fontSize: 14, height: '100%', height: 35, borderBottomWidth: 0.3 ,borderBottomColor:'#C6D2DE' },
  applyBtn:{ width: '35%', height: '100%', justifyContent: 'center', alignItems: 'flex-end' },
  couponsTxt:{ fontSize: 15, height: 20,fontWeight:'700' },
  codeBtn:{ width: '100%', height: '70%' },
  CouponModalView:{ flexDirection: 'row', alignItems: 'center', height: 30,borderBottomWidth:0.3,borderBottomColor:'#C6D2DE' },
  orangeDot:{ height: 14, width: 14, borderRadius: 14, backgroundColor: colors.orangeBtn },
  couponCodeTxtView:{ justifyContent: 'center',alignItems:'center' ,marginLeft:10},
})
