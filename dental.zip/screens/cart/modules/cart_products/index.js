import React, { Component } from 'react';
import { Text, View, Image, TouchableOpacity, ScrollView, Pressable, Alert } from 'react-native';
import { Mutation } from 'react-apollo';
import { UPDATE_CART_ITEM, REMOVE_CART_ITEM } from '../../graphql';
import { ADD_TO_WISHLIST_QUERY } from '../../../product/graphql';
import styles from './cart_products.style';
import QuantitySelector from '@components/quantity_selector';
import TouchableCustom from '@helpers/touchable_custom';
import MIcon from 'react-native-vector-icons/MaterialIcons';
import imageConstant from '@helpers/images';
import Loader from '@components/loader';
import { DentalkartContext } from '@dentalkartContext';
import SyncStorage from '@helpers/async_storage';
import tokenClass from '@helpers/token';
import { showErrorMessage, showSuccessMessage } from '../../../../helpers/show_messages';
import { Icon } from 'native-base'
import Modal from "react-native-modal";
import { client } from '@apolloClient';

export default class CartProducts extends Component {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    this.state = {
      item: props.item,
      showQuantity: true,
      guest_cart_id: 0,
      customer_cart_id: 0,
      loginStatus: false,
      isheart: false,
      isStockOutmodal: false,
      similarProduct: [{ img: imageConstant.androidIcon, proname: 'Waldent Max Piezo 3+ Ultrosonic Scaler', proSmallDescription: 'Waldent Max Piezo 3+ Ultrosonic Scaler', disprice: 320, price: 1300 }, { img: imageConstant.androidIcon, proname: 'Waldent Max Piezo 3+ Ultrosonic Scaler', proSmallDescription: 'Waldent Max Piezo 3+ Ultrosonic Scaler', disprice: 320, price: 1300 }, { img: imageConstant.androidIcon, proname: 'Waldent Max Piezo 3+ Ultrosonic Scaler', proSmallDescription: 'Waldent Max Piezo 3+ Ultrosonic Scaler', disprice: 320, price: 1300 }, { img: imageConstant.androidIcon, proname: 'Waldent Max Piezo 3+ Ultrosonic Scaler', proSmallDescription: 'Waldent Max Piezo 3+ Ultrosonic Scaler', disprice: 320, price: 1300 }],
    };
  }

  getStorageValue = async key => {
    return await SyncStorage.get(key);
  };
  componentDidUpdate() {
    if (this.state.item.qty !== this.props.item.qty) {
      this.setState({
        showQuantity: false,
        item: this.props.item,
      });
      setTimeout(() => this.setState({ showQuantity: true }), 100);
    }
  }
  async componentWillMount() {
    let guest_cart_id = await SyncStorage.get('guest_cart_id');
    let customer_cart_id = await SyncStorage.get('customer_cart_id');
    let loginStatus = await tokenClass.loginStatus();
    this.setState({ guest_cart_id, customer_cart_id, loginStatus });
  }
  getProductUrl() {
    const { navigation, item } = this.props;
    let urlKey = item.product.url_key;


    let productUrl = '';
    if (urlKey) {
      let urlSub = urlKey.replace('.html', '');
      if (urlSub.charAt(0) === '/') {
        urlSub = urlSub.slice(1);
      }
      productUrl = urlSub;
    }
    return productUrl;
  }
  async addToWishlist(id, _this) {
    const { navigation, } = this.props;
    let isLoggedIn = await tokenClass.loginStatus();
    let productUrl = this.getProductUrl();
    console.warn('product url === > ', productUrl, id)
    if (!isLoggedIn) {
      console.warn('false')
      navigation.navigate('Login', {
        screen: 'Cart',
        params: { productUrl: productUrl },
      });
    } else {
      try {
        const data = await client.mutate({
          mutation: ADD_TO_WISHLIST_QUERY,
          variables: { productId: id },
          fetchPolicy: 'no-cache',
        });
        return showSuccessMessage('Added to Wishlist');
      } catch (err) {
        console.log(err);
      }
    }
  }
  similarProductMapping() {
    return this.state.similarProduct.map((data, index) => {
      return (
        <View style={styles.similarProductMappingMainView}>
          <View style={[styles.similarProductImg, { backgroundColor: this.state.isStockOutmodal ? colors.white : colors.HexColor }]}>
            <Image source={data.img} style={{ width: '100%', height: '100%' }} resizeMode={'contain'} />
          </View>
          <View style={styles.dessView}>
            <Text numberOfLines={1} ellipsizeMode='tail' style={styles.proName}>{data.proname}</Text>
            <Text numberOfLines={1} ellipsizeMode='tail' style={styles.proSmallDescription}>{data.proSmallDescription}</Text>
            <View style={styles.similarProductPriceView}>
              <View style={styles.rupeeIconView}>
                <Icon name="rupee" type="FontAwesome" style={styles.rupeeIcon} />
                <Text style={styles.disPrice}>{data.disprice}</Text>
              </View>
              <View style={[styles.rupeeIconView, { justifyContent: 'flex-start' }]}>
                <Icon name="rupee" type="FontAwesome" style={styles.picerupeeIcon} />
                <Text style={styles.price}>{data.price}</Text>
              </View>
            </View>
          </View>
        </View>
      )
    })
  }

  

  openModal(id, removeFromCart, ) {
    Alert.alert(
      'Delete Cart Item',
      'Are you sure to delete this cart item?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {

          text: 'Delete',
          onPress: () => removeFromCart({ variables: { id: id }}),
        },
      ],
      { cancelable: false },
    );
  }


  render() {
    const {
      item,
      currency,
      _this,
      postUpdateCart,
      navigateToProduct,
      Query,
      navigation
    } = this.props;
    const guest_cart_id = this.state.guest_cart_id;
    const customer_cart_id = this.state.customer_cart_id;
    const cart_id = this.state.loginStatus ? customer_cart_id : guest_cart_id;
    const {
      prices: {
        row_total_including_tax: { value },
      },
    } = item;
    const tier_prices = item.product;
    const diss = tier_prices.tier_prices
    return (
      <View style={styles.cartItemMainView}>
        <View style={styles.cartItemSubView}>
          <View style={styles.cartItemImg}>
            <Image
              resizeMethod={'resize'}
              resizeMode={'contain'}
              source={{ uri: item.product.thumbnail.url }}
              style={styles.cartProductImage}
            />
          </View>

          <View style={styles.poductDessView}>
            <Text numberOfLines={2} ellipsizeMode='tail' style={styles.poductname}>{item.product.name}</Text>
            {this.context.country.country_id === 'IN' &&
              item.reward_point_product &&
              item.reward_point_product !== 0 ? (
              <View style={styles.rewardWrapper}>
                <Image
                  source={{
                    uri:
                      'https://s3.ap-south-1.amazonaws.com/dentalkart-media/React/coin.png',
                  }}
                  style={styles.rewardIcon}
                  resizeMode={'contain'}
                />
                <Text style={styles.rewardPoints}>
                  {item.reward_point_product}
                </Text>
              </View>
            ) : null}
            <View
              style={[
                styles.priceView,
                item.quantity != 1 ? styles.priceWrapperMargin : false,
              ]}>
              <Text style={styles.priceText}>
                {currency}
                {value}
              </Text>
              {item.quantity > 1 && (
                <Text style={[styles.priceText, {}]}>
                  ({currency} {(value / item.quantity).toFixed(2)} each)
                </Text>
              )}
            </View>
            {item.product.dentalkart_custom_fee != null && item.product.dentalkart_custom_fee > 0 ?
              <View>
                <Text style={styles.deliveryFee}>+ {currency + item.product.dentalkart_custom_fee} Delivery Charges</Text>
              </View>
              : null}

            {item.product.stock_status == 'OUT_OF_STOCK' ? (
              null
            ) :
              diss.map((data, index) => {
                return (
                  <View style={[styles.cartItemOfferView, { top: 2 }]}>
                    {data.qty <= item.quantity ? null :<Text style={styles.offerView}>Buy {data.qty - item.quantity} more to get at <Icon name="rupee" type="FontAwesome" style={[styles.offerView, { fontSize: 9 }]} />{data.value} each </Text>}
                  </View>
                )
              })
            }

            <View style={styles.qtyBtnView}>
              <View style={styles.stockOutBtnView}>
                {item.product.stock_status == 'OUT_OF_STOCK' ? (

                  <View style={styles.stockOutBtn}>
                    <Text style={styles.stockOutTxt}>Stock out</Text>
                  </View>
                ) :

                  <Mutation
                    mutation={UPDATE_CART_ITEM}
                    variables={{
                      cart_item_id: item.id,
                      quantity: item.quantity,
                      cart_id: cart_id,
                    }}
                    update={postUpdateCart}
                    refetchQueries={() => {
                      return [
                        {
                          query: Query,
                          variables: { cart_id: cart_id },
                        },
                      ];
                    }}
                    onError={error => {
                      showErrorMessage(`${error.message}. Please try again.`);
                    }}>
                    {(updateCart, { loading, error }) => {
                      if (loading || !this.state.showQuantity) {
                        return <Loader loading={true} transparent={true} />;
                      }
                      return (
                        <View style={styles.quantityWrapper}>
                          <QuantitySelector
                            qty={item.quantity}
                            id={item.id}
                            sku={item.sku}
                            cart_this={_this}
                            title="cart"
                            updateQuantity={(qty, id) =>
                              updateCart({
                                variables: {
                                  cart_item_id: parseInt(item.id),
                                  quantity: qty,
                                  cart_id: cart_id,
                                },
                              })
                            }
                          />
                        </View>
                      );
                      return null;
                    }}
                  </Mutation>
                }
              </View>
              <TouchableOpacity style={[styles.shadow, styles.heartBtnView, {}]} onPress={() => this.addToWishlist(item.product.id, item.sku, _this, navigation)} >
                <Icon name={'heart'} type={'AntDesign'} style={styles.heartIcon} />
              </TouchableOpacity>
              <View style={[styles.shadow, styles.heartBtnView]} >
                <Mutation
                  mutation={REMOVE_CART_ITEM}
                  variables={{ cart_item_id: item.id, cart_id: cart_id }}
                  update={postUpdateCart}
                  refetchQueries={() => {
                    return [
                      {
                        query: Query,
                        variables: { cart_id: cart_id },
                      },
                    ];
                  }}
                  onCompleted={() => {
                    showSuccessMessage('Removed items from cart successfully.');
                  }}
                  onError={error => {
                    showErrorMessage(`${error.message}. Please try again.`);
                  }}>
                  {(removeFromCart, { loading, error }) => {
                    return (
                      <View>
                      <TouchableCustom
                        underlayColor={'#ffffff10'}
                        onPress={() =>
                          this.openModal(item.id, removeFromCart)
                        }>
                        <View style={[styles.productRemoveAction, {}]}>
                          <Image source={imageConstant.delete} style={styles.deleteImg} resizeMode={'contain'} />
                        </View>
                      </TouchableCustom>
                      {loading && <Loader loading={true} transparent={true} />}
                      </View>
                    );
                  }}
                </Mutation>
              </View>
            </View>
          </View>
        </View>
      
        <Modal isVisible={this.state.isStockOutmodal}
          animationInTiming={1000}
          animationOutTiming={1000}
          transparent={true}
          animationIn="fadeIn"
          animationOut="fadeOut"
          // onSwipeComplete={() => this.setState({ isModalVisibal: false })}
          style={{ margin: 0, justifyContent: "center", alignItems: 'center' }}
        >
          <View style={styles.modalMainView}>
            <View style={styles.stockOutModalEmptyView}>

            </View>
            <View style={styles.modalSubView}>
              <ScrollView>
                <View style={styles.StockOutmodalSubView}>
                  <Text style={styles.StockOutText}>This product  is  stock out</Text>

                  <Text style={styles.eitherTxt}>Either remove the unavailable item or replace with recommended similar item</Text>
                </View>

                <View style={styles.StockOutProView}>
                  <View style={styles.StockOutProimgView}>
                    {/* <Image source={imageConstant.gloves} style={{ width: '100%', height: '100%' }} resizeMode={'cover'} /> */}
                  </View>
                  <View style={styles.StockOutDisView}>
                    <Text style={styles.StockOutDisText}>ChlorHex Mouthwash</Text>
                    <Text style={styles.dispersible}>Ketormore tromethamine dispersible tablets</Text>
                    <View style={styles.priceMainView}>
                      <View style={styles.priceView}>
                        <Icon name="rupee" type="FontAwesome" style={styles.priceIcon} />
                        <Text style={[styles.pricetext, { color: colors.blueColor, fontSize: 20 }]}>{1300}</Text>
                      </View>

                      <Pressable style={styles.unavilableView}>
                        <Text style={styles.unavilableText}>Unavailable</Text>
                      </Pressable>
                    </View>
                  </View>
                </View>
                <View style={styles.StockOutFooterBtnView}>
                  <Pressable style={styles.norecomendationsView}>
                    <Text style={styles.norecomendationTxt}>No recommendations available</Text>
                  </Pressable>
                  <Pressable style={styles.notifyView}>
                    <Text style={styles.notifyText}>Notify Me</Text>
                  </Pressable>
                </View>

                <View style={[styles.similarProductMainView, { height: 190, }]}>
                  <Text style={styles.youalsoLikeText}>You also may like</Text>
                  <View style={[styles.similarProductSubView, { backgroundColor: colors.HexColor, }]}>
                    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
                      {this.similarProductMapping()}
                    </ScrollView>
                  </View>
                </View>

                <Pressable style={styles.footerBtnView} onPress={() => this.removeBtnPress()} >
                  <Text style={styles.removeBtnTxt}>Remove 1 product and proceed</Text>
                </Pressable>
              </ScrollView>

            </View>
          </View>
        </Modal>
      </View>

    );
  }
}
