import React from 'react';
// We need to import the connectHighlight to our import
import { connectHighlight } from 'react-instantsearch/connectors';
import { Text } from 'react-native';

const CustomHighlight = ({ highlight, attribute, hit }) => {
    const parsedHit = highlight({
        highlightProperty: '_highlightResult',
        attribute,
        hit,
    });
    const highlightedHit = parsedHit.map((part, idx) => {
        if (part.isHighlighted)
            return (
                <Text key={idx} style={{ fontWeight: 'bold' }}>
                    {part.value}
                </Text>
            );
        return part.value;
    });
    return <Text>{highlightedHit}</Text>;
}

export const Highlight = connectHighlight(CustomHighlight);