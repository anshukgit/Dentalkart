import {StyleSheet, Platform} from 'react-native';
import {DeviceWidth, DeviceHeight} from '../../config/environment';

export const SearchPageStyle = StyleSheet.create({
  searchBoxWrapper: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    elevation: 2,
    shadowColor: '#bfbfbf',
    shadowOffset: {
      height: 0,
      width: 0,
    },
    shadowOpacity: 0.5,
    shadowRadius: 2,
  },
  backIconWrapper: {
    width: 50,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    height: Platform.OS === 'ios' ? 45 : 45,
  },
  inputField: {
    height: Platform.OS === 'ios' ? 45 : 45,
    width: DeviceWidth - 50,
    color: '#000',
    fontSize: 14,
  },
  emptySearchWrapper: {
    height: DeviceHeight - 45,
    backgroundColor: '#fff',
    alignItems: 'center',
  },
  noquerySearchWrapper: {
    height: DeviceHeight - 45,
    backgroundColor: '#fff',
    alignItems: 'center',
  },
  searchResultWrapper: {
    backgroundColor: '#fff',
    marginBottom: 43,
  },
  searchProduct: {
    paddingTop: 3,
    paddingBottom: 3,
    flex: 1,
    borderBottomWidth: 0.5,
    borderBottomColor: '#ddd',
    marginLeft: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  productDetailWrapper: {
    width: DeviceWidth - 130,
    marginLeft: 5,
  },
  searchProductPriceWrapper: {
    flexDirection: 'row',
  },
  searchProductPrice: {
    marginRight: 5,
  },
  searchProductPriceStrike: {
    textDecorationLine: 'line-through',
    textDecorationStyle: 'solid',
  },
  searchImage: {
    width: 250,
    height: 250,
  },
});
