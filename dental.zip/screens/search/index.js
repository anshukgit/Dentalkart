import React from 'react';
import {View, Image, Modal, ToastAndroid} from 'react-native';
import {InstantSearch} from 'react-instantsearch/native';
import {connectStateResults} from 'react-instantsearch/connectors';
import {Hits} from './Hits';
import {SearchBox, SearchPage} from './SearchBox';
import {SearchPageStyle} from './searchPageStyle';
import {DentalkartContext} from '@dentalkartContext';
import {addToCart} from '@screens/cart';
import {client} from '@apolloClient';
import {ADD_TO_WISHLIST_QUERY} from '@screens/product/graphql';
import tokenClass from '@helpers/token';
import {fireAnalyticsEvent} from '@helpers/firebase_analytics';
import SyncStorage from '@helpers/async_storage';
import {showErrorMessage, showSuccessMessage} from '../../helpers/show_messages';
import { SafeAreaView } from 'react-native';
import { StatusBarScreen } from '../../components/statusbar';

class SearchScreen extends React.PureComponent {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    this.state = {
      hits: '',
      isSearched: false,
      productClicked: false,
      productClickedId: '',
      searchTerm: '',
      addToCartResponse: props.addToCartResponse,
      addToWishListResponse: props.addToWishListResponse,
      currentCurrencyCode: '',
    };
  }
  saveHits(hits) {
    this.setState({hits});
  }
  triggerScreenEvent = _ => {
    const {userInfo} = this.context;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Search',
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };
  componentDidMount() {
    this.setState({currentCurrencyCode: this.context.country.currency_code});
    this.triggerScreenEvent();
  }
  searchResult(hit) {
    if (this.state.hits) {
      this.setState({
        searchTerm: hit,
        isSearched: true,
        productClicked: false,
        productClickedId: '',
        app_id: '',
        api_key: '',
      });
    }
  }
  async addToWishList(product) {
    let isLoggedIn = await tokenClass.loginStatus();
    if (!isLoggedIn) {
      this.setState({isSearched: false});
      this.props.navigation.navigate('Login', {screen: 'Search'});
    } else {
      try {
        const data = client.mutate({
          mutation: ADD_TO_WISHLIST_QUERY,
          variables: {productId: product.objectID, sku: product.sku},
        });
        return showSuccessMessage('Added to Wishlist');
      } catch (err) {
        console.log(err);
      }
    }
  }
  async addToCart(product) {
    if (product.type_id === 'simple') {
      const result = await addToCart(product, this.context);
      this.context.getUserInfo();
      return result;
    } else {
      this.navigateToDetail(product);
    }
  }
  navigateToDetail(item) {
    this.setState({isSearched: false});
    this.props.navigation.push('ProductDetails', {productUrl: item.url_key});
  }

  async componentWillMount() {
    let app_id = await SyncStorage.get('app_id');
    let app_key = await SyncStorage.get('api_key');
    this.setState({app_id, app_key});
  }

  render() {
    const app_id = this.state.app_id || 'UQ589HLQT3';
    const api_key = this.state.app_key || '9acdf6adbc945f1cc46be269df3f8bdb';
    return (
      <View>
        <StatusBarScreen />
        <InstantSearch
          appId={app_id}
          apiKey={api_key}
          indexName="dentalkart_default_products">
          <SearchBox _this={this} />
          <Content
            navigation={this.props.navigation}
            _this={this}
            currentCurrency={this.state.currentCurrencyCode}
          />
        </InstantSearch>
        <Modal
          transparent={false}
          animationType={'fade'}
          visible={this.state.isSearched}
          onRequestClose={() => this.setState({isSearched: false})}>
          <SearchPage
            hits={this.state.hits}
            _this={this}
            currency={this.state.currentCurrencyCode}
          />
        </Modal>
      </View>
    );
  }
}
// <View style={SearchPageStyle.emptySearchWrapper}>
// 	<Image source={{uri: 'https://s3.ap-south-1.amazonaws.com/dentalkart-media/App/SearchHelloTP.png'}} style={SearchPageStyle.searchImage} />
// </View>

// <InstantSearch
// 	appId="UQ589HLQT3"
// 	apiKey="9acdf6adbc945f1cc46be269df3f8bdb"
// 	indexName="dentalkart_default_products"
// >

const Content = connectStateResults(
  ({searchState, searchResults, props, _this, currentCurrency}) => {
    const hasResults =
      searchState.query && searchResults && searchResults.nbHits !== 0;
    const currencyCode = currentCurrency || 'INR';
    return !searchState.query ? (
      <Hits
        currency={currencyCode}
        navigation={props.navigation}
        _this={_this}
      />
    ) : hasResults ? (
      <Hits
        currency={currencyCode}
        navigation={props.navigation}
        _this={_this}
      />
    ) : (
      <View style={SearchPageStyle.emptySearchWrapper}>
        <Image
          source={{
            uri:
              'https://s3.ap-south-1.amazonaws.com/dentalkart-media/App/searchSorryTP.png',
          }}
          style={SearchPageStyle.searchImage}
        />
      </View>
    );
  },
);

export default SearchScreen;
