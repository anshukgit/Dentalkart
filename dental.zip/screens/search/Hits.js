import React, {useContext} from 'react';
// First, we need to add the connectInfiniteHits connector to our import
import { connectInfiniteHits } from 'react-instantsearch/connectors';
// We also need to import the FlatList and other React Native component
import { View, FlatList, Image, Text } from 'react-native';
import TouchableCustom from '../../helpers/touchable_custom';
import { Highlight } from './HighlightQuery';
import { SearchPageStyle } from './searchPageStyle';
import {DentalkartContext} from '@dentalkartContext';


const getProductUrl = (product) => {
    let url = '#';
    const indexedPrefix = "https://www.dentalkart.com/";
    if(product && product.url){
        const urlsub = (product.url).replace(".html", "")
        url = (urlsub).replace(indexedPrefix, "");
    }

    if(product && product.url_key) url = `${product.url_key}`;
    return url;
}
const handlePress = (navigation, item) => {
    console.log(JSON.stringify(item, null, "\t"));
    const {push} = navigation;
    const url = getProductUrl(item)
    this.requestAnimationFrame(()=> {
        push('ProductDetails', { productUrl: url})
    });
}

export const Hits = connectInfiniteHits(({ hits, hasMore, refine, currency='', navigation, _this }) => {
    const {country} = useContext(DentalkartContext);
    /* if there are still results, you can call the refine function to load more */
    const onEndReached = function() {
        if (hasMore) {
          refine();
        }
    };
    const searchResult = function() {
        if(hits)
            _this.saveHits(hits);
    }
    searchResult();
    return (
        <FlatList
            data={hits}
            keyboardShouldPersistTaps={'always'}
            onEndReached={onEndReached}
            keyExtractor={(item, index) => item.objectID}
            style={SearchPageStyle.searchResultWrapper}
            keyboardDismissMode='interactive'
            renderItem={({ item }) => {
                const isPriceVisible = !item.msrp;
                if (item.international_active === "No" && country.country_id !== "IN") return null;
                return (
                    <TouchableCustom underlayColor={'#ffffff10'} onPress={()=> handlePress(navigation, item)} >
                        <View style={SearchPageStyle.searchProduct}>
                            <Image
                              style={{ height: 60, width: 60 }}
                              source={{ uri: 'https:'+item.thumbnail_url }}
                              resizeMethod={"resize"}
                            />
                            <View style={SearchPageStyle.productDetailWrapper}>
                                <Text>
                                    <Highlight attribute="name" hit={item} />
                                </Text>
                                {currency && item.price[currency]?
                                    <View style={SearchPageStyle.searchProductPriceWrapper}>
                                        {isPriceVisible &&
                                            <View>
                                                <Text style={[(item.price[currency].special_from_date)? SearchPageStyle.searchProductPriceStrike: null, SearchPageStyle.searchProductPrice]}>
                                                    {item.price[currency].default_original_formated}
                                                </Text>
                                                <Text>{item.price[currency].default_formated}</Text>
                                            </View>
                                        }
                                    </View>
                                : false }
                            </View>
                        </View>
                    </TouchableCustom>
                );
            }}
        />
    );
});
