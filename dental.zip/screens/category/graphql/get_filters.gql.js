import gql from "graphql-tag";
import toSource from "@helpers/toSource";

const GET_FILTERS = (appliedFilters=[]) => {
    return gql`
        query filters($id: Int!){
            dkCategoryFilters(id: $id,  filter: ${appliedFilters.toSource()}){
                label
                code
                options{
                    value
                    label
                }
	        }
        }
    `;
}

export default GET_FILTERS;
