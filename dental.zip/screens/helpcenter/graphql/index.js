export {default as GET_FAQ_CATEGORIES_QUERY} from './get_faq_categories.gql';
