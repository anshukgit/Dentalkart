
export {default as GET_CATEGORY_QUESTIONS_QUERY} from './get_category_questions.gql';
export {default as GET_FAQ_CATEGORIES_QUERY} from '../../../graphql/get_faq_categories.gql';
