export {default as GET_ANSWER_QUERY} from './get_answer.gql';
export {default as UPDATE_LIKE_QUERY} from './update_like.gql';
