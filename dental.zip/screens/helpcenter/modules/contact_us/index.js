import React, {Component} from 'react';
import {View, Text} from 'react-native';
import styles from './contact_us.style';
import Header from '@components/header';

export default class ContactUs extends Component{
    render(){
        return(
            <View>
                <Header
                    back
                    heading="Contact Us"
                    navigation={this.props.navigation}
                />
                <View style={styles.wrapper}>
                    <View style={styles.cardWrapper}>
                        <View style={styles.cardHeadingWrapper}>
                            <Text style={styles.cardHeading}>Headquarters</Text>
                        </View>
                        <View style={styles.addressWrapper}>
                            <Text style={styles.addressHeading}>Delhi NCR</Text>
                            <Text style={styles.cardBody}>VASA Denticity Pvt. Ltd.</Text>
                            <Text style={styles.cardBody}>Farm No. 12, Club Drive</Text>
                            <Text style={styles.cardBody}>Gadaipur, DLF Farms</Text>
                            <Text style={styles.cardBody}>Near Ghitorni Metro Station</Text>
                            <Text style={styles.cardBody}>Delhi - 110030</Text>
                        </View>
                    </View>
                    <View style={styles.cardWrapper}>
                        <View style={styles.cardHeadingWrapper}>
                            <Text style={styles.cardHeading}>Overseas Office</Text>
                        </View>
                        <View style={styles.addressWrapper}>
                            <Text style={styles.addressHeading}>Dubai</Text>
                            <Text style={styles.cardBody}>VASA Denticity Pvt. Ltd.</Text>
                            <Text style={styles.cardBody}>1807-6, 18th Floor, BB1 Tower</Text>
                            <Text style={styles.cardBody}>Mazaya Business Avenue, JLT</Text>
                            <Text style={styles.cardBody}>Dubai UAE</Text>
                        </View>
                    </View>
                </View>
            </View>
        );
    }
}
