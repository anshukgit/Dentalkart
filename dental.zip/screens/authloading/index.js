import React, {Component} from 'react';
import {
  View,
  StyleSheet,
  Image,
  Platform,
  Linking,
  ToastAndroid,
} from 'react-native';
import tokenClass from '@helpers/token';
import {DentalkartContext} from '@dentalkartContext';
import SyncStorage from '@helpers/async_storage';
import firebase from 'react-native-firebase';
import {ActivityIndicator} from 'react-native';
import {SecondaryColor} from '@config/environment';

// await firebase.analytics().logEvent("screenname", {
//     screenName: "Login",
//     appName: "Dentalkart",
// });

export default class AuthLoading extends Component {
  static contextType = DentalkartContext;
  setInitialScreen = async (notification = null) => {
    const deepLinkingUrl = await this.navigateDeepLinking();
    setTimeout(async () => {
      const {navigate} = this.props.navigation;
      if (!notification) {
        const isFirstTime = await SyncStorage.get('firstTime');
        const isLoggedIn = await tokenClass.loginStatus();
        if (!deepLinkingUrl) {
          if (isLoggedIn || isFirstTime) {
            navigate('Home', {entry: true});
          } else {
            navigate('Login', {screen: 'Home', entry: true});
          }
        } else {
          this.handleDeepLinkURL(deepLinkingUrl, true);
        }
      } else {
        this.navigateToTarget(notification, true);
      }
    }, 1500);
  };
  setParentNavigationProp = () => {
    const {navigation} = this.props;
    const {setNavigationProp} = this.context;
    setNavigationProp(navigation);
  };
  navigate = url => {
    const {navigate} = this.props.navigation;
    const route = url.replace(/.*?:\/\//g, '');
    const id = route.match(/\/([^\/]+)\/?$/)?.[1];
    const routeName = route.split('/')[1];
    if (routeName === 'cart') {
      navigate('Cart', {id});
    } else if (routeName === 'orderSuccess') {
      navigate('OrderSuccess', {id});
    }
  };
  handleDeepLinkURL = (url, entry) => {
    let pageUrl = url.replace('dentalkart://dentalkart/', '');
    pageUrl = url.replace('dentalkart://dentalkart', '');
    if (pageUrl.includes('?')) {
      pageUrl = pageUrl.split('?')[0];
    }
    /* ***************************************
            TODO:// Fetch and parse deeplink url here and navigate
           *************************************** */
    // Remove this after verification

    const pageUrlMap = {
      cart: 'Cart',
      home: 'Home',
    };
    if (pageUrl) {
      if (pageUrlMap[pageUrl]) {
        this.props.navigation.navigate(pageUrlMap[pageUrl], {entry});
      } else {
        this.props.navigation.navigate('UrlResolver', {
          url_key: pageUrl,
          entry,
        });
      }
    } else {
      this.props.navigation.navigate('Home', {entry});
    }
  };
  handleOpenURL = event => {
    this.handleDeepLinkURL(event.url, false);
  };
  async getToken() {
    let fcmToken = await firebase.messaging().getToken();
    console.log(fcmToken);
  }
  async checkPermission() {
    const enabled = await firebase.messaging().hasPermission();
    if (enabled) {
      this.getToken();
    } else {
      this.requestPermission();
    }
  }
  async requestPermission() {
    try {
      await firebase.messaging().requestPermission();
      this.getToken();
    } catch (error) {
      console.log('permission rejected');
    }
  }
  navigateToTarget(notification, entry) {
    if (notification?.data?.url) {
      this.props.navigation.navigate('UrlResolver', {
        url_key: notification.data.url,
        entry,
      });
    }
  }
  displayNotification(notification, type) {
    let localNotification;
    if (Platform.OS === 'android') {
      console.log(notification, type, 'in');
      const channel = new firebase.notifications.Android.Channel(
        'promotions',
        'promotions channel',
        firebase.notifications.Android.Importance.Max,
      );
      firebase.notifications().android.createChannel(channel);

      localNotification = new firebase.notifications.Notification({
        sound: 'default',
        show_in_foreground: true,
      })
        .setNotificationId(notification.notificationId)
        .setTitle(notification.title || notification.data.title)
        .setSubtitle(notification.subtitle)
        .setBody(notification.body || notification.data.body)
        .setData(notification.data)
        .android.setChannelId('promotions') // e.g. the id you chose above
        .android.setSmallIcon('@drawable/ic_stat_name') // create this icon in Android Studio
        .android.setLargeIcon('@drawable/ic_stat_name') // create this icon in Android Studio
        .android.setColor('#000000') // you can set a color here
        .android.setPriority(firebase.notifications.Android.Priority.High)
        .android.setAutoCancel(true);
      if (notification.data?.image) {
        localNotification.android.setBigPicture(notification.data.image);
      }
    } else {
      localNotification = new firebase.notifications.Notification({
        sound: 'default',
        show_in_foreground: true,
      })
        .setNotificationId(notification.notificationId)
        .setTitle(notification.title || notification.data.title)
        .setSubtitle(notification.subtitle)
        .setBody(notification.body || notification.data.body)
        .setData(notification.data);
    }

    firebase
      .notifications()
      .displayNotification(localNotification)
      .catch(err => console.error(err));
  }
  async createNotificationListeners() {
    let isSimilarToLastOpened;
    firebase.notifications().onNotification(notification => {
      this.displayNotification(notification, 'received');
    });
    this.notificationOpenedListener = firebase
      .notifications()
      .onNotificationOpened(async notificationOpen => {
        await SyncStorage.set(
          'lastNotificationId',
          notificationOpen.notification.notificationId,
        );
        this.navigateToTarget(notificationOpen.notification, false);
      });
    const notificationOpen = await firebase
      .notifications()
      .getInitialNotification();
    if (notificationOpen) {
      let previousId = await SyncStorage.get('lastNotificationId');
      isSimilarToLastOpened =
        previousId === notificationOpen.notification.notificationId;
      if (!isSimilarToLastOpened) {
        await SyncStorage.set(
          'lastNotificationId',
          notificationOpen.notification.notificationId,
        );
        this.setInitialScreen(notificationOpen.notification);
      } else {
        this.setInitialScreen();
      }
    } else {
      this.setInitialScreen();
    }
    // this.messageListener = firebase.messaging().onMessage(message => {
    //   //process data message
    //   console.log(message, 'data');
    // });
  }
  navigateDeepLinking = async () => {
    let url = null;
    if (Platform.OS === 'android') {
      url = await Linking.getInitialURL();
    }
    return url;
  };
  componentDidMount() {
    Linking.addEventListener('url', this.handleOpenURL);
    this.checkPermission();
    this.createNotificationListeners();
    this.setParentNavigationProp();
  }
  componentWillUnmount() {
    Linking.removeEventListener('url', this.handleOpenURL);
  }
  render() {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={SecondaryColor} />
      </View>
    );
  }
  componentWillUnmount() {
    // Linking.removeEventListener('url', this.handleOpenURL);
  }
}

const styles = StyleSheet.create({
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
