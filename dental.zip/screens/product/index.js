import React, {Component, Fragment} from 'react';
import {
  Text,
  ToastAndroid,
  ScrollView,
  ActivityIndicator,
  Share,
  View,
  StatusBar,
} from 'react-native';
import {Query} from 'react-apollo';
import {GET_PRODUCT_QUERY, ADD_TO_WISHLIST_QUERY} from './graphql';
import {addToCart} from '@screens/cart';
import {client} from '@apolloClient';
import Header from '@components/header';
import ProductAction from './modules/product_action';
import ProductImages from './modules/product_images';
import BulKQuote from './modules/bulk_quote';
import ProductSpecification from './modules/product_specification';
import ProductTabs from './modules/product_tabs';
import {ProductReviews} from '@screens/reviews';
import tokenClass from '@helpers/token';
import {BASE_URL, DeviceHeight, StatusBarHeight} from '@config/environment';
import {DentalkartContext} from '@dentalkartContext';
import Loader from '@components/loader';
import {fireAnalyticsEvent} from '@helpers/firebase_analytics';
import {showErrorMessage, showSuccessMessage} from '../../helpers/show_messages';
import {Platform} from 'react-native';

export default class ProductDetails extends Component {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    this.state = {
      productQuantity: 1,
      productOptions: [],
      selectedGroupProducts: [],
      bulkModalVisible: false,
      bulkModalSoure: 0,
      payload: '',
    };
    this.product = null;
  }
  closeBulkModal = () => {
    this.setState({bulkModalVisible: false});
  };
  openBulkModal = source => {
    this.setState({bulkModalVisible: true, bulkModalSoure: source});
  };
  updateQuantity(qty, sku, type) {
    if (type === 'grouped') {
      this.setSelectedGroupProducts(qty, sku, type);
    } else {
      this.setState({
        productQuantity: qty,
      });
    }
  }
  setSelectedGroupProducts(qty, sku, type) {
        let selectedProducts = this.state.selectedGroupProducts.filter(product => product.data.sku!=sku);
        if(parseFloat(qty)>0)
        selectedProducts.push({data : {sku: sku, quantity: parseFloat(qty)}});
        this.setState({selectedGroupProducts: selectedProducts});
  }
  setProductOptions = options => {
    let productOptions = [];
    Object.keys(options).map(item => {
      options[item].map(innerItem => {
        productOptions.push({
          id: innerItem.id,
          value: innerItem.value,
          quantity: 1,
        });
      });
    });
    this.setState({productOptions});
  };
  setConfigurableProductOptions = (options, payload) => {
    let productOptions = [];
    Object.keys(options).map(item => {
      options[item].map(innerItem => {
        productOptions.push({
          id: innerItem.id,
          value: innerItem.value,
          quantity: 1,
        });
        return null;
      });
      return null;
    });
    this.setState({productOptions: productOptions, payload: payload});
  };
  getProductUrl() {
    const {navigation, urlKey} = this.props;
    console.warn(' product detail ========== > ' , navigation.getParam('productUrl')  , ' === ' , urlKey )
    let productUrl = '';
    if (urlKey) {
      let urlSub = urlKey.replace('.html', '');
      if (urlSub.charAt(0) === '/') {
        urlSub = urlSub.slice(1);
      }
      productUrl = urlSub;
    } else {
      productUrl = navigation.getParam('productUrl');
    }
    return productUrl;
  }
  async addToWishlist(id, sku) {
    let isLoggedIn = await tokenClass.loginStatus();
    let productUrl = this.getProductUrl();
    console.warn('product url specifiction === > ' , productUrl , id)
    if (!isLoggedIn) {
      this.props.navigation.navigate('Login', {
        screen: 'ProductDetails',
        params: {productUrl: productUrl},
      });
    } else {
      try {
        const data = await client.mutate({
          mutation: ADD_TO_WISHLIST_QUERY,
          variables: {productId: id},
          fetchPolicy: 'no-cache',
        });
        return showSuccessMessage('Added to Wishlist');
      } catch (err) {
        console.log(err);
      }
    }
  }
  async addToCartPress() {
    const {
      selectedGroupProducts,
      productQuantity,
      productOptions,
      payload,
    } = this.state;
    this.product.qty = productQuantity;

    if (this.product.type_id === 'grouped') {
      if (selectedGroupProducts.length > 0) {
        this.product.options = selectedGroupProducts;
      } else {
        return showErrorMessage('Select a product');
      }
    } else if (this.product.type_id === 'bundle') {
      if (productOptions.length > 0) {
        this.product.options = productOptions;
      } else {
        return showErrorMessage('Select a product configuration');
      }
    } else if (this.product.type_id === 'configurable') {
      if (payload && productOptions.length > 0) {
        const attributeCodesArray = productOptions.map(data => {
          const Getobj = payload.item.configurable_options.find(
            item => item.attribute_id === data.id.toString(),
          );
          return {
            attribute_code: Getobj.attribute_code,
            value: data.value,
          };
        });

        const getChildSku = payload.item.variants.filter((data, index) => {
          let HasValue = attributeCodesArray.map(
            item => data.product[item.attribute_code] === parseInt(item.value),
          );
          const AllConditionSatisfied = HasValue.every(value => value === true);
          if (AllConditionSatisfied) {
            return data.product;
          }
        });
        this.product.childSku = getChildSku[0].product.sku;
      } else {
        showErrorMessage('You need to choose options for your product.');
      }
    } else {
      if (productQuantity === 0) {
        return showErrorMessage('Select a product quantity');
      }
    }

    const result = await addToCart(this.product, this.context);
    this.context.getUserInfo();
    return result;
  }
  async buyNowPress() {
    const result = await this.addToCartPress();
    if (result) {
      this.props.navigation.navigate('Cart');
    }
  }
  async canAddReview() {
    let productUrl = this.getProductUrl();
    let isLoggedIn = await tokenClass.loginStatus();
    if (isLoggedIn) {
      return this.props.navigation.navigate('Reviews', {
        productId: this.product.id,
      });
    } else {
      this.props.navigation.navigate('Login', {
        screen: 'ProductDetails',
        params: {productUrl: productUrl},
      });
    }
  }
  share(product) {
    Share.share(
      {
        message: `Check this out ${product.name} ${BASE_URL}${
          product.url_key
        }.html`,
      },
      {
        dialogTitle: 'Share on ..',
        tintColor: 'green',
      },
    ).catch(err => console.log(err));
  }
  triggerScreenEvent = _ => {
    const {userInfo} = this.context;
    const {navigation, urlKey} = this.props;
    let {params} = navigation.state;
    const entry = params ? params.entry : false;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: `Product: ${urlKey}`,
      entry,
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };
  componentDidMount() {
    this.triggerScreenEvent();
  }
  render() {
    const {urlKey} = this.props;
    const {userInfo} = this.context;
    let productUrl = this.getProductUrl();

    console.log(this.state.selectedGroupProducts)

    return (
      <Fragment>
        {!urlKey && (
          <Header menu title cart search navigation={this.props.navigation} />
        )}
        <Query
          query={GET_PRODUCT_QUERY}
          variables={{urlKey: productUrl}}
          fetchPolicy="cache-and-network"
          onError={error => {
            showErrorMessage(`${error.message}. Please try again.`);
          }}>
          {({data, loading, error}) => {
            if (loading) {
              return <Loader loading={true} transparent={true} />;
            }
            if (error) {
              return showErrorMessage(`${error.message}. Please try again.`);
            }
            if (data.products) {
              const product = data.products.items[0];
              this.product = product;
              if (!product) {
                return <Text>The requested product doesn't exist</Text>;
              }
              return (
                <View
                  style={{
                    height:
                      DeviceHeight -
                      (Platform.OS === 'android' ? 100 : 65) -
                      StatusBarHeight,
                  }}>
                  <ScrollView>
                    <ProductImages
                      _this={this}
                      image={product.image.url}
                      gallery={product.media_gallery_entries}
                    />
                    <ProductSpecification product={product} _this={this} />
                    <ProductTabs product={product} />
                    <BulKQuote
                      _this={this}
                      product={product}
                      closeBulkModal={this.closeBulkModal}
                      openBulkModal={this.openBulkModal}
                    />
                    <ProductReviews product={product} _this={this} />
                  </ScrollView>
                  <ProductAction
                    addToCartPress={() => this.addToCartPress()}
                    buyNowPress={() => this.buyNowPress()}
                    product={product}
                    openBulkModal={this.openBulkModal}
                  />
                </View>
              );
            }
          }}
        </Query>
      </Fragment>
    );
  }
}
