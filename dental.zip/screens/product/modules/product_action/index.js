import React, {Component} from 'react';
import {
  View,
  Image,
  TouchableOpacity,
  Text,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import TouchableCustom from '@helpers/touchable_custom';
import styles from './product_action.style';
import  {hasNotch} from 'react-native-device-info';


export default class ProductAction extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bnloading: false,
      acloading: false,
    };
  }
  handleAction = async type => {
    if (type === 'BN') {
      this.setState({bnloading: true});
      await this.props.buyNowPress();
    } else {
      this.setState({acloading: true});
      await this.props.addToCartPress();
    }
    this.setState({
      bnloading: false,
      acloading: false,
    });
  };
  render() {
    const {bnloading, acloading} = this.state;
    const {product, openBulkModal} = this.props;
    const disabled = product.stock_status === 'OUT_OF_STOCK';
    return (
      <View>
        {!product.msrp ? (
          <View style={[styles.productActionWrapper, hasNotch() ? styles.buttonNotchIssue : '']}>
            <View
              style={[
                styles.buyNowContainer,
                disabled ? styles.disabled : null,
              ]}>
              <TouchableCustom
                disabled={disabled}
                underlayColor={'#ffffff10'}
                onPress={() => (!bnloading ? this.handleAction('BN') : null)}>
                <View style={styles.buyNowWrapper}>
                  {!bnloading ? (
                    <Text style={styles.actionButtonText}>BUY NOW</Text>
                  ) : (
                    <ActivityIndicator
                      style={styles.loader}
                      size="small"
                      color="#fff"
                    />
                  )}
                </View>
              </TouchableCustom>
            </View>
            <View
              style={[
                styles.buyNowContainer,
                styles.borderLeft,
                disabled ? styles.disabled : null,
              ]}>
              <TouchableCustom
                underlayColor={'#ffffff10'}
                disabled={disabled}
                onPress={() => (!acloading ? this.handleAction('AC') : null)}>
                <View style={styles.addToCartWrapper}>
                  {!acloading ? (
                    <Text style={styles.actionButtonText}>ADD TO CART</Text>
                  ) : (
                    <ActivityIndicator
                      style={styles.loader}
                      size="small"
                      color="#fff"
                    />
                  )}
                </View>
              </TouchableCustom>
            </View>
          </View>
        ) : (
          <View style={styles.productActionWrapper}>
            <View style={styles.requestPriceContainer}>
              <TouchableCustom
                underlayColor={'#ffffff10'}
                onPress={() => openBulkModal(1)}>
                <View style={styles.requestPriceWrapper}>
                  <Text style={styles.actionButtonText}>REQUEST PRICE</Text>
                </View>
              </TouchableCustom>
            </View>
          </View>
        )}
      </View>
    );
  }
}
