import {StyleSheet} from 'react-native';
import {DeviceWidth, SecondaryColor, PrimaryColor} from '@config/environment';

export default (styles = StyleSheet.create({
  productActionWrapper: {
    height: 50,
    flexDirection: 'row',
    shadowColor: 'black',
    backgroundColor: '#fff',
    shadowOffset: {width: 0, height: 0},
    shadowOpacity: 0.2,
    shadowRadius: 0,
    elevation: 10,
    shadowColor: '#bfbfbf',
    shadowOffset: {
      height: 0,
      width: 0,
    },
    shadowOpacity: 0.5,
    shadowRadius: 2,
  },
  addToCartWrapper: {
    borderRadius: 5,
    paddingVertical: 15,
    width: DeviceWidth / 2 - 20,
    alignItems: 'center',
    backgroundColor: SecondaryColor,
  },
  buyNowContainer: {
    width: DeviceWidth / 2,
    padding: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  borderLeft: {
    borderLeftWidth: 0.5,
    borderLeftColor: '#ddd',
  },
  buyNowWrapper: {
    borderRadius: 5,
    paddingVertical: 15,
    width: DeviceWidth / 2 - 20,
    alignItems: 'center',
    backgroundColor: PrimaryColor,
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 11,
  },
  disabled: {
    opacity: 0.5,
  },
  loader: {
    fontSize: 9,
  },
  requestPriceContainer: {
    width: DeviceWidth,
    padding: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  requestPriceWrapper: {
    borderRadius: 5,
    paddingVertical: 10,
    width: DeviceWidth - 20,
    alignItems: 'center',
    backgroundColor: PrimaryColor,
  },
  buttonNotchIssue: {
    marginBottom: 10
  },
}));
