import React, {Component} from 'react';
import {View, Text, FlatList, ToastAndroid} from 'react-native';
import WebView from 'react-native-webview';
import TouchableCustom from '@helpers/touchable_custom';
import {Query} from 'react-apollo';
import {GET_PRODUCT_SPECIFICATIONS_QUERY} from '../../graphql';
import {SecondaryColor} from '@config/environment';
import Icon from 'react-native-vector-icons/Entypo';
import styles from './product_tabs.style';
import {showErrorMessage} from '../../../../helpers/show_messages';

export default class ProductTabs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeTab: '',
    };
  }
  initState(index) {
    this.state.activeTab === index
      ? this.setState({activeTab: ''})
      : this.setState({activeTab: index});
  }
  render() {
    const {product, activeTab} = this.props;
    return (
      <Query
        query={GET_PRODUCT_SPECIFICATIONS_QUERY}
        variables={{sku: product.sku}}
        fetchPolicy="cache-and-network"
        onError={error => {
          showErrorMessage(`${error.message}. Please try again.`);
        }}>
        {({data, loading, error}) => {
          if(loading || error){
            return null;
          }
          if (data.GetAttributesBySku) {
            const productKeys = data.GetAttributesBySku.attributes;
            return (
              <View style={styles.productTabsWrapper}>
                <FlatList
                  keyboardShouldPersistTaps={'always'}
                  data={productKeys}
                  renderItem={({item, index}) => (
                    <DescriptionTabs item={item} index={index} _this={this} />
                  )}
                  keyExtractor={(item, index) => index.toString()}
                  extraData={this.state.activeTab}
                  style={{marginBottom: 10}}
                />
              </View>
            );
          } else {
            return null;
          }
        }}
      </Query>
    );
  }
}

export const DescriptionTabs = ({item, index, _this}) => {
  let data = item.attribute_value.toString();
  let value = data.replace(/<[^>]*>|&nbsp;|&amp;/g, '');
  return (
    <View>
      <TouchableCustom
        underlayColor={'#ffffff10'}
        onPress={() => _this.initState(index)}>
        <View style={styles.tabTagWrapper}>
          <Text style={styles.tabTag}>
            {item.attribute_label
              .split('_')
              .join(' ')
              .toUpperCase()}
          </Text>
          <Icon
            name={
              _this.state.activeTab === index
                ? 'chevron-small-up'
                : 'chevron-small-down'
            }
            size={17}
            color={SecondaryColor}
          />
        </View>
      </TouchableCustom>
      <View style={styles.webViewWrapper}>
        {_this.state.activeTab === index ? (
          item.attribute_code == 'video' ? (
            <WebView
              source={{uri: item.attribute_value}}
              style={{height: 200}}
            />
          ) : (
            <Text style={styles.tabText}>{value}</Text>
          )
        ) : null}
      </View>
    </View>
  );
};
