import {StyleSheet} from 'react-native';
import {SecondaryColor, DeviceWidth} from '@config/environment';

export default styles = StyleSheet.create({
    productTabsWrapper: {
        backgroundColor: '#f3f3f3',
        paddingTop: 5
    },
    tabTagWrapper: {
		borderColor: '#ddd',
		borderWidth: 0.5,
		backgroundColor: '#fff',
        padding: 10,
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between'
	},
	tabTag: {
		fontSize: 13,
		color: SecondaryColor
	},
    webViewWrapper: {
        flex: 1,
    },
	tabText: {
		padding: 10,
		fontSize: 12,
		color: '#212121',
		backgroundColor: '#efefef',
        height: 'auto',
        width: DeviceWidth,
	},
})
