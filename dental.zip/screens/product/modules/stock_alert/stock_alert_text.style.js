import {StyleSheet} from 'react-native';
import {DeviceWidth} from '@config/environment'
export default styles = StyleSheet.create({
    alertText:{
        padding: 8,
        textDecorationLine: "underline",
        textDecorationStyle: "solid",
        color: "blue"
    }

})
