import {StyleSheet} from 'react-native';
import {DeviceHeight, DeviceWidth, SecondaryColor} from '@config/environment';

export default (styles = StyleSheet.create({
  imageContainer: {
    backgroundColor: '#fff',
  },
  bigimageWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
  },
  bigimage: {
    height: DeviceHeight / 3,
    width: DeviceWidth,
    resizeMode: 'contain',
  },
  thumbnailsWrapper: {
    marginTop: 10,
    marginBottom: 10,
    paddingLeft: 10,
    paddingRight: 10,
  },
  thumbnailContainer: {
    marginRight: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#d6d7da',
    paddingTop: 2,
    paddingBottom: 2,
  },
  thumbnail: {
    height: 50,
    width: 50,
    resizeMode: 'contain',
  },
  activeImage: {
    borderWidth: 2,
    borderColor: SecondaryColor,
  },
}));
