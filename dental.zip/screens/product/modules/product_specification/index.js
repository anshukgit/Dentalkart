import React,{Component, Fragment} from 'react';
import { View, Text, Image } from 'react-native';
import TouchableCustom from '@helpers/touchable_custom';
import MCIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './product_specification.style';
import SimpleProduct from './modules/simple_product';
import GroupedProduct from './modules/grouped_product';
import ConfigurableProduct from './modules/configurable_product';
import BundleProduct from './modules/bundle_product';
import HTML from 'react-native-render-html';
import {DentalkartContext} from '@dentalkartContext';
import {ExpiryInfoComponent, DispatchInfoComponent} from './modules/product_expiry_dispatch_info';
import SubscribeForStockAlert from '../stock_alert';

export default class ProductSpecification extends Component {
    static contextType = DentalkartContext;
    constructor(props){
        super(props);
        this.state = {
            _this: props._this,
            product: props.product,
        }
    }
    render(){
        const {_this} = this.state;
        const {product} = this.props;
        console.warn('product>...>./..',product)
        const isPriceVisible = !product.msrp;
        const {navigation} =_this.props;
        let minimalPrice = product.price.minimalPrice.amount.value;
        return(
            <View style={styles.productDetailsContainer}>
                <View id={product.id} style={styles.productDetailsWrapper}>
                    <View style={styles.productNameWrapper}>
                        <Text numberOfLines={2} style={styles.productName}>{product.name}</Text>
                    </View>
                    {(product.short_description.html) ?
                        <View style={styles.shortDescriptionWrapper}>
                            <HTML baseFontStyle={styles.shortDescription} html={product.short_description.html} />
                        </View> : null
                    }
                    {(isPriceVisible && product.price.minimalPrice.amount.value) ?
                        <View style={styles.productNewpriceWrapper}>
                            {product.type_id == 'grouped'?
                                <Text style={styles.productStartingAtPrice}>Starting at: {product.price.regularPrice.amount.currency}</Text> :
                                <Text style={styles.currency}>{product.price.regularPrice.amount.currency}</Text>
                            }
                            <Text style={styles.productNewprice}>{product.price.minimalPrice.amount.value}</Text>
                        </View> : null
                    }
                    {product.dentalkart_custom_fee != null && product.dentalkart_custom_fee > 0 ?
                    <View>
                        <Text style={styles.deliveryFee}> + {product.price.regularPrice.amount.currency+product.dentalkart_custom_fee} Delivery Fees</Text>
                    </View> : null }
                    {product.dispatch_days && product.type_id === 'grouped' &&
                        <DispatchInfoComponent dispatchDays={product.dispatch_days} infoToDisplay={ `-Dispatches from warehouse in - `} producType={`grouped`}/>

                    }
                    <View style={styles.productPriceInfoWrapper}>
                        {(product.price && (product.type_id != 'grouped') && (product.price.regularPrice.amount.value > product.price.minimalPrice.amount.value)) ? (<Text style={styles.productOldprice}>{product.price.regularPrice.amount.currency}{product.price.regularPrice.amount.value}</Text>) : null}
                        {(product.price && (product.type_id != 'grouped') && (product.price.regularPrice.amount.value > product.price.minimalPrice.amount.value)) ? (<Text style={styles.productDiscount}>{( 100 - ((product.price.minimalPrice.amount.value * 100) / product.price.regularPrice.amount.value) ).toFixed(2)}%</Text>) : null}
                        {(product.average_rating && product.rating_count>0)?
                            <View style={styles.reviewsWrapper}>
                                <View style={styles.ratingBoxWrapper}>
                                    <Text style={styles.ratingBox}>{parseFloat(product.average_rating).toFixed(1)}</Text>
                                    <MCIcon name='star' style={styles.ratingBoxIcon} />
                                </View>
                                <Text style={styles.reviewsQty}>({product.rating_count})</Text>
                            </View> : false
                        }
                    </View>
                    {(product.stock_status === "OUT_OF_STOCK") ?
                        <View style={styles.availablityWrapper}>
                            <Text style={styles.soldOutText}>Sold out</Text>
                        </View> : null
                    }
                    {(isPriceVisible && product.tier_prices) ? (
                        <View style={styles.tierPriceWrapper}>
                            {product.tier_prices.map((tierItem, index) => (
                                (tierItem.value < minimalPrice)  && <Text style={styles.tierPrice} key={index}>
                                    Buy {tierItem.qty} or above for {product.price.regularPrice.amount.currency}{tierItem.value} each and save {( 100 - ((tierItem.value * 100) / product.price.minimalPrice.amount.value) ).toFixed(2)}%
                                </Text>
                            ))}
                        </View>
                    ) : null}
                    {(product.only_x_left_in_stock) ?
                        <View style={styles.leftInStockWrapper}>
                            <Text style={styles.leftInStock}>Only {product.only_x_left_in_stock} left in stock</Text>
                        </View> : null
                    }
                    {this.context.country.country_id === 'IN' && product.reward_point_product?
                        <View style={styles.rewardWrapper}>
                            <Image source={{uri: "https://s3.ap-south-1.amazonaws.com/dentalkart-media/React/coin.png"}} style={styles.rewardIcon}/>
                            <Text style={styles.rewardPoints}>{product.reward_point_product}</Text>
                        </View> : null
                    }
                    {
                        (product.type_id === 'simple') ? (<SimpleProduct _this={_this} product={product}/>) :
                        (product.type_id === 'grouped') ? (<GroupedProduct _this={_this} product={product} />) :
                        (product.type_id === 'configurable') ? (<ConfigurableProduct _this={_this} setConfigurableProductOptions={_this.setConfigurableProductOptions} product={product} />) :
                        (product.type_id === 'bundle') ? (<BundleProduct _this={_this} setProductOptions={_this.setProductOptions} product={product} />) :
                        (<Text>No Product type</Text>)
                    }
                    {product.type_id !== 'grouped' ?
                        <View style={{marginTop:10, marginBottom:10}}>
                            <ExpiryInfoComponent productExpiry={product.pd_expiry_date}  infoToDisplay={`Expiry Date`} producType={product.type_id }/>
                            <DispatchInfoComponent dispatchDays= {product.dispatch_days}  infoToDisplay={`Dispatch time`} producType={product.type_id}/>
                        </View>:
                        null
                    }
                </View>
                {(product.stock_status === "OUT_OF_STOCK") ?
                        <SubscribeForStockAlert productId={product.id} navigation={navigation}/>
                     : null
                }
                <View style={styles.buttonsWrapper}>
                    <TouchableCustom onPress={()=> _this.share(product)} underlayColor={'#ffffff10'}>
                        <View style={styles.shareButton}>
                            <MCIcon name="share" size={14} color='#21212180' />
                            <Text style={styles.shareButtonText}>Share</Text>
                        </View>
                    </TouchableCustom>
                    <TouchableCustom onPress={()=> _this.addToWishlist(product.id, product.sku)} underlayColor={'#ffffff10'}>
                        <View style={styles.shareButton}>
                            <MCIcon name="heart" size={14} color='#21212180'/>
                            <Text style={styles.shareButtonText}>Add To Wishlist</Text>
                        </View>
                    </TouchableCustom>
                </View>
            </View>
        )
    }
}
