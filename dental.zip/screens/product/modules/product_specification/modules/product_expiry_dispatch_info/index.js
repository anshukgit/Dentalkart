
import React, {Fragment, Component} from 'react';
import {
  View,
  ScrollView,
  Modal,
  Text,
  TouchableOpacity,
  Button
} from 'react-native';
import {Query, Mutation} from 'react-apollo';
import {GET_DISPATCH_INFORMATION_QUERY} from '../../../../graphql';
import styles from './expiry_dispatch.style';

function formatDate(getDateString){
    const dateString = new Date(getDateString.replace(' ', 'T'))
    const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June', 'July',
         'August', 'September', 'October', 'November', 'December'
    ];
    const day = dateString.getDate();
    const monthIndex = dateString.getMonth();
    const year = dateString.getFullYear();
    return  `${monthNames[monthIndex]}, ${year}`;
}

export const DispatchInfoComponent = ({dispatchDays, infoToDisplay, producType}) => {

    const [openDispatchDateModal, setOpenDispatchDateModal] = React.useState(false)

    const handleDispatchModalOpen = () => {
        setOpenDispatchDateModal(true)
    }

    const handleDispatchModalClose = () => {
        setOpenDispatchDateModal(false)
    }

    const DispatchInformation = () => {
        return (
            <View>
                <Text>Dispatch Days mentioned here are valid for this product only.</Text>
                <Text>
                    Days required to actually dispatch an order from our warehouse may depend on various factors like
                </Text>
                <Text>
                    1. Other products in an order. (In case an order has 5 different items together, actual dispatch date from warehouse may depend on the product with longest dispatch days.)
                </Text>
                <Text>
                    2. General Holidays & Shipping partner schedules.
                </Text>
                <Text>
                    3. Dental Exhibitions (Product supply from manufacturers is affected during or after exhibition.
                </Text>
                <Text>
                    4. Natural Calamities (floods, earthquakes, landslides etc) or embargo situations.
                </Text>
            </View>
        )
    }

    return(
        <View>
            {dispatchDays &&
                <Query
                    query={GET_DISPATCH_INFORMATION_QUERY}
                    variables={{attribute_code: "dispatch_days", entity_type: "4"}}
                    fetchPolicy={'cache-and-network'}
                >
                    {({ loading, error, data }) => {
                        if (loading) return null;
                        if (error) console.log(`Error! ${error}`)
                        const getAttributeOptionsArray =data.customAttributeMetadata.items[0].attribute_options.filter(data=>
                            data.value===dispatchDays.toString()
                        )
                        return(
                            <View style={{flexDirection:'row', alignItems:'center', marginBottom: producType==='grouped'? 8 : 0}}>
                                <View style={producType==="grouped" ? styles.GroupHeadText : styles.expiryInfohead}>
                                    <Text>{infoToDisplay}</Text>
                                </View>
                                <View style={producType==="grouped" ? styles.info_text : styles.expiryInfohead}>
                                    <Text onPress={()=>handleDispatchModalOpen()} style={styles.linkText}>{producType==="grouped" ? `${getAttributeOptionsArray[0].label} days` : `${getAttributeOptionsArray[0].label} working days`}</Text>
                                </View>
                                <Modal
                                    visible={openDispatchDateModal}
                                    transparent={true}
                                    animationType="slide"
                                    onRequestClose={() =>
                                        handleDispatchModalClose()
                                }>
                                    <View style={styles.modalWrapper}>
                                        <DispatchInformation/>
                                        <View style={{alignItems:'center', }}>
                                            <TouchableOpacity onPress={()=> handleDispatchModalClose()} >
                                                <Text style={styles.modalCloseButton}>
                                                     Close
                                                </Text>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                </Modal>
                            </View>
                        );
                    }}
                </Query>
            }
        </View>
    )
}


export const ExpiryInfoComponent = ({productExpiry, infoToDisplay, producType}) => {

    const [openExpiryModal, setOpenExpiryModal] = React.useState(false);

    const handleExpiryModalOpen = () => {
       setOpenExpiryModal(true);
    };

    const handleExpiryModalClose = () => {
        setOpenExpiryModal(false);
    };

    const ExpiryInformation = () => {
        return(
            <View>
                <Text>
                    The Expiration date mentioned here is based on our latest warehouse stock. Dentalkart tries to always deliver the latest lot i.e longest expiry of products directly procured from the manufacturer.
                </Text>
                <Text>
                    Incase of short expiry products, it is always mentioned clearly .
                </Text>
            </View>
        )
    }
    return(
        <View>
            {productExpiry &&
                <View style={{marginBottom:8,flexDirection:'row', alignItems:'center'}}>
                    <View>
                        <Text style = { producType==="grouped" ? styles.GroupHeadText : styles.expiryInfohead}>{infoToDisplay}</Text>
                    </View>
                    <View style={producType==="grouped" ? styles.info_text : styles.expiryInfohead}>
                        <Text onPress={()=>handleExpiryModalOpen()} style={styles.linkText}>{formatDate(productExpiry)}</Text>
                    </View>
                    <Modal
                        visible={openExpiryModal}
                        transparent={true}
                        animationType="slide"
                        onRequestClose={() =>
                            handleExpiryModalClose()
                    }>
                        <View style={styles.modalWrapper}>
                            <ExpiryInformation/>
                            <View style={{alignItems:'center', }}>
                                <TouchableOpacity onPress={()=> handleExpiryModalClose()} >
                                    <Text style={styles.modalCloseButton}>
                                         Close
                                    </Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </Modal>
                </View>
            }
        </View>
    )
}
