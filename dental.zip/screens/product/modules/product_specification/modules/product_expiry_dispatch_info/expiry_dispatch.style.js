import {StyleSheet} from 'react-native';
import {SecondaryColor} from '@config/environment';


export default styles = StyleSheet.create({
    modalWrapper:{
        position:'absolute',
        bottom:0,
        backgroundColor:'#fff',
        paddingTop:15,
        paddingBottom:15,
        paddingLeft:20,
        paddingRight:20,
        borderTopColor: '#ddd',
        borderWidth:0.5,
        shadowColor: '#bfbfbf',
        shadowOpacity: 0.5,
        shadowOffset: {
            height: 0,
            width: 0
        },
        elevation: 1,
        zIndex:2
	},
    modalCloseButton:{
        paddingTop:4,
        paddingBottom:4,
        paddingLeft:10,
        paddingRight:8,
        borderRadius:12,
        backgroundColor: SecondaryColor,
        color:'#fff',
        textAlign:'center',
        width:130,
        marginTop:10,
    },
    expiryInfohead:{
        borderWidth:1,
        borderColor:'#ddd',
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:10,
        paddingRight:10,
    },
    linkText:{
       textDecorationLine: 'underline',
       color:'#2a5db0'
   },
   GroupHeadText:{
       marginRight:5
   }

})
