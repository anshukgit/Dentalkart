import React, {Component} from 'react';
import {View, Text, Image, ActivityIndicator, ToastAndroid} from 'react-native';
import QuantitySelector from '@components/quantity_selector';
import MCIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import {GET_GROUP_PRODUCT_QUERY} from '../../../../graphql';
import {Query} from 'react-apollo';
import styles from './grouped_product.style';
import {showErrorMessage} from '../../../../../../helpers/show_messages';
import {ExpiryInfoComponent} from '../product_expiry_dispatch_info';
import SubscribeForStockAlert from '../../../stock_alert';


export default class GroupedProduct extends Component {
  constructor(props) {
    super(props);
    this.state = {
      _this: props._this,
      product: props.product,
    };
  }

  arrayWithSoldOutAtBottom = (arr) => {
        let inStockArray=[], outOfStockArray=[];
        arr.map((data, index)=>{
            if(data.product.stock_status === "IN_STOCK"){
                inStockArray.push(data)
            }
            else {
                outOfStockArray.push(data)
            }
            return null
        })

        const resultingArray = inStockArray.concat(outOfStockArray)

        return resultingArray;
    }

   render() {
    const {product, _this} = this.state;
    const {navigation} = _this.props;
    return (
      <View>
        {product.stock_status === 'IN_STOCK' && (
          <Query
            query={GET_GROUP_PRODUCT_QUERY}
            variables={{sku: product.sku}}
            fetchPolicy="cache-and-network"
            onError={error => {
              showErrorMessage(`${error.message}. Please try again.`);
            }}>
            {({data, loading, error}) => {
              if(loading || error) {
                return <ActivityIndicator size="large" color="#343434" />;
              }
              if (data.products) {
                const productProperties = data.products.items[0];
                if (productProperties.items) {
                   const getSoldOutAtBottomArray = this.arrayWithSoldOutAtBottom(productProperties.items)
                  return (
                    <View>
                      {getSoldOutAtBottomArray.map((item, index) => {
                        const product = item.product;
                        let minimalPrice =
                          product.price.minimalPrice.amount.value;
                        return (
                          <View style={styles.groupedWrapper} key={index}>
                            <View style={styles.groupedProductNameWrapper}>
                              <Text
                                style={styles.groupedProductName}
                                numberOfLines={2}>
                                {product.name}
                              </Text>
                            </View>
                            <View style={styles.productGroupedPriceInfoWrapper}>
                              {product.price.minimalPrice.amount.value ? (
                                <View style={styles.productNewpriceWrapper}>
                                  <Text style={styles.currency}>
                                    {product.price.minimalPrice.amount.currency}
                                  </Text>
                                  <Text style={styles.productNewprice}>
                                    {product.price.minimalPrice.amount.value}
                                  </Text>
                                </View>
                              ) : null}
                              {product.price.regularPrice.amount.value >
                              product.price.minimalPrice.amount.value ? (
                                <Text style={styles.productOldprice}>
                                  {product.price.regularPrice.amount.value}
                                </Text>
                              ) : null}
                              {product.price.regularPrice.amount.value >
                              product.price.minimalPrice.amount.value ? (
                                <Text style={styles.productDiscount}>
                                  {(
                                    100 -
                                    (product.price.minimalPrice.amount.value *
                                      100) /
                                      product.price.regularPrice.amount.value
                                  ).toFixed(2)}
                                  %
                                </Text>
                              ) : null}
                              {product.average_rating &&
                              product.rating_count > 0 ? (
                                <View style={styles.reviewsWrapper}>
                                  <View style={styles.ratingBoxWrapper}>
                                    <Text style={styles.ratingBox}>
                                      {parseFloat(
                                        product.average_rating,
                                      ).toFixed(1)}
                                    </Text>
                                    <MCIcon
                                      name="star"
                                      style={styles.ratingBoxIcon}
                                    />
                                  </View>
                                  <Text style={styles.reviewsQty}>
                                    ({product.rating_count})
                                  </Text>
                                </View>
                              ) : (
                                false
                              )}
                            </View>
                            {!(product.stock_status === 'IN_STOCK') ? (
                              <View style={styles.availablityWrapper}>
                                <Text style={styles.soldOutText}>Sold out</Text>
                              </View>
                            ) : null}
                            {product.tier_prices ? (
                              <View style={styles.tierPriceWrapper}>
                                {product.tier_prices.map(
                                  (tierItem, index) =>
                                    tierItem.value < minimalPrice && (
                                      <Text
                                        style={styles.tierPrice}
                                        key={index}>
                                        Buy {tierItem.qty} or above for{' '}
                                        {
                                          product.price.regularPrice.amount
                                            .currency
                                        }
                                        {tierItem.value} each and save{' '}
                                        {(
                                          100 -
                                          (tierItem.value * 100) /
                                            product.price.minimalPrice.amount
                                              .value
                                        ).toFixed(2)}
                                        %
                                      </Text>
                                    ),
                                )}
                              </View>
                            ) : null}
                            {!(product.stock_status === 'IN_STOCK') ?
                                 <SubscribeForStockAlert productId={product.id} navigation={navigation}/>
                             : null
                            }
                            {product.stock_status === 'IN_STOCK' ? (
                              <View style={styles.groupedQuantityWrapper}>
                                <QuantitySelector
                                  qty={0}
                                  type="grouped"
                                  id={product.id}
                                  sku={product.sku}
                                  product_this={_this}
                                  title="product"
                                />
                              </View>
                            ) : null}
                            <ExpiryInfoComponent productExpiry={product.pd_expiry_date} infoToDisplay={`Expires in/after`} producType={"grouped"} />
                          </View>
                        );
                      })}
                    </View>
                  );
                } else {
                  return <Text>No group Products Available.</Text>;
                }
              }
            }}
          </Query>
        )}
      </View>
    );
  }
}
