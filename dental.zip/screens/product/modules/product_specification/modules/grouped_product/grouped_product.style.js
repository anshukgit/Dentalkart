import {StyleSheet} from 'react-native';
import {DeviceWidth} from '@config/environment'
export default styles = StyleSheet.create({
    groupedWrapper:{
		backgroundColor: '#fff',
        padding: 5,
        borderRadius: 3,
        marginTop: 5,
        marginBottom: 5,
        elevation: 1.5,
		shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
	},
    groupedProductNameWrapper: {
		width: DeviceWidth-80,
		marginBottom: 5
	},
	groupedProductName: {
		fontSize: 13,
		color: '#212121',
	},
    productGroupedPriceInfoWrapper: {
		flexDirection: 'row',
		alignItems: 'center',
		marginBottom: 5
	},
    productNewpriceWrapper: {
		flexDirection: 'row',
		alignItems: 'center'
	},
    currency: {
		fontSize: 12,
	},
	productNewprice:{
		fontSize: 25,
		color: '#212121',
		marginRight: 5
	},
    productOldprice: {
		textDecorationLine: 'line-through',
		textDecorationStyle: 'solid',
		fontSize: 12,
		color: '#21212180',
		marginRight: 5,
		color: '#bbbbbb'
	},
    productDiscount: {
		color: 'green',
		fontSize: 13
	},
    reviewsWrapper: {
		flexDirection: 'row',
		marginLeft: 7
	},
	ratingBoxWrapper: {
		flexDirection: 'row',
		backgroundColor: '#1abf46',
		justifyContent: 'center',
		alignItems: 'center',
		borderRadius: 3,
		paddingLeft: 3,
		paddingRight: 3
	},
	ratingBox: {
		color: '#fff',
		marginRight: 2,
		fontSize: 12
	},
    ratingBoxIcon: {
		color: '#fff',
		fontSize: 12
	},
	reviewsQty: {
		marginLeft: 5,
		fontSize: 12,
		color: '#21212180',
	},
    availablityWrapper: {
		backgroundColor: 'red',
		position: 'absolute',
		top: 5,
		right: 5,
		paddingVertical: 1,
		paddingHorizontal: 5,
		borderRadius: 20
	},
	soldOutText: {
		fontSize: 10,
        color: '#fff',
	},
    tierPrice: {
		fontSize: 11,
		color: '#00a324'
	},
    tierPriceWrapper: {
		marginBottom: 5
	},
})
