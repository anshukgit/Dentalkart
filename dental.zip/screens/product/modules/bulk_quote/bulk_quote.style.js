import {StyleSheet} from 'react-native';
import {DeviceWidth, SecondaryColor, PrimaryColor} from '@config/environment';

export default styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        marginTop:40
     },
    textfield: {
        height:40,
        borderRadius: 4,
        marginLeft:5,
        marginRight:5,
        padding:4,
        borderWidth: 0.5,
        borderColor: '#cccc',
    },
    placeholderColor: {
        borderColor: '#787878',
    },
    button: {
       alignItems: 'center',
       backgroundColor: 'orange',
       padding: 4,
       margin:5,
       alignItems:'center',
       height:40,
   },
    text: {
        color:"white",
        padding:5,
        fontWeight:'bold'
    },
    errortext: {
        fontSize:12,
        color:'red',
        marginLeft:5,
        padding:5
    },
    footerContainerWrapper: {
        backgroundColor: '#f3f3f3',
        paddingBottom: 10
    },
    footerContainer: {
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems:'center',
        paddingVertical: 10
    },
    footerHeading: {
        marginBottom: 8
    },
    quoteButton: {
        height:40,
        backgroundColor:'#0061d5',
        padding:4,
        borderRadius:4
    },
    quoteText: {
        color:'white',
        fontWeight:'bold',
        padding:7,
        textAlign:'center'
    }
})
