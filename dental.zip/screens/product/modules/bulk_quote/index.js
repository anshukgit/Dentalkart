import React, {Component} from 'react';
import {Mutation} from 'react-apollo';
import {BULK_ORDER_MUTATION} from '../../graphql';
import {
  View,
  Modal,
  Text,
  Alert,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Platform,
  ToastAndroid,
  KeyboardAvoidingView,
} from 'react-native';
import styles from './bulk_quote.style';
import Header from '@components/header';
import {validateEmail, validateMobile} from '@helpers/validator';
import {showErrorMessage, showSuccessMessage} from '../../../../helpers/show_messages';

// export default class BulKQuote extends Component{
//     render(){
//         return(
//             <View>
//                 <Text>Nakul</Text>
//             </View>
//         )
//     }
// }
export default class BulKQuote extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userName: '',
      userNameError: '',
      userPhone: '',
      userPhoneError: '',
      userEmail: '',
      userEmailError: '',
      userPincode: '',
      userPincodeError: '',
      expectedPrice: null,
      expectedPriceError: '',
      bulkQuantity: null,
      bulkQuantityError: '',
      prod_sku: '',
    };
  }
  handleBulkOrderDataChange = (name, value) => {
    if (value) {
      this.setState({
        [name]: value,
      });
    } else {
      this.setState({
        [name]: '',
      });
    }
  };
  onBulkOrderSubmit = bulkOrderMutation => {
    const {
      userName,
      userEmail,
      userPhone,
      userPincode,
      bulkQuantity,
      expectedPrice,
    } = this.state;
    if (!userName) {
      this.setState({userNameError: 'Name is required field.'});
      return false;
    } else {
      this.setState({userNameError: ''});
    }
    if (!userPhone) {
      this.setState({userPhoneError: 'Phone is required field.'});
      return false;
    } else if (userPhone && !validateMobile(userPhone)) {
      this.setState({userPhoneError: 'please enter correct phone number.'});
      return false;
    } else {
      this.setState({userPhoneError: ''});
    }
    if (!userEmail) {
      this.setState({userEmailError: 'Email is required field.'});
      return false;
    } else if (userEmail && !validateEmail(userEmail)) {
      this.setState({userEmailError: 'Please enter correct email'});
      return false;
    } else {
      this.setState({userEmailError: ''});
    }
    if (!userPincode) {
      this.setState({userPincodeError: 'please enter pincode'});
      return false;
    } else {
      this.setState({userPincodeError: ''});
    }
    if (!expectedPrice) {
      this.setState({expectedPriceError: 'Please enter expected price.'});
      return false;
    } else {
      this.setState({expectedPriceError: null});
    }
    if (!bulkQuantity) {
      this.setState({bulkQuantityError: 'Quantity is required field.'});
      return false;
    } else {
      this.setState({bulkQuantityError: null});
    }

    bulkOrderMutation();
  };
  handleError = ({graphQLErrors, networkError, operation, response}) => {
    if (graphQLErrors) {
      graphQLErrors.map(({message, category, path, debugMessage}) => {
        switch (category) {
          case 'graphql-authorization':
            console.warn(message);
            break;
          case 'internal':
            console.warn(message);
            break;
          default:
            if (Platform.OS === 'ios') {
              return setTimeout(() => Alert.alert(message), 500);
            } else {
              return showErrorMessage(message);
            }
            console.warn(message);
        }
        return null;
      });
    } else if (networkError) {
      console.warn(JSON.stringify(networkError));
    } else if (operation) {
      console.warn(JSON.stringify(operation));
    } else if (response) {
      console.warn(JSON.stringify(response));
    }
  };
  postBulkOrderSubmit = ({data}) => {
    const {_this, closeBulkModal} = this.props;
    this.setState({
      userName: '',
      userNameError: '',
      userPhone: '',
      userPhoneError: '',
      userEmail: '',
      userEmailError: '',
      userPincode: '',
      userPincodeError: '',
      expectedPrice: null,
      expectedPriceError: '',
      bulkQuantity: null,
      bulkQuantityError: '',
      prod_sku: '',
    });
    if (data) {
      if (Platform.OS === 'ios') {
        return setTimeout(
          () =>
            Alert.alert('', 'Request received successfully', [
              {text: 'OK', onPress: () => closeBulkModal()},
            ]),
          500,
        );
      } else {
        closeBulkModal();
        return showSuccessMessage('Request received successfully');
      }
    } else {
      return null;
    }
  };
  render() {
    const {_this, closeBulkModal, openBulkModal} = this.props;
    const {
      userName,
      userEmail,
      userPhone,
      userPincode,
      bulkQuantity,
      expectedPrice,
      prod_sku,
    } = this.state;
    const variables = {
      name: userName,
      email: userEmail,
      phone: userPhone,
      postcode: userPincode,
      prod_sku: this.props.product.sku,
      quantity: bulkQuantity,
      expected_price: expectedPrice,
      source: _this.state.bulkModalSoure,
    };
    return (
      <View>
        <View style={styles.footerContainerWrapper}>
          <View style={styles.footerContainer}>
            <Text style={styles.footerHeading}>
              Want to buy even more quantity?
            </Text>
            <TouchableOpacity
              style={styles.quoteButton}
              onPress={() => openBulkModal(0)}>
              <Text style={styles.quoteText}>GET BULK QUOTE NOW</Text>
            </TouchableOpacity>
          </View>
        </View>
        <Modal
          animationType="slide"
          transparent={false}
          visible={_this.state.bulkModalVisible}>
          <Header
            back={false}
            heading="Price Quote"
            navigation={_this.props.navigation}
            backCoustomMethod={closeBulkModal}
          />
          <ScrollView keyboardShouldPersistTaps="handled">
            <View style={styles.container}>
              <TextInput
                style={styles.textfield}
                autoCapitalize="none"
                placeholder="Name"
                placeholderTextColor={styles.placeholderColor.borderColor}
                value={this.state.userName}
                onChangeText={value =>
                  this.handleBulkOrderDataChange('userName', value)
                }
              />
              <Text style={styles.errortext}>{this.state.userNameError}</Text>
              <TextInput
                style={styles.textfield}
                placeholder="Phone Number"
                placeholderTextColor={styles.placeholderColor.borderColor}
                keyboardType={'numeric'}
                onChangeText={value =>
                  this.handleBulkOrderDataChange('userPhone', value)
                }
                value={this.state.userPhone}
              />
              <Text style={styles.errortext}>{this.state.userPhoneError}</Text>
              <TextInput
                style={styles.textfield}
                placeholder="Email"
                placeholderTextColor={styles.placeholderColor.borderColor}
                autoCapitalize="none"
                value={this.state.userEmail}
                onChangeText={value =>
                  this.handleBulkOrderDataChange('userEmail', value)
                }
              />
              <Text style={styles.errortext}>{this.state.userEmailError}</Text>
              <TextInput
                style={styles.textfield}
                placeholder="Pincode"
                placeholderTextColor={styles.placeholderColor.borderColor}
                keyboardType={'numeric'}
                value={this.state.userPincode}
                onChangeText={value =>
                  this.handleBulkOrderDataChange('userPincode', value)
                }
              />
              <Text style={styles.errortext}>
                {this.state.userPincodeError}
              </Text>
              <TextInput
                style={styles.textfield}
                placeholder="Expected price per piece"
                placeholderTextColor={styles.placeholderColor.borderColor}
                keyboardType={'numeric'}
                value={this.state.expectedPrice}
                onChangeText={value =>
                  this.handleBulkOrderDataChange('expectedPrice', value)
                }
              />
              <Text style={styles.errortext}>
                {this.state.expectedPriceError}
              </Text>
              <TextInput
                style={styles.textfield}
                placeholder="Quantity"
                placeholderTextColor={styles.placeholderColor.borderColor}
                keyboardType={'numeric'}
                value={this.state.bulkQuantity}
                onChangeText={value =>
                  this.handleBulkOrderDataChange('bulkQuantity', value)
                }
              />
              <Text style={styles.errortext}>
                {this.state.bulkQuantityError}
              </Text>
              <KeyboardAvoidingView
                behaviour={Platform.OS === 'ios' ? 'padding' : ''}
                style={{marginBottom: Platform.OS === 'ios' ? 250 : 0}}>
                <Mutation
                  mutation={BULK_ORDER_MUTATION}
                  variables={variables}
                  update={this.postBulkOrderSubmit}
                  onError={error => this.handleError(error)}>
                  {(bulkOrderMutation, {data, loading, error}) => {
                    return (
                      <TouchableOpacity
                        style={styles.button}
                        onPress={() =>
                          !loading
                            ? this.onBulkOrderSubmit(bulkOrderMutation)
                            : null
                        }>
                        <Text style={styles.text}>
                          {loading ? 'Submiting...' : 'Submit'}
                        </Text>
                      </TouchableOpacity>
                    );
                  }}
                </Mutation>
              </KeyboardAvoidingView>
            </View>
          </ScrollView>
        </Modal>
      </View>
    );
  }
}
