import {StyleSheet} from 'react-native';
import {DeviceHeight, DeviceWidth, SecondaryColor} from '@config/environment';

export default styles = StyleSheet.create({
	productGroupedPriceInfoWrapper: {
		flexDirection: 'row',
		alignItems: 'center',
		marginBottom: 5
	},
    rewardWrapper: {
		flexDirection: 'row',
		alignItems: 'center',
		marginVertical: 5
	},
	rewardIcon: {
		width: 20,
		height: 20,
		marginRight: 3
	},
	rewardPoints: {
		color: '#282828',
		fontSize: 15
	}
})
