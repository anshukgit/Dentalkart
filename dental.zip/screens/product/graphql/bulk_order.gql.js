import gql from 'graphql-tag';
const BULK_ORDER=gql`
    mutation bulkOrder(
        $name:String!,
        $email:String!,
        $phone:String!,
        $postcode:String!,
        $prod_sku:String!,
        $quantity:Int!,
        $expected_price:Float!,
        $source:Int!
    ){
    bulkOrder(input:{
        name:$name,
        email:$email,
        phone:$phone,
        postcode:$postcode,
        prod_sku:$prod_sku,
        quantity:$quantity,
        expected_price:$expected_price,
        source:$source})
        {
           message
        }
    }
`;
export default BULK_ORDER;
