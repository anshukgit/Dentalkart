import gql from "graphql-tag";

const GET_GROUP_PRODUCT_QUERY = gql`
    query productData ($sku : String){
        products(filter : {
            sku : {
                eq : $sku
            }
        })
        {
            items{
                ... on GroupedProduct{
                    items{
                        product{
                            name
                            sku
                            special_price
                            stock_status
                            id
                            type_id
                            expiry
                            pd_expiry_date
                            dispatch_days
                            weight
                            short_description{
                                html
                            }
                            reward_point_product
                            tier_prices{
                                qty
                                value
                                percentage_value
                            }
                            price{
                                regularPrice{
                                    amount{
                                        value
                                        currency
                                    }
                                }
                                minimalPrice{
                                    amount{
                                        value
                                        currency
                                    }
                                }
                                maximalPrice{
                                    amount{
                                        value
                                        currency
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
`;

export default GET_GROUP_PRODUCT_QUERY;
