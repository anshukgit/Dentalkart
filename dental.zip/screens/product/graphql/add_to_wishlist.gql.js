import gql from "graphql-tag";
const ADD_TO_WISHLIST = gql`
    mutation addItem($productId: Int!){
        dkAddItemToWishlist(productId: $productId){
            items{
                id
                wishlist_id
                product_id
                qty
                description
                added_at
                sku
            }
        }
    }
`;
export default ADD_TO_WISHLIST;
