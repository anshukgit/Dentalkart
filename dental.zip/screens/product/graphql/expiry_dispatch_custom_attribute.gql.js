import gql from 'graphql-tag';

const GET_DISPATCH_INFORMATION = gql`
    query customAttributeMetadata ($attribute_code: String, $entity_type : String){
        customAttributeMetadata(attributes: {
            attribute_code:$attribute_code
            entity_type:$entity_type
        })
    {
        items{
            attribute_code
            entity_type
            attribute_type
            attribute_options{
                label
                value
            }
        }
    }
}`

export default  GET_DISPATCH_INFORMATION;
