
export { default as DELETE_WISHLIST_ITEM_QUERY } from './delete_wishlist_item.gql';
export { default as GET_CUSTOMER_WISHLIST_ITEMS } from './get_customer_wishlist.gql';
