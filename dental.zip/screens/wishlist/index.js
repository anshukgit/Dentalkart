import React, {Component} from 'react';
import {
  View,
  ActivityIndicator,
  FlatList,
  ToastAndroid,
  Image,
  Text,
} from 'react-native';
import WishlistProducts from './modules/wishlist_products';
import {Query} from 'react-apollo';
import {
  DELETE_WISHLIST_ITEM_QUERY,
  GET_CUSTOMER_WISHLIST_ITEMS,
} from './graphql';
import {client} from '@apolloClient';
import {addToCart} from '@screens/cart';
import Header from '@components/header';
import Styles from './wishlist.style';
import Loader from '@components/loader';
import {fireAnalyticsEvent} from '@helpers/firebase_analytics';
import {DentalkartContext} from '@dentalkartContext';
import {showErrorMessage, showSuccessMessage} from '../../helpers/show_messages';

const EmptyWishlist = () => {
  return (
    <View style={Styles.wrapper}>
      <Text style={Styles.textHeading}>{"It's Empty Here !"}</Text>
      <Image
        source={{
          uri:
            'https://s3.ap-south-1.amazonaws.com/dentalkart-media/App/wishlistApp.png',
        }}
        style={Styles.emptyImage}
      />
      <Text style={Styles.textAfterImage}>
        You have no items currently. Start adding!
      </Text>
    </View>
  );
};

export default class Wishlist extends Component {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    this.state = {};
  }
  removeItem = async id => {
    try {
      const data = client.mutate({
        mutation: DELETE_WISHLIST_ITEM_QUERY,
        variables: {wishlistItemId: id},
      });
      showSuccessMessage('Removed from the Wishlist');
    } catch (err) {
      console.log(err);
    }
  };
  addToCart = async item => {
    if (item.type_id === 'simple') {
      await addToCart(item, this.context);
    } else {
      this.navigateToDetail(item);
    }
  };
  navigateToDetail(item) {
    this.props.navigation.push('ProductDetails', {productUrl: item.url_key});
  }
  triggerScreenEvent = _ => {
    const {userInfo} = this.context;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Wishlist',
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };
  componentDidMount() {
    this.triggerScreenEvent();
  }
  render() {
    return (
      <View style={{flex: 1}}>
        <Header back heading="My Wishlist" navigation={this.props.navigation} />
        <Query
          query={GET_CUSTOMER_WISHLIST_ITEMS}
          fetchPolicy="cache-and-network">
          {({data, loading, error}) => {
            if (error) {
              return showErrorMessage(`${error.message}. Please try again.`);
            }
            if (loading) {
              return <Loader loading={true} transparent={true} />;
            }
            if (data && data.customer.wishlist) {
              let products = data.customer.wishlist
                ? data.customer.wishlist.items
                : [];
              return (
                <FlatList
                  data={products}
                  renderItem={({item}) => (
                    <WishlistProducts
                      item={item}
                      _this={this}
                      wishlistId={item.id}
                    />
                  )}
                  keyExtractor={(item, index) => item.sku}
                  initialNumToRender={5}
                  ListEmptyComponent={() => <EmptyWishlist />}
                />
              );
            } else {
              return <Text>Something went wrong !</Text>;
            }
          }}
        </Query>
      </View>
    );
  }
}
