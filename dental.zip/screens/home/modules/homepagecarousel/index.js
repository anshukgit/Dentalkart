import React, {PureComponent} from 'react';
import { StyleSheet, Text, View, Image, FlatList, TouchableOpacity} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import styles from './homepagecarousel.style';
import getImageUrl from '@helpers/getImageUrl';
import getDiscount from '@helpers/getDiscount';
import MCIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import {DentalkartContext} from '@dentalkartContext';

export default class HomepageCarousel extends PureComponent{
    static contextType = DentalkartContext;
    getProductBlock = (product, index) => {
        if (product) {
            return (
                <View>{this.productsCardTemplate(product, index)}</View>
            );
        }
        return <Text>No product data</Text>
    }
    productsCardTemplate = (product, index)=> {
        const {navigation} = this.props;
        const isPriceVisible = !product.msrp;
        const regularPrice = product.price.regularPrice.amount.value;
        const minimalPrice = product.price.minimalPrice.amount.value;
        const discountPercentage = getDiscount(product);
        const currency = product.price.regularPrice.amount.currency;
        const getImageObj= product.media_gallery_entries.filter(data => data.types.length>0).find(data=>data.file)
        const imageUrl = getImageObj && getImageObj.file
    	return (
    		<TouchableOpacity onPress={() => navigation.navigate('UrlResolver', {url_key: product.url_key})}>
    			<View style={[styles.productBox, (index%2==0) ? styles.productBoxBorderRight : null, (index === 0 || index === 1) ? styles.productBoxBorderBottom : null]}>
    				<View style={styles.productImageWrapper}>
    					<Image resizeMethod={"resize"} source={{uri: getImageUrl(imageUrl)}} style={styles.productImage} />
    				</View>
                    <View style={styles.productNameWrapper}>
    					<Text numberOfLines={2} style={styles.productName}>{product.name}</Text>
    				</View>
    				<View style={styles.priceWrapper}>
                        <View style={styles.reviewWrapper}>
                            {(product.average_rating && parseFloat(product.average_rating) >0 ) ?
                                <View style={styles.ratingWrapper}>
                                    <Text style={styles.rating}>
                                        {parseFloat(product.average_rating).toFixed(1)}
                                        <MCIcon name='star' style={styles.star} />
                                    </Text>
                                </View> :
                                null}
                                {product.rating_count && <View><Text style={styles.numbers}>({product.rating_count} ratings & reviews)</Text></View>}
                        </View>
                        {isPriceVisible &&
                            <View style={styles.pricingWrapper}>
                                {
                                    <View style={styles.pricingWrapper}>
                                        {   product.type_id === 'grouped' ?
                                            (<Text style={styles.numbers}>Starting at: </Text>) : null
                                        }
                                        <Text style={styles.specialPrice}>{`${currency} ${minimalPrice} `}</Text>
                                    </View>
                                }
                                { (minimalPrice !== regularPrice) & regularPrice > 0 ? (<Text style={styles.newPrice}>{currency}{regularPrice}</Text>) : null}
                                {/*discountPercentage > 0 ? (<Text style={styles.discount}>{discountPercentage}% Off</Text>) : null*/}
                            </View>
                        }
    				</View>
                    {((this.context.country && this.context.country.country_id === 'IN') && product.reward_point_product && product.reward_point_product !== 0)?
    					<View style={styles.rewardWrapper}>
    						<Image source={{uri: "https://s3.ap-south-1.amazonaws.com/dentalkart-media/React/coin.png"}} style={styles.rewardIcon}/>
    						<Text style={styles.rewardPoints}>{product.reward_point_product}</Text>
    					</View> : null
    				}
    				{product.discount>0? <Text style={styles.discount}>{product.discount}%</Text> : null}
    			</View>
    		</TouchableOpacity>
    	);
    }
    render(){
        const {gridData, getProduct, navigation} = this.props;
        const skus = gridData && gridData.sku.slice(0, 4);
        return(
            <View style={styles.cardWrapper}>
                <LinearGradient
                    colors={['#2b79ac', '#fff']}
                    start={{ x: 0, y: 0 }}
                    style={styles.cardWrapper}
                >
                    <View style={styles.categoryTitleWrapper}>
                        <View style={styles.categoryTitle}>
                            <Text style={styles.categoryName}>{gridData.heading}</Text>
                        </View>
                        <TouchableOpacity onPress={() => navigation.navigate('UrlResolver', { url_key: gridData.heading_url})}>
                            <View style={styles.categoryButtonWrapper}>
                                <View style={styles.categoryButton}>
                                    <Text style={styles.categoryButtonText}>View All</Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <FlatList
                        data = {skus}
                        renderItem={({item, index}) => this.getProductBlock(getProduct(item), index)}
                        numColumns={2}
                        keyExtractor={(sku, index) => index}
                        style={styles.productsCard}
                        initialNumToRender={4}
                    />
                </LinearGradient>
            </View>
        );
    }
}
