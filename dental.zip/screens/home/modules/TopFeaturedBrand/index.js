import React, {Component} from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity, ScrollView} from 'react-native';
import {client} from '@apolloClient';
import sortByPosition from '@helpers/sort_by_position';
import {Query} from 'react-apollo';
import GET_FEATURED_BRANDS_QUERY from '../../../brandPage/graphql/get_featured_brand.gql.js';
import styles from '../../../brandPage/featured_brand/featured_brand.style.js';
import {DeviceWidth} from '@config/environment';


class TopFeaturedBrands extends Component{

    render(){
        return(
            <View>
                <View>
                    <Query
                        query={GET_FEATURED_BRANDS_QUERY}
                        fetchPolicy="cache-and-network"
                    >
                        {({data,loading,error})=>{
                            if(data && data.getBrand){
                                const datalist= sortByPosition(data.getBrand);
                                return(
                                    <View style={{marginBottom:12, marginTop:12}}>
                                        <View style={{flex:1, justifyContent:'space-between', flexDirection:'row', paddingLeft:6, paddingRight:6, marginBottom: 10, alignItems:'center'}}>
                                            <Text style={styles.topText}>Top Brands</Text>
                                            <TouchableOpacity  style = {styles.brandButton} onPress={()=>this.props.navigation.navigate('BrandPageScreen')}>
                                                <Text style={styles.BrandText}>View all Brands</Text>
                                            </TouchableOpacity>
                                        </View>
                                        <View >
                                            <ScrollView
                                                horizontal={true}
                                                showsHorizontalScrollIndicator={false}
                                                >
                                                <View style={{flex:1,flexDirection:'row', marginLeft:7}}>
                                                    {
                                                        datalist.map((value, index) =>
                                                            (value.is_active && index < 8) &&
                                                               <TouchableOpacity style={{ width:`${(100/8)}%`, margin:'auto', marginBottom:7, justifyContent: 'center', alignItems: 'center', backgroundColor: "#fff"}} onPress={() => this.props.navigation.navigate('UrlResolver', { url_key: `/${value.url_path}.html`})}>
                                                                    <View style={[styles.imageBox, styles.HomeExtraMargin]}>
                                                                        <Image
                                                                            source={{
                                                                              uri:`https://www.dentalkart.com/media/${value.logo}`
                                                                            }}
                                                                            style={styles.image}
                                                                        >
                                                                        </Image>
                                                                    </View>
                                                                    <Text style={styles.bottomText}>{value.name}</Text>
                                                                </TouchableOpacity>
                                                            )
                                                    }
                                                </View>
                                            </ScrollView>

                                        </View>


                                    </View>
                                )
                            }
                            else if (error) {return<Text>{JSON.stringify(error)}</Text>}
                            else if (loading) {return null}
                            else return null
                        }}
                    </Query>
                </View>
            </View>
        )
    }
}


export default TopFeaturedBrands;
