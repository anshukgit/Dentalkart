import React, {PureComponent} from 'react';
import {
  Text,
  View,
  FlatList,
  ScrollView,
  ToastAndroid,
  Image,
  TouchableOpacity,
   Platform,
    Linking

} from 'react-native';
import {Query} from 'react-apollo';
import Header from '@components/header';
import HomepageSlider from './modules/homepageslider';
import HomepageBrands from './modules/homepagebrands';
import HomepageBanner from './modules/homepagebanner';
import HomepageCarousel from './modules/homepagecarousel';
import TopFeaturedBrands from './modules/TopFeaturedBrand';
import {
  GET_SLIDER_BRAND_FLASH_SALE_QUERY,
  GET_CAROUSEL_AND_BANNERS_QUERY,
  GET_CAROUSEL_PRODUCTS_QUERY,
  GET_NOTICES
} from './graphql';
import chunkify from '@helpers/chunkify';
import getImageUrl from '@helpers/getImageUrl';
import styles from './home.style';
import {SecondaryColor} from '@config/environment';
import {DentalkartContext} from '@dentalkartContext';
import {fireAnalyticsEvent} from '@helpers/firebase_analytics';
import {showErrorMessage} from '../../helpers/show_messages';
import { client2 } from '@apolloClient';

export default class Home extends PureComponent {
  static contextType = DentalkartContext;
  getSliderBrands = () => {
    return (
      <Query
        query={GET_SLIDER_BRAND_FLASH_SALE_QUERY}
        fetchPolicy="cache-and-network"
        onError={error => {
          showErrorMessage(`${error.message}. Please try again.`);
        }}>
        {({loading, error = false, data}) => {
          if (loading || error) {
            return (
              <Image
                source={{
                  uri:
                    'https://dentalkart-media.s3.ap-south-1.amazonaws.com/App/unnamed.gif',
                }}
                style={styles.noSliderImage}
              />
            );
          }
          const {gethomepagesliders, gethomepagesalesbanner} = data;
          if (data && gethomepagesliders && gethomepagesalesbanner) {
            return (
              <View>
                <HomepageSlider
                  navigation={this.props.navigation}
                  data={gethomepagesliders}
                />
              </View>
            );
          } else {
            return (
              <Image
                source={{
                  uri:
                    'https://dentalkart-media.s3.ap-south-1.amazonaws.com/App/unnamed.gif',
                }}
                style={styles.noSliderImage}
              />
            );
          }
        }}
      </Query>
    );
  };
  getCarouselAndBanners = () => {
    const getAllCarouselSku = carousels => {
      const allSkus = [];
      carousels.map(carousel => {
        carousel.sku.map((sku, index) => {
          if (index < 4 && sku) {
            allSkus.push(sku);
          }
          return null;
        });
        return null;
      });
      return allSkus;
    };
    return (
      <Query
        query={GET_CAROUSEL_AND_BANNERS_QUERY}
        fetchPolicy="no-cache"
        onError={error => {
          showErrorMessage(`${error.message}. Please try again.`);
        }}>
        {({loading, error, data}) => {
          if (loading || error) {
            return (
              <Image
                source={{
                  uri:
                    'https://dentalkart-media.s3.ap-south-1.amazonaws.com/App/ezgif.com-crop+%281%29.gif',
                }}
                style={styles.noCarouselImage}
              />
            );
          }
          if (
            data.gethomepagecarousel &&
            data.gethomepagebannersv2 &&
            data.gethomepagebrands
          ) {
            const gethomepagebrands = data.gethomepagebrands;
            const bannersData = data.gethomepagebannersv2
              ? data.gethomepagebannersv2
              : [];
            const bannersGroup = chunkify(bannersData, 10, 3);
            const carouselData = data.gethomepagecarousel
              ? data.gethomepagecarousel
              : [];
            const skus = getAllCarouselSku(carouselData);
            return (
              <View>
                <Query
                  query={GET_CAROUSEL_PRODUCTS_QUERY}
                  fetchPolicy="cache-and-network"
                  variables={{sku: skus}}>
                  {({loading, error, data}) => {
                    if (loading || error) {
                      return (
                        <Image
                          source={{
                            uri:
                              'https://dentalkart-media.s3.ap-south-1.amazonaws.com/App/ezgif.com-crop+%281%29.gif',
                          }}
                          style={styles.noCarouselImage}
                        />
                      );
                    }
                    if (data.products) {
                      const setProductsObj = () => {
                        const products = {};
                        data.products.items.map(
                          product =>
                            (products[
                              product.sku.toLowerCase().trim()
                            ] = product),
                        );
                        const getProduct = sku => products[sku.toLowerCase()];
                        return getProduct;
                      };
                      const getProduct = setProductsObj();
                      const prsentation = [
                        {el: 'cr', index: 0},
                        {el: 'br', index: 0},

                        {el: 'cr', index: 1},
                        {el: 'bg', index: 0},

                        {el: 'cr', index: 2},
                        {el: 'bg', index: 1},

                        {el: 'cr', index: 3},
                        {el: 'bg', index: 2},

                        {el: 'cr', index: 4},
                        {el: 'bg', index: 3},

                        {el: 'cr', index: 5},
                        {el: 'bg', index: 4},

                        {el: 'cr', index: 6},
                        {el: 'bg', index: 5},

                        {el: 'cr', index: 7},
                        {el: 'bg', index: 6},

                        {el: 'cr', index: 8},
                        {el: 'bg', index: 7},

                        {el: 'cr', index: 9},
                        {el: 'bg', index: 8},

                        {el: 'bg', index: 9},
                      ];
                      const getElement = prsentation => {
                        const elementTypes = {
                          cr: carouselData[prsentation.item.index] ? (
                            <HomepageCarousel
                              navigation={this.props.navigation}
                              gridData={carouselData[prsentation.item.index]}
                              getProduct={getProduct}
                            />
                          ) : null,
                          br: (
                            <HomepageBrands
                              data={gethomepagebrands}
                              navigation={this.props.navigation}
                            />
                          ),
                          bg: bannersGroup[prsentation.item.index] ? (
                            <HomepageBanner
                              navigation={this.props.navigation}
                              data={bannersGroup[prsentation.item.index]}
                            />
                          ) : null,
                        };
                        return elementTypes[prsentation.item.el];
                      };
                      return (
                        <View>
                          <FlatList
                            data={prsentation}
                            renderItem={(prsentation, index) =>
                              getElement(prsentation)
                            }
                            numColumns={1}
                            keyExtractor={(prsentation, index) =>
                              index.toString()
                            }
                            initialNumToRender={4}
                          />
                        </View>
                      );
                    } else {
                      return (
                        <Image
                          source={{
                            uri:
                              'https://dentalkart-media.s3.ap-south-1.amazonaws.com/App/ezgif.com-crop+%281%29.gif',
                          }}
                          style={styles.noCarouselImage}
                        />
                      );
                    }
                  }}
                </Query>
              </View>
            );
          } else {
            return null;
          }
        }}
      </Query>
    );
  };
  scrollToTop = () => {
    this.scrollView.scrollTo({x: 0, y: 0, animated: true});
  };
  triggerScreenEvent = _ => {
    const {userInfo} = this.context;
    const {navigation} = this.props;
    let {params} = navigation.state;
    const entry = params ? params.entry : false;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Home',
      entry,
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };
  getHomePageNotices = () => {
    const {handleError} = this.context;
    return (
      <View>
        <Query
          query={GET_NOTICES}
          fetchPolicy="network-only"
          client={client2}
          onError={error => handleError(error)}>
          {({loading, data, error}) => {
            if (loading || error) {
              return null;
            }
            if (data && data.notices) {
              const {notices} = data;
              const homepageNoticesAndroid = notices.filter(notice => notice.section === 'homepage' && notice.source === 'only_android');
              const homepageNoticesIos = notices.filter(notice => notice.section === 'homepage' && notice.source === 'only_ios');
              if (homepageNoticesAndroid.length>0 || homepageNoticesIos.length>0) {
                return (
                    <View>
                      {
                           Platform.OS === 'ios' ?
                           <View style={{ margin: 6}}>
                               {homepageNoticesIos.map(notice => (
                                   <TouchableOpacity onPress={()=>  notice.link ? Linking.openURL(notice.link) : null} style={{padding: 6, backgroundColor:notice.background || '#fff' }}>
                                       <Text style={{color: notice.colour || SecondaryColor, backgroundColor:notice.background || '#fff' }}>
                                         {notice.content}
                                       </Text>
                                  </TouchableOpacity>
                               ))}
                           </View> :
                           <View style={{margin: 6}}>
                               {homepageNoticesAndroid.map(notice => (
                                   <TouchableOpacity onPress={()=>  notice.link ? Linking.openURL(notice.link) : null} style={{padding: 6, backgroundColor:notice.background || '#fff'}}>
                                       <Text style={{color: notice.colour || SecondaryColor}}>
                                         {notice.content}
                                       </Text>
                                  </TouchableOpacity>
                               ))}
                           </View>
                       }
                 </View>
               );
              } else {
                return null;
              }
            } else {
              return null;
            }
          }}
        </Query>
      </View>
    );
  };

  componentDidMount() {
    this.triggerScreenEvent();
  }
  render() {
    // const {userInfo} = this.context;
    return (
      <View>
        <Header
          menu
          cart
          title
          home
          navigation={this.props.navigation}
          scrollToTop={this.scrollToTop}
        />
        <ScrollView ref={ref => (this.scrollView = ref)}>
          <View style={styles.scrollViewContainer}>
            {/* <Text>Naveen</Text> */}
            {this.getHomePageNotices()}
            {this.getSliderBrands()}
            <TopFeaturedBrands navigation={this.props.navigation}/>
            {this.getCarouselAndBanners()}
          </View>
        </ScrollView>
      </View>
    );
  }
}
