import {StyleSheet} from 'react-native';
import {DeviceWidth} from '@config/environment';

export default (styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollViewContainer: {
    marginBottom: 120,
  },
  noSliderImage: {
    width: DeviceWidth,
    height: (DeviceWidth * 145) / 384,
    borderRadius: 5,
    resizeMode: 'stretch',
  },
  noCarouselImage: {
    width: DeviceWidth,
    height: (DeviceWidth * 368) / 384,
    borderRadius: 5,
    resizeMode: 'stretch',
  },
}));
