import gql from 'graphql-tag';

const GET_CAROUSEL_PRODUCTS = gql`
    query productData ($sku : [String]!){
        products(filter : {
            sku : {
                in : $sku
            }
        },  pageSize: 60 )
        {
            items{
                id
                name
                thumbnail{
                    label
                    url
                }
                media_gallery_entries{
                    id
                    file
                    types
                }
                url_key
                url_path
                type_id
                stock_status
                short_description{
                    html
                }
                special_price
                reward_point_product
                sku
                average_rating
                rating_count
                msrp
                tier_prices{
                    qty
                    value
                    percentage_value
                }
                price{
                    regularPrice{
                        amount{
                            value
                            currency
                        }
                    }
                    minimalPrice{
                        amount{
                            value
                            currency
                        }
                    }
                    maximalPrice{
                        amount{
                            value
                            currency
                        }
                    }
                }
            }
        }
    }
`;

export default GET_CAROUSEL_PRODUCTS
