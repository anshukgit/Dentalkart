import React from 'react';
import {View, Text, TouchableOpacity, ActivityIndicator} from 'react-native';
import TouchableCustom from '@helpers/touchable_custom';
import {DeliveryPageStyle} from '../style';
import MIcon from 'react-native-vector-icons/MaterialIcons';
import {TextField} from 'react-native-material-textfield';
import {SecondaryColor} from '@config/environment';
import  {hasNotch} from 'react-native-device-info';

export const DeliveryAddress = ({address, _this}) => {
  const {navigate} = _this.props.navigation;
  return (
    <View style={DeliveryPageStyle.deliveryAddressWrapper}>
      <View>
        <View style={DeliveryPageStyle.nameWrapper}>
          <Text style={DeliveryPageStyle.name}>
            {address.firstname} {address.lastname}
          </Text>
        </View>
        <View style={DeliveryPageStyle.addressDetailWrapper}>
          {address.street[0] ? (
            <Text style={DeliveryPageStyle.addressText}>
              {address.street[0]}
            </Text>
          ) : null}
          {address.city ? (
            <Text style={DeliveryPageStyle.addressText}>{address.city}</Text>
          ) : null}
          {address.region ? (
            <Text style={DeliveryPageStyle.addressText}>
              {address.region.region} - {address.postcode}
            </Text>
          ) : null}
          {address.country ? (
            <Text style={DeliveryPageStyle.addressText}>
              {address.country.country}
            </Text>
          ) : null}
          <Text style={DeliveryPageStyle.addressText}>{address.telephone}</Text>
          {address.vat_id ? (
            <Text style={DeliveryPageStyle.addressText}>
              GSTIN: {address.vat_id}
            </Text>
          ) : null}
        </View>
        {/* {!address.alternate_mobile?
                    <View style={DeliveryPageStyle.alternate_mobile_field_wrapper}>
                        <View style={DeliveryPageStyle.alternate_mobile_message_wrapper}>
                            <Text style={DeliveryPageStyle.alternate_mobile_message}>*At the time of delivery in case we are unable to reach you on your primary number, please provide your alternate number.</Text>
                            <TouchableOpacity onPress={()=> _this.toggleAlternateField()}>
                                <Text style={DeliveryPageStyle.alternate_mobile_button}>{`Click To ${!_this.state.showAlternateField?'Add':'Hide'}`}</Text>
                            </TouchableOpacity>
                        </View>
                        {_this.state.showAlternateField?
                            <View>
                                <TextField
                                    label='Alternate Number'
                                    tintColor={SecondaryColor}
                                    labelHeight={15}
                                    onChangeText={(text) => _this.validate(text)}
                                    value={_this.state.alternateMobile}
                                    clearButtonMode={'always'}
                                    spellCheck={false}
                                    autoCorrect={false}
                                    returnKeyType="done"
                                    onSubmitEditing={()=> _this.addAlternateNumber(address)}
                                    blurOnSubmit={false}
                                    autoCapitalize={'none'}
                                    underlineColorAndroid={'transparent'}
                                    keyboardType = {'numeric'}
                                    fontSize={12}
                                    error={_this.state.alternateMobileError}
                                    containerStyle={DeliveryPageStyle.textField}
                                />
                            </View>
                            : null
                        }
                    </View>
                    : null
                } */}
        {/*<TouchableCustom
          underlayColor={'#ffffff10'}
          onPress={() =>
            _this.state.showAlternateField
              ? _this.addAlternateNumber(address)
              : navigate('Address', {checkout: true})
          }>
          <View style={DeliveryPageStyle.buttonWrapper}>
            <Text style={DeliveryPageStyle.buttonText}>
              {_this.state.showAlternateField ? 'Save' : 'Change/Add Address'}
            </Text>
          </View>
        </TouchableCustom>*/}
      </View>
    </View>
  );
};

export const Payments = ({_this, item}) => {
  return (
    <TouchableCustom
      underlayColor={'#ffffff10'}
      onPress={() => _this.setState({selectedMethodCode: item})}>
      <View style={DeliveryPageStyle.methodWrapper}>
        <View style={DeliveryPageStyle.paymentTitleWrapper}>
          <Text style={DeliveryPageStyle.paymentTitle}>{item.title}</Text>
        </View>
        <View style={DeliveryPageStyle.paymentRadioIconWrapper}>
          <MIcon
            name={`radio-button-${
              _this.state.selectedMethodCode === item ? 'checked' : 'unchecked'
            }`}
            size={18}
            style={DeliveryPageStyle.radioOff}
          />
        </View>
      </View>
    </TouchableCustom>
  );
};

export const DeliveryAction = ({priceDetails, _this}) => {
  const buttonDisabled = _this.state.selectedMethodCode ? false : true;
  return (
    <View style={DeliveryPageStyle.deliveryActionContainer}>
      {/* {!buttonDisabled?
                <Text style={DeliveryPageStyle.errorText}>
                    Please make sure that you have selected your current country delivery address.
                </Text>
            : null} */}
      <View style={DeliveryPageStyle.deliveryActionWrapper}>
        <View style={DeliveryPageStyle.shortSummaryWrapper}>
          <Text style={DeliveryPageStyle.totalText}>Total Payable Amount</Text>
          <Text style={DeliveryPageStyle.shortSummaryPrice}>
            {priceDetails.quote_currency_code}{' '}
            {
              priceDetails.total_segments[
                priceDetails.total_segments.length - 1
              ].value
            }
          </Text>
        </View>
        <View style={[DeliveryPageStyle.continueButtonWrapper, hasNotch() ? DeliveryPageStyle.buttonNotchIssue : '']}>
          <TouchableCustom
            underlayColor="#ffffff10"
            onPress={() =>
              !_this.state.showCircularProgress ? _this.placeOrder() : null
            }
            disabled={buttonDisabled}>
            <View
              style={[
                DeliveryPageStyle.placeOrderButton,
                buttonDisabled ? DeliveryPageStyle.disabled : null,
              ]}>
              {_this.state.showCircularProgress ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <Text style={DeliveryPageStyle.placeOrderButtonText}>
                  Place Order
                </Text>
              )}
            </View>
          </TouchableCustom>
        </View>
      </View>
    </View>
  );
};
