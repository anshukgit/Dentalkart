import React, {useState, useContext} from 'react';
import { FETCH_ORDER_DETAILS_QUERY } from '../graphql';
import {
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import {DentalkartContext} from '@dentalkartContext';
import {client} from '@apolloClient';
import RazorpayCheckout from 'react-native-razorpay';
import {NavigationActions, StackActions} from 'react-navigation';


export const RetryPaymentButton= (props) => {
    const {amount, order_id, reference_number, merchant_id, currency, customerEmail, contactNumber} = props.paymentData;
    const { handleError} = useContext(DentalkartContext);
    const [CircularProgress, setCircularProgress] = useState("false")

    function handleRazorpaySubmit () {
        const  payload =  {order_id : order_id}

        try {
            const options = {
              description: '',
              image: 'https://www.dentalkart.com/dentalkarticon.png',
              currency: currency,
              key: merchant_id,
              amount: amount,
              order_id: reference_number,
              name: 'Dentalkart',
              prefill: {
                email: customerEmail,
                contact:contactNumber
              },
              theme: {color: ''},
            };

            RazorpayCheckout.open(options)
              .then(response => {
                console.log('razorpay response ', response);
                const rzpres = {
                  rzp_payment_id: response.razorpay_payment_id,
                  rzp_order_id: response.razorpay_order_id,
                  rzp_signature: response.razorpay_signature,
                };
                const RzpPayload={...payload, ...rzpres}
                submitOrder(RzpPayload)
              })
              .catch(error => {
                submitOrder(payload)
                handleError(error);
              });

        }catch (error){
            handleError(error)
            setCircularProgress("false")
        }
    }


    const  submitOrder = async (payload) => {
        try{
            setCircularProgress("true")
            const {data} = await client.query({
                query: FETCH_ORDER_DETAILS_QUERY,
                fetchPolicy: 'network-only',
                variables:  {...payload}
            });

            if(data && data.fetchOrder && data.fetchOrder.order_id){
                setCircularProgress("false")

                if(data.fetchOrder && data.fetchOrder.status==='success'){
                    let resetAction;
                    resetAction = StackActions.reset({
                      index: 1,
                      actions: [
                        NavigationActions.navigate({routeName: 'Home'}),
                        NavigationActions.navigate({
                          routeName: 'OrderSuccess',
                          params: {orderId: data.fetchOrder.order_id, retryPayment:true},
                        }),
                      ],
                    });

                    props.navigation.dispatch(resetAction);

                }
                else{
                    let resetAction;
                     resetAction = StackActions.reset({
                       index: 1,
                       actions: [
                         NavigationActions.navigate({routeName: 'Home'}),
                         NavigationActions.navigate({
                           routeName: 'OrderDetails',
                           params: {orderId: data.fetchOrder.order_id, fetchOrderRes:data.fetchOrder}
                         }),
                       ],
                     });
                     props.navigation.dispatch(resetAction);
                }
            }
            else {
                console.log('not success')
            }
        }
        catch(e){
            setCircularProgress(false);
            handleError(e)
        }
    }

    return(
        <View>
            <View style={{flex:1, marginLeft:10,marginRight:10}}>
                <Text style={{ fontSize: 12, marginTop:10, marginBottom: 15}}>Your payment has failed. please try again.</Text>
                {CircularProgress === "false" ?
                    <TouchableOpacity  style={{ padding: 8, borderRadius: 5, backgroundColor: '#318be4' }} onPress={()=>handleRazorpaySubmit()}>
                        <Text style={{ color: '#fff', fontSize: 12, textAlign: 'center' }}>Retry Payment</Text>
                    </TouchableOpacity> :
                    <TouchableOpacity style={{ padding: 8, borderRadius: 5, backgroundColor: '#318be4' }} onPress={() => null}>
                        <Text style={{ color: '#fff', fontSize: 12, textAlign: 'center' }}>Retrying...</Text>
                    </TouchableOpacity>
                }
            </View>
        </View>
    )

}
