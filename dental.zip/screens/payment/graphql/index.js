export {default as PLACE_ORDER_MUTATION} from './dk_placeorder_mutation.gql.js';
export {default as FETCH_ORDER_DETAILS_QUERY} from './fetch_order.gql.js';
