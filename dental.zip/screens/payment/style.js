import { StyleSheet } from 'react-native';
import {DeviceWidth, PrimaryColor, SecondaryColor} from '@config/environment';

export const DeliveryPageStyle = StyleSheet.create({
    flatlistWrapper: {
        backgroundColor: '#fff',
    },
    deliveryAddressWrapper: {
        backgroundColor: '#fff',
        padding: 1,
        borderRadius: 3,
        marginTop: 5,
        marginBottom: 5,
        marginRight: 8,
        marginLeft: 8,
        elevation: 1,
        shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
    },
    nameWrapper: {
        paddingLeft: 10
    },
    name: {
        fontSize: 14,
    },
    addressDetailWrapper: {
        paddingLeft: 10
    },
    addressText: {
        fontSize: 12,
        color: '#21212180'
    },
    buttonWrapper:{
        backgroundColor: '#fff',
        marginVertical: 5,
        marginHorizontal: 10,
        height: 30,
        borderWidth: 0.4,
        borderColor: SecondaryColor,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
		elevation: 1.5,
        shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
    },
    buttonText: {
        color: SecondaryColor,
        fontSize: 13
    },
    shortSummaryPrice: {
        fontSize: 15,
        color: '#212121'
    },
    continueButtonWrapper: {
        width: DeviceWidth/2,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    methodWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 5,
        paddingVertical: 8,
        borderRadius: 3,
    },
    paymentTitleWrapper: {
        width : DeviceWidth/1.3
    },
    paymentTitle: {
        fontSize: 12,
        color: '#21212190'
    },
    paymentRadioIconWrapper:{
        alignItems: 'center',
        justifyContent: 'center',
    },
    radioOff: {
        color: SecondaryColor
    },
    placeOrderButton: {
        backgroundColor: PrimaryColor,
        width: DeviceWidth/2,
        height: 40,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 2,
        borderColor: '#b9b9b9',
        elevation: 1,
        shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
    },
    deliveryActionContainer: {
       backgroundColor: '#fff',
        elevation: 10,
        shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
        justifyContent: 'center',
    },
    deliveryActionWrapper: {
       flexDirection: 'row'
    },
    errorText: {
        textAlign: 'center',
        fontSize: 12,
        paddingBottom: 5,
        color: '#ed4949'
    },
    shortSummaryWrapper: {
        width: DeviceWidth/2,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
    },
    placeOrderButtonText: {
        color: '#fff',
        fontSize: 18
    },
    paymentWrapper: {
        shadowRadius: 2,
        marginTop: 5,
        marginHorizontal: 8,
        borderRadius: 3,
        backgroundColor: '#fff',
        marginBottom: 1,
        elevation: 2,
        shadowColor: '#bfbfbf',
        shadowOffset: {
          height: 0,
          width: 0
        },
        shadowOpacity: .5,
        shadowRadius: 2,
    },
    paymentHeading: {
        color: '#282828',
        paddingHorizontal: 8,
        paddingVertical: 10
    },
    totalText: {
        color: '#28282880',
        fontSize: 12
    },
    continueButtonText: {
        color: '#fff',
        fontSize: 18
    },
    disabled: {
        opacity: 0.5
    },
    alternate_mobile_field_wrapper: {
        padding: 10
    },
    alternate_mobile_message_wrapper: {
        marginBottom: 10
    },
    alternate_mobile_message: {
        color: '#f4433680',
        fontSize: 10
    },
    alternate_mobile_button: {
        color: SecondaryColor,
        fontSize: 12,
        textDecorationLine: 'underline'
    },
    buttonNotchIssue: {
        marginBottom: 20
    }
});