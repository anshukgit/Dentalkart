import React from 'react';
import {
  View,
  Text,
  ScrollView,
  FlatList,
  ActivityIndicator,
  Alert,
  ToastAndroid,
  TouchableHighlight,
} from 'react-native';
import Header from '@components/header';
import { DeliveryAddress, DeliveryAction, Payments } from './modules';
import { DeliveryPageStyle } from './style';
import { validateMobile } from '@helpers/validator';
import { DentalkartContext } from '@dentalkartContext';
import { postRequest, getRequest } from '@helpers/network';
import API from '@config/api';
import Loader from '@components/loader';
import RazorpayCheckout from 'react-native-razorpay';
import { NavigationActions, StackActions } from 'react-navigation';
import { fireAnalyticsEvent } from '@helpers/firebase_analytics';
import { GET_NOTICES } from '../../graphql';
import { PLACE_ORDER_MUTATION, FETCH_ORDER_DETAILS_QUERY } from './graphql'
import SyncStorage from '@helpers/async_storage';
import { client, client2 } from '@apolloClient';
import { Query } from 'react-apollo';
import {
  SecondaryColor,
  razorPayKeyId,
  razorPayTestKeyId,
} from '@config/environment';
import { showErrorMessage } from '../../helpers/show_messages';

export class PaymentScreen extends React.Component {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    const selectedAddress = props.navigation.state.params?.item;
    this.state = {
      addresses: [],
      selectedAddress: selectedAddress,
      paymentMethods: null,
      savePaymentResponse: null,
      saveOrderResponse: null,
      selectedMethodCode: null,
      deliveryaddressResponse: null,
      placeOrder: false,
      showPaymentMethodsApi: false,
      addressApi: false,
      cartTotals: null,
      showAlternateField: false,
      alternateMobile: '',
      alternateMobileError: '',
      newDeliveryAddress: '',
      pageLoaded: false,
      loading: false,
      showCircularProgress: false,
    };
  }
  async componentDidMount() {
    this.triggerScreenEvent();
    await this.setState({
      context: this.context,
    });
    this.getShippingMethods(this.state.selectedAddress);
  }
  getStreet(address) {
    let street = [];
    if (address.street[0]) {
      street.push(address.street[0]);
      if (address.street[1]) {
        street.push(address.street[1]);
      }
    }
    return street;
  }
  getShippingMethods(address) {
    if (address) {
      this.setState({ loading: true });
      const address_data = {
        email: this.state.context.userInfo.customer.email,
        region: address.region.region,
        region_id: address.region.region_id,
        region_code: address.region.region_code,
        country_id: address.country_code,
        street: this.getStreet(address),
        postcode: address.postcode,
        city: address.city,
        firstname: address.firstname,
        lastname: address.lastname,
        customer_id: address.customer_id,
        telephone: address.telephone,
        same_as_billing: 1,
      };
      const address_payload = {
        address: { ...address_data },
      };
      postRequest(API.checkout.estimate_shipping_methods, address_payload)
        .then(res => {
          if (!res.ok) {
            throw res;
          }
          return res.json();
        })
        .then(shipping_methods => {
          const payload = {
            addressInformation: {
              shipping_address: { ...address_data },
              billing_address: { ...address_data },
              shipping_carrier_code: shipping_methods[0].carrier_code,
              shipping_method_code: shipping_methods[0].method_code,
            },
          };
          postRequest(
            API.checkout.set_shipping_and_billing_information,
            payload,
          )
            .then(res => {
              if (!res.ok) {
                throw res;
              }
              return res.json();
            })
            .then(data => {
              console.log('data', data);
              this.setState({
                paymentMethods: data.payment_methods,
                cartTotals: data.totals,
                pageLoaded: true,
                loading: false,
              });
              this.onPaymentOptionPress(data.payment_methods[0]);
            })
            .catch(error => {
              this.setState({ loading: false });
              showErrorMessage(`${error.message}. Please try again.`);
            });
        })
        .catch(error => {
          this.setState({ loading: false });
          showErrorMessage(`${error.message}. Please try again.`);
        });
    }
  }
  onPaymentOptionPress = option => {
    this.setState({ selectedMethodCode: option });
  };
  selectAddress = address => {
    const { addresses } = this.state;
    let isFound = 0;
    for (let i = 0; i < addresses.length; i++) {
      if (addresses[i].id === address.id) {
        isFound = 1;
        break;
      }
    }
    if (isFound === 0) {
      addresses.push(address);
    }
    this.setState({ selectedAddress: address, addresses });
    this.getShippingMethods(address);
  };
  addAlternateNumber(address) {
    console.log(address, this.state.alternateMobile);
  }
  toggleAlternateField() {
    this.setState({ showAlternateField: !this.state.showAlternateField });
  }
  validate(mobile) {
    this.setState({ alternateMobile: mobile });
    if (!validateMobile(mobile)) {
      this.setState({
        alternateMobileError: 'Please enter correct mobile number.',
      });
    } else {
      this.setState({ alternateMobileError: '' });
    }
  }
  async placeOrder() {
    try {
      const customer_cart_id = await SyncStorage.get('customer_cart_id');
      const { selectedAddress, selectedMethodCode, context } = this.state;
      this.setState({ showCircularProgress: true });
      const { data } = await client.mutate({
        mutation: PLACE_ORDER_MUTATION,
        variables: { cart_id: customer_cart_id, payment_method: selectedMethodCode.code }
      });
      if (data && data.dkplaceOrder && data.dkplaceOrder.order_number) {
        const payload = { order_id: data.dkplaceOrder.order_number }
        if (selectedMethodCode.code === "razorpay" && data.dkplaceOrder.reference_number) {
          const rzpData = { amount: data.dkplaceOrder.amount, order_id: data.dkplaceOrder.reference_number, key: data.dkplaceOrder.merchant_id, currency: data.dkplaceOrder.currency }
          this.initiateRazorPay(payload, rzpData);
        }
        else if (selectedMethodCode.code === "paytm" && data.dkplaceOrder.reference_number) {
          //paytmcode
        }
        else {
          this.submitOrder(payload)
        }
      }
      else {
        console.log('order_number does not exit')
      }

    } catch (e) {
      this.setState({ showCircularProgress: false });
      showErrorMessage(`${e.message}. Please try again.`);

    }

  }

  submitOrder = async payload => {
    const { handleError, getGuestAndCustomerCartId, getCartItemCount } = this.state.context;
    try {
      const { data } = await client.query({
        query: FETCH_ORDER_DETAILS_QUERY,
        fetchPolicy: 'network-only',
        variables: { ...payload }
      });

      if (data && data.fetchOrder && data.fetchOrder.order_id) {
        this.setState({ showCircularProgress: false });
        if (data.fetchOrder && data.fetchOrder.status === 'success') {
          await getCartItemCount(0)
          await SyncStorage.remove('customer_cart_id');
          await getGuestAndCustomerCartId();
          let resetAction;
          resetAction = StackActions.reset({
            index: 1,
            actions: [
              NavigationActions.navigate({ routeName: 'Home' }),
              NavigationActions.navigate({
                routeName: 'OrderSuccess',
                params: { orderId: data.fetchOrder.order_id, retryPayment: false },
              }),
            ],
          });
          this.props.navigation.dispatch(resetAction);

        }
        else {
          console.log("data fetchorder", data);
          await getCartItemCount(0)
          await SyncStorage.remove('customer_cart_id');
          await getGuestAndCustomerCartId();

          let resetAction;
          resetAction = StackActions.reset({
            index: 1,
            actions: [
              NavigationActions.navigate({ routeName: 'Home' }),
              NavigationActions.navigate({
                routeName: 'OrderDetails',
                params: { orderId: data.fetchOrder.order_id, fetchOrderRes: data.fetchOrder }
              }),
            ],
          });
          this.props.navigation.dispatch(resetAction);

        }
      }
      else {
        console.log('not success')
      }
    }
    catch (e) {
      this.setState({ showCircularProgress: false });
      handleError(e)
    }
  };

  initiateRazorPay = async (payload, rzpData) => {
    const { userInfo } = this.state.context;
    const { amount, order_id, key, currency } = rzpData;
    const options = {
      description: '',
      image: 'https://www.dentalkart.com/dentalkarticon.png',
      currency: currency,
      key: key,
      amount: amount,
      order_id: order_id,
      name: 'Dentalkart',
      prefill: {
        email: userInfo.customer.email,
        contact: this.state.selectedAddress
          ? this.state.selectedAddress.telephone
          : '',
        name: `${userInfo.customer.firstname} ${userInfo.customer.lastname}`,
      },
      theme: { color: '' },
    };
    RazorpayCheckout.open(options)
      .then(response => {
        console.log('razorpay response ', response);
        // handle success
        const rzpres = {
          rzp_payment_id: response.razorpay_payment_id,
          rzp_order_id: response.razorpay_order_id,
          rzp_signature: response.razorpay_signature,
        };
        const RzpPayload = { ...payload, ...rzpres }
        this.submitOrder(RzpPayload)
      })
      .catch(error => {
        this.submitOrder(payload)
        showErrorMessage(`${error.description}. Please try again.`);
      });
  };

  triggerScreenEvent = _ => {
    const { userInfo } = this.context;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Payment',
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };
  render() {
    const { loading } = this.state;
    const { handleError } = this.context;
    return (
      <View style={{ flex: 1 }}>
        <Header back heading="Place Order" navigation={this.props.navigation} />
        <ScrollView
          ref={ref => (this.scrollView = ref)}
          style={{ flex: 1, backgroundColor: '#fff' }}
          keyboardShouldPersistTaps="handled">
          {this.state.selectedAddress ? (
            <DeliveryAddress
              address={this.state.selectedAddress}
              _this={this}
            />
          ) : null}
          {true ? (
            <View style={DeliveryPageStyle.paymentWrapper}>
              <Text style={DeliveryPageStyle.paymentHeading}>
                Payment Options
              </Text>
              <Query
                query={GET_NOTICES}
                fetchPolicy="network-only"
                client={client2}
                onError={error => handleError(error)}>
                {({ loading, data, error }) => {
                  if (loading || error) {
                    return null;
                  }
                  if (data.notices) {
                    const { notices } = data;
                    const paymentNotices = notices.filter(
                      notice =>
                        notice.section === 'payment' &&
                        (notice.source === 'app' || 'both'),
                    );
                    if (paymentNotices && paymentNotices.length > 0) {
                      return (
                        <View style={{ padding: 5 }}>
                          {paymentNotices.map(notice => (
                            <Text
                              style={{
                                color: notice.colour || SecondaryColor,
                                marginBottom: 5,
                              }}>
                              {notice.content}
                            </Text>
                          ))}
                        </View>
                      );
                    } else {
                      return null;
                    }
                  } else {
                    return null;
                  }
                }}
              </Query>
              <FlatList
                data={this.state.paymentMethods}
                renderItem={({ item }) =>
                  item.code !== 'paytm' && <Payments _this={this} item={item} />
                }
                keyExtractor={(item, index) => item.code}
                extraData={this.state}
              />
            </View>
          ) : (
              <View style={{ marginTop: 10 }}>
                <ActivityIndicator size="large" color="#2b79ac" />
              </View>
            )}
        </ScrollView>
        {this.state.cartTotals && (
          <DeliveryAction priceDetails={this.state.cartTotals} _this={this} />
        )}
        <Loader loading={loading} transparent={true} />
      </View>
    );
  }
}

export default PaymentScreen;
