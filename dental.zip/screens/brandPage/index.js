import React from 'react';
import {ScrollView, View, Text, TouchableOpacity} from 'react-native';
import {NavigationActions} from 'react-navigation';
import Header from '@components/header';
import {client} from '@apolloClient';
import  FeaturedBrands from './featured_brand';
import AllBrands from './all_brands';

export class BrandPageScreen extends React.Component {
	onFocusScroll =  () => {
		this.scrollView.scrollTo({x: 0, y: 200, animated: true});
	}
	render(){
		return (
			<View>
                <Header
                    back
                    heading='All Brands'
                    navigation={this.props.navigation}
                />
				<ScrollView ref={ref => (this.scrollView = ref)}>
					<View style={{paddingLeft:8, paddingRight:8, marginTop: 5, marginBottom:80, backgroundColor:'#f0f0f0'}}>
						<FeaturedBrands navigation={this.props.navigation}/>
						<AllBrands navigation={this.props.navigation} scrollIntoView={this.onFocusScroll}/>
					</View>
				</ScrollView>
			</View>
		);
	}
}

export default BrandPageScreen;
