import React from 'react';
import {
  View,
  ScrollView,
  ToastAndroid,
  Platform,
  KeyboardAvoidingView,
  Alert,
  Linking,
} from 'react-native';
import { NavigationActions } from 'react-navigation';
import EditAddressForm from './modules/editAddress';
import { validateMobile, validatePincode, validateGST } from '@helpers/validator';
import Header from '@components/header';
import { DentalkartContext } from '@dentalkartContext';
import { COUNTRIES_QUERY, COUNTRY_QUERY } from '@screens/country';
import { client } from '@apolloClient';
import API from '@config/api';
import { postRequest } from '@helpers/post_request';

import {
  ADD_ADDRESS_QUERY,
  UPDATE_ADDRESS_QUERY,
  GET_ADDRESSES_QUERY,
} from './graphql';
import { fireAnalyticsEvent } from '@helpers/firebase_analytics';
import { showErrorMessage, showSuccessMessage } from '../../helpers/show_messages';
import SyncStorage from '@helpers/async_storage';
import HeaderComponent from "@components/HeaderComponent";

class EditAddressesScreen extends React.Component {
  static contextType = DentalkartContext;
  constructor(props) {
    super(props);
    const { state } = this.props.navigation,
      item = state.params.item ? state.params.item : '';
    (street = item?.street?.[0]), (landmark = item?.street?.[1]);
    this.state = {
      firstname: item?.firstname ?? '',
      lastname: item?.lastname ?? '',
      mobile: item?.telephone ?? '',
      pincode: item?.postcode ?? '',
      street: street ? street : '',
      city: item?.city ?? '',
      state: item?.region?.region ?? '',
      stateRegionId: item?.region?.region_id ?? '',
      landmark: landmark ? landmark : '',
      country: {},
      gstin: item?.vat_id ?? '',
      address_id: item?.id ?? '',
      default_shipping: item.default_shipping ? true : false,
      deliveryAddress: props.deliveryAddress,
      editData: null,
      title: item.id ? 'Edit Address' : 'Add New Address',
      isVerified: item ? true : false,
      firstnameError: '',
      lastnameError: '',
      mobileError: '',
      pincodeError: '',
      streetError: '',
      cityError: '',
      stateError: '',
      locationError: '',
      gstinError: '',
      // isPickerOpen: false,
      countryList: [],
      regionList: [],
      apiValidations: {}
    };
    this._inputs = {};
  }
  _next(field) {
    this._inputs[field] && this._inputs[field].focus();
  }
  triggerScreenEvent = _ => {
    const { userInfo } = this.context;
    fireAnalyticsEvent({
      eventname: 'screenname',
      screenName: 'Edit Address',
      userId: userInfo && userInfo.customer ? userInfo.customer.id : '',
    });
  };

  requestOptionalValidations() {
    const { state } = this.props.navigation,
      item = state.params.item ? state.params.item : '';
    const country_code = item ? item.country_code : this.context.country.country_id;
    const payload = {
      "country_code": country_code
    }
    postRequest(API.validateFields, payload)
      .then(res => res.json())
      .then(data => {
        this.setState({ apiValidations: data });
      })
      .catch(error => console.log(error));
  }

  async componentDidMount() {
    let { country } = this.state;
    this.triggerScreenEvent();
    await this.getCountries();
    if (!country.value) {
      const { state } = this.props.navigation,
        item = state.params.item ? state.params.item : '';
      const country_code = item
        ? item.country_code
        : this.context.country.country_id;
      const countrydata = await this.getCountryInfo(country_code);
      country = {
        value: country_code,
        label: countrydata.country.full_name_english,
      };
      this.setState({ country });
    }
    this.getRegions(country.value);
    this.requestOptionalValidations()
  }

  getCountryInfo = async countryId => {
    try {
      const { data } = await client.query({
        query: COUNTRY_QUERY,
        variables: { id: countryId },
        fetchPolicy: 'cache-first',
      });
      return data;
    } catch (error) {
      showErrorMessage(`${error.message}. Please try again.`);
    }
  };
  getCountries = async () => {
    let countryList = [];
    try {
      const { data } = await client.query({
        query: COUNTRIES_QUERY,
        fetchPolicy: 'cache-first',
      });
      if (data.countries) {
        data.countries.map(item => {
          countryList.push({
            value: item.id,
            label: item.full_name_english || item.id,
          });
          return null;
        });
        this.setState({ countryList: countryList });
      }
    } catch (error) {
      showErrorMessage(`${error.message}. Please try again.`);
    }
  };
  getRegions = async (countryId = 'IN') => {
    let countryInfo;
    let regionList = [];
    let data = await client.readQuery({ query: COUNTRIES_QUERY });
    if (!data.countries) {
      countryInfo = await this.getCountryInfo(countryId);
    } else {
      data.countries.filter(item => {
        if (item.id === countryId) {
          countryInfo = item;
        }
        return null;
      });
    }
    if (countryInfo.available_regions.length > 0) {
      this.setState({ regionDisable: false });
      countryInfo.available_regions.map(item => {
        regionList.push({
          value: item.id,
          label: item.name,
        });
        return null;
      });
    } else {
      this.setState({ regionDisable: true });
    }
    this.setState({ regionList: regionList });
  };
  changeCountry() {
    const { navigate } = this.props.navigation;
    Alert.alert(
      'Change Country',
      'After changing country, currency will be changed.',
      [
        { text: 'Change Country', onPress: () => navigate('Country') },
        { text: 'Cancel', style: 'cancel' },
      ],
    );
  }
  _onValueChange(itemValue) {
    let selectedState = {};
    this.state.regionList.map((state) => {
      if (state.value === itemValue) {
        selectedState = state;
      }
    });
    // let selectedState = this.state.regionList[index-1];
    const newSelectedStateLabel = selectedState?.label ?? this.state.state;
    const newSelectedStateValue = selectedState?.value ?? this.state.stateRegionId;
    this.setState({
      state: newSelectedStateLabel,
      stateRegionId: newSelectedStateValue,
    });
    this.validate('state', newSelectedStateLabel);
  }
  onSavePress = async (id = '') => {
    const { checkout } = this.props.navigation.state.params;
    const { handleError } = this.context;
    try {
      const { data } = await client.query({
        query: GET_ADDRESSES_QUERY,
        fetchPolicy: 'network-only',
      });
      this.props.navigation.push('Address', { checkout });
     
    } catch (error) {
      const msg = handleError(error);
      showErrorMessage(`${msg}. Please try again.`);
    }
  };
  postSavingAddress = async (cache, { data }) => {
    let message, id;
    if (data.createCustomerAddress) {
      message = 'Address added successfully';
      id = data.createCustomerAddress.id;
      // this.props.navigation.navigate('Cart');
    } else {
      id = data.updateCustomerAddress.id;
      const storedAddress = await SyncStorage.get('delivery_address') || ''
      if (storedAddress && storedAddress.id === id) {
        await SyncStorage.set('delivery_address', data.updateCustomerAddress)
      }
      message = 'Address updated successfully';

    }
    showSuccessMessage(message);
    this.onSavePress(id);
  };
  saveAddress(_saveAddress) {
    const {
      firstname,
      lastname,
      mobile,
      pincode,
      gstin,
      street,
      landmark,
      city,
      country,
      default_shipping,
      address_id,
      stateRegionId,
      isVerified,
    } = this.state;

    if (isVerified) {
      const mergeStreet = [street, landmark];
      let variables = {
        firstname: firstname,
        lastname: lastname,
        postcode: pincode,
        telephone: mobile,
        street: mergeStreet,
        country_id: country.value,
        region_id: stateRegionId || 0,
        city: city.trim(),
        vat_id: gstin,
        default_shipping: default_shipping,
      };
      if (address_id) {
        //for update address id
        variables = { id: address_id, ...variables };
      }
      _saveAddress({ variables: variables });
    } else {
      showErrorMessage('Please fill your details correctly.');
    }
  }
  async validate(fieldName, value) {
    let isPincode = (isState = false);
    await this.setState({ [fieldName]: value });
    value = value?.trim() ?? value;
    if (!value) {
      // if(fieldName === 'pincode' && !this.props.optionalFields.postcode_required) {
      //    //fieldName === 'state' && !this.props.optionalFields.state_required){
      // 	await this.setState({[`${fieldName}Error`]: ''});
      // }else{
      await this.setState({ [`${fieldName}Error`]: 'Field can not be empty.' });
      // }
    } else {
      this.setState({ [`${fieldName}Error`]: '' });
    }

    if (fieldName == 'mobile') {
      const { country } = this.context;
      const country_id = country.country_id;
      if (! await validateMobile(value)) {
        console.log('here');
        await this.setState({
          [`${fieldName}Error`]:
            country_id === 'IN'
              ? 'Please enter a 10 digit mobile number.'
              : 'Mobile number must be more than 6 digits.',
        });
      } else {
        console.log('here 1');
        this.setState({ [`${fieldName}Error`]: '' });
      }
    }

    if (fieldName == 'pincode') {
      if (this.state.apiValidations.postcode_required && !validatePincode(value, this.state.apiValidations.postcode_format))
        await this.setState({ [`${fieldName}Error`]: 'Pincode must be in correct format.' });
      else
        this.setState({ [`${fieldName}Error`]: '' });
    }

    if (fieldName == 'gstin') {
      if (!value) {
        await this.setState({ [`${fieldName}Error`]: '' });
      } else if (!validateGST(value)) {
        await this.setState({
          [`${fieldName}Error`]: 'Please enter a valid gst number.',
        });
      } else {
        this.setState({ [`${fieldName}Error`]: '' });
      }
    }
    if (
      this.state.firstname &&
      this.state.lastname &&
      this.state.mobile &&
      !this.state.mobileError &&
      this.state.city.trim() &&
      this.state.street &&
      !this.state.gstinError
    ) {
      // isPincode = (this.props.optionalFields.postcode_required)? (this.state.pincode && !this.state.pincodeError? true : false) : true;
      // isState = (this.props.optionalFields.state_required)? (this.state.state && !this.state.stateError? true : false) : true;
      isPincode = this.state.pincode && !this.state.pincodeError ? true : false;
      isState = this.state.state && !this.state.stateError ? true : false;
      this.setState({ isVerified: isPincode && isState ? true : false });
    } else {
      this.setState({ isVerified: false });
    }
  }
  render() {
    const { state } = this.props.navigation;
    const { item } = state.params;
    return (
      <View style={{ flex: 1 }}>
        {/* <Header
          heading={this.state.title}
          navigation={this.props.navigation}
          back
        /> */}
        {/* <View style={{ height: 10, wdth: '100%' }}></View> */}
        <HeaderComponent label={this.state.title} onPress={() => this.props.navigation.navigate('Address')} style={{ height: 40 }} />
        {/* <View style={{ height: 10, wdth: '100%' }}></View> */}
        <ScrollView
          keyboardShouldPersistTaps={'handled'}
          keyboardDismissMode={'none'}>
          {/* <KeyboardAvoidingView behavior="padding" enabled> */}
          {this.state.country.value && <EditAddressForm
            _this={this}
            stateList={this.state.regionList}
            query={item ? UPDATE_ADDRESS_QUERY : ADD_ADDRESS_QUERY}
          />}
          {/* </KeyboardAvoidingView> */}
        </ScrollView>
      </View>
    );
  }
}

export default EditAddressesScreen;
