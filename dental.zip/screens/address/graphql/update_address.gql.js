import gql from "graphql-tag";
const UPDATE_ADDRESS = gql`
    mutation updateAddress(
        $id: Int!,
        $firstname: String!,
        $lastname: String!,
        $postcode: String!,
        $telephone: String!,
        $street:[String]!,
        $country_id: CountryCodeEnum!,
        $region_id: Int,
        $city: String!,
        $vat_id: String,
        $default_shipping: Boolean
    ){
        updateCustomerAddress( id: $id, input: {
            firstname: $firstname,
            lastname: $lastname,
            postcode: $postcode,
            telephone: $telephone,
            street: $street,
            country_code: $country_id,
            region: {
                region_id: $region_id
            },
            city: $city,
            vat_id: $vat_id,
            default_shipping: $default_shipping
        }){
                id,
                firstname,
                lastname,
                postcode,
                telephone,
                street,
                region{
                    region
                    region_id
                    region_code
                },
                country_code
                city,
                vat_id,
                default_shipping
        }
    }
`;
export default UPDATE_ADDRESS;
