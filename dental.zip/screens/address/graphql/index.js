export { default as GET_ADDRESSES_QUERY } from './get_addresses.gql';
export { default as ADD_ADDRESS_QUERY } from './add_address.gql';
export { default as DELETE_ADDRESS_QUERY } from './delete_address.gql';
export { default as UPDATE_ADDRESS_QUERY } from './update_address.gql';
