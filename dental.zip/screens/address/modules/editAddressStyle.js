import {StyleSheet, Platform} from 'react-native';
import {PrimaryColor, SecondaryColor} from '@config/environment';

export const EditAddress = StyleSheet.create({
  container: {
    padding: 5,
  },
  myLocationContainer: {
    backgroundColor: SecondaryColor,
    padding: 10,
    borderRadius: 3,
    marginBottom: 4,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  myLocationText: {
    color: '#fff',
    fontSize: 13,
    marginLeft: 5,
  },
  inputFieldGroup: {
    backgroundColor: '#fff',
    padding: 10,
    paddingBottom: 2,
    marginBottom: 10,
    borderRadius: 4,
    paddingHorizontal:15
  },
  button: { width: '100%', height: 48, borderRadius: 3, alignItems: 'center', flexDirection: 'row', marginTop: 18, backgroundColor: colors.blueColor, justifyContent: 'center', },
  buttonDisabled: { width: '100%', height: 48, borderRadius: 3, alignItems: 'center', flexDirection: 'row', marginTop: 18, backgroundColor: colors.blueColor, justifyContent: 'center',opacity:0.5 },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  checkBoxWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginEnd: 10,
    width:'100%'
  },
  checkBoxText: {
    fontSize: 14,
  },
  checkBox: {
    width: 50,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  defaultAddressSwitchWrapper: {
    borderRadius: 3,
    paddingLeft: 10,
    flexDirection: 'row',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  textField: {
    width: '90%',
  },
  mobileFieldWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  mobileCountryCode: {
    marginRight: 5,
    borderRadius: 2,
    borderWidth: 1,
    borderColor: '#efefef',
    padding: 5,
    color: '#28282880',
  },
  countryCangeWrapper: {
    position: 'absolute',
    right: 15,
    bottom: 25,
  },
  changeCountryText: {
    color: '#21212180',
    fontSize: 13,
  },
  dropdownWrapper: {
    borderBottomWidth: 1,
    borderColor: '#efefef',
    marginBottom: Platform.OS == 'ios' ? 40 : 10,
    width: '100%', borderWidth: 1, height: 45, borderColor: colors.LightCyan, borderRadius: 3, alignItems: 'center', justifyContent: 'center', top: 3.5 
  },
  textinputMainView: { width: '100%', height: 70, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5 },
  textinputSubView: { width: '49%', height: '100%', justifyContent: 'space-around' },
  labelText: { fontSize: 15, color: colors.StormGrey, },
  TextInput: { borderWidth: 1, height: 45, paddingHorizontal: 8, borderColor: colors.LightCyan,borderRadius: 3, marginTop: 15  },
  formWrapper: {
    width: '95%',
    alignSelf: 'center',
    paddingHorizontal: 8,
  },
  genderWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 10,
    paddingHorizontal: 10,
  },
  genderText: {
    color: '#212121',
    fontSize: 15,
  },
  genderTitle: {
    color: '#000',
    fontSize: 15,
    marginLeft: 5,
  },
  editButton: {
    position: 'absolute',
    bottom: 5,
    right: 5,
    backgroundColor: '#444',
    borderRadius: 10,
  },
  saveButton: {
    marginHorizontal: 20, right: 3,
    width: '90%', height: 48, borderRadius: 3, alignItems: 'center', marginVertical: 18, backgroundColor: colors.blueColor, justifyContent: 'center',
  },
  saveText: {
    color: '#fff',
  },
  buttonContainer: {
    elevation: 3,
    marginVertical: 20,
  },
  updateButton: {
    position: 'absolute',
    right: 5,
    top: 15,
  },
  buttonWrapper: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#00000050',
    padding: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 15,
    marginLeft: 10,
  },
  emailTextInputView: { width: '100%', height: 45, borderWidth: 1, alignItems: 'center', flexDirection: 'row', paddingHorizontal: 8, borderRadius: 3, marginBottom: 3, top: 5, borderColor: colors.LightCyan, },
  AsteriskIcon:{color:'red',fontSize:15}
});
