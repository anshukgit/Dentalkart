export { default as GET_TEMPLATE_QUERY } from './get_template.gql';

