export { default as COUNTRIES_LIST_QUERY } from './country_list.gql';
export { default as SET_COUNTRY_QUERY } from './set_country.gql';
