import React, {Component} from 'react';
import {View, ScrollView} from 'react-native';
import {DentalkartContext} from '@dentalkartContext';
import Loader from '@components/loader';
import Category from '@screens/category';
import ProductDetails from '@screens/product';
import Header from '@components/header';

export default class UrlResolver extends Component {
  constructor() {
    super();
    this.state = {
      loading: true,
      pageType: null,
    };
  }
  static contextType = DentalkartContext;
  getPageType = async () => {
    const {navigation} = this.props;
    const urlKey = navigation.getParam('url_key');
    const {urlResolver} = this.context;
    console.log(urlKey);
    const page = await urlResolver(urlKey);
    console.log('page', page);
    this.setState({loading: false, pageType: page});
  };
  componentDidMount() {
    this.getPageType();
  }
  render() {
    const {loading, pageType} = this.state;
    const {navigation} = this.props;
    const {userInfo} = this.context;
    const urlKey = navigation.getParam('url_key');
    return (
      <View>
        <Header
          menu
          cart
          title
          category
          search
          navigation={this.props.navigation}
        />
        {!loading && pageType && pageType.urlResolver && (
          <View>
            {pageType.urlResolver.type === 'CATEGORY' ? (
              <ScrollView>
                <Category
                  urlResolver={pageType.urlResolver}
                  navigation={this.props.navigation}
                />
              </ScrollView>
            ) : (
              <View>
                <ProductDetails
                  urlKey={urlKey}
                  navigation={this.props.navigation}
                />
              </View>
            )}
          </View>
        )}
        {loading && <Loader loading={loading} transparent={true} />}
      </View>
    );
  }
}
